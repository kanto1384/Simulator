using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace JsonEditorSolution
{
    /// <summary>
    /// A Windows Forms form that loads JSON from files or text, displays
    /// structures in a TreeView, allows array editing via DataGridView, and
    /// supports drag-and-drop of JSON files. It also automatically loads all
    /// *.json files in a local "data" directory on start.
    /// </summary>
    public class JsonEditorForm : Form
    {
        private readonly TreeView treeView;
        private readonly DataGridView dataGridView;
        // Text box for manual JSON input and output (removed in this version)
        // private readonly TextBox textBoxJson;
        private readonly Button buttonLoad;
        private readonly Button buttonSave;

        private readonly string dataDirectory;
        // Tracks the currently loaded file path for saving. Null if data loaded via text box or multiple files.
        private string? currentFilePath;
        private JToken? rootJson;

        public JsonEditorForm()
        {
            this.Text = "JSON Editor";
            this.Width = 800;
            this.Height = 600;

            dataDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");

            // Initialize TreeView
            treeView = new TreeView
            {
                Dock = DockStyle.Left,
                Width = 250
            };
            treeView.AfterSelect += TreeView_AfterSelect;

            // Initialize DataGridView
            dataGridView = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            // Allow editing by clicking a cell (double click enters edit mode)
            dataGridView.ReadOnly = false;
            dataGridView.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView.CellValueChanged += DataGridView_CellValueChanged;
            // Handle key presses to commit edits on Enter
            dataGridView.KeyDown += DataGridView_KeyDown;
            // Update JSON in real time when cell editing ends
            dataGridView.CellEndEdit += DataGridView_CellEndEdit;

            // Panel for controls on the right
            var rightPanel = new Panel { Dock = DockStyle.Fill };

            // Removed the bottom JSON preview text box; editing is done directly via grid

            // Buttons for loading and saving JSON from the text box
            buttonLoad = new Button { Text = "Load JSON", Dock = DockStyle.Top };
            buttonLoad.Click += ButtonLoad_Click;

            buttonSave = new Button { Text = "Save JSON", Dock = DockStyle.Top };
            buttonSave.Click += ButtonSave_Click;

            // Assemble the right panel (no preview box)
            rightPanel.Controls.Add(dataGridView);
            rightPanel.Controls.Add(buttonSave);
            rightPanel.Controls.Add(buttonLoad);

            // Add controls to the form (treeView on the left, rightPanel on the right)
            this.Controls.Add(rightPanel);
            this.Controls.Add(treeView);

            // Enable drag-and-drop of JSON files onto the form
            this.AllowDrop = true;
            this.DragEnter += Form_DragEnter;
            this.DragDrop += Form_DragDrop;
        }

        /// <summary>
        /// When the form is shown, automatically load all JSON files in the
        /// data directory if it exists.
        /// </summary>
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            LoadJsonDirectory();
        }

        /// <summary>
        /// Enumerates *.json files in the data directory and adds each to the tree.
        /// Each file's root element becomes a top-level node named after the file.
        /// </summary>
        private void LoadJsonDirectory()
        {
            if (!Directory.Exists(dataDirectory))
            {
                return;
            }
            treeView.Nodes.Clear();
            rootJson = null;
            currentFilePath = null;
            foreach (string file in Directory.GetFiles(dataDirectory, "*.json"))
            {
                try
                {
                    string json = File.ReadAllText(file);
                    JToken token = JToken.Parse(json);
                    AddNode(token, null, Path.GetFileName(file));
                    // Keep reference to last loaded token for Save button
                    rootJson = token;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to load {file}: {ex.Message}");
                }
            }
            treeView.ExpandAll();

            // Automatically select the first array node if available
            if (rootJson != null)
            {
                SelectFirstArrayNode();
            }
        }

        /// <summary>
        /// Handles drag-enter events to determine if a dragged file is acceptable.
        /// Allows dropping of .json files only.
        /// </summary>
        private void Form_DragEnter(object? sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Any(f => Path.GetExtension(f).Equals(".json", StringComparison.OrdinalIgnoreCase)))
                {
                    e.Effect = DragDropEffects.Copy;
                }
            }
        }

        /// <summary>
        /// Handles drag-drop events. When a JSON file is dropped onto the form,
        /// it is parsed and displayed in the editor.
        /// </summary>
        private void Form_DragDrop(object? sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                string? file = files.FirstOrDefault(f => Path.GetExtension(f).Equals(".json", StringComparison.OrdinalIgnoreCase));
                if (!string.IsNullOrEmpty(file))
                {
                    LoadJsonFromFile(file);
                }
            }
        }

        /// <summary>
        /// Reads a JSON file from disk and loads it into the tree and text box.
        /// </summary>
        private void LoadJsonFromFile(string filePath)
        {
            try
            {
                string json = File.ReadAllText(filePath);
                rootJson = JToken.Parse(json);
                // Removed preview: do not display JSON in a text box
                treeView.Nodes.Clear();
                AddNode(rootJson, null, Path.GetFileName(filePath));
                treeView.ExpandAll();
                // Record the current file path so that Save can overwrite it if desired
                currentFilePath = filePath;

                // Automatically select the first editable array node to show the grid view
                SelectFirstArrayNode();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load {filePath}: {ex.Message}");
            }
        }

        /// <summary>
        /// Finds and selects the first TreeView node whose tag is a JArray of JObject, so that the
        /// DataGridView is automatically populated when a JSON file is loaded. If no such node exists,
        /// the selection remains unchanged.
        /// </summary>
        private void SelectFirstArrayNode()
        {
            TreeNode? result = FindArrayNode(treeView.Nodes);
            if (result != null)
            {
                treeView.SelectedNode = result;
            }
        }

        /// <summary>
        /// Recursively searches the collection of nodes for a node whose Tag is a JArray of JObject.
        /// Returns the first matching node or null if none found.
        /// </summary>
        private TreeNode? FindArrayNode(TreeNodeCollection nodes)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Tag is JArray arr && arr.Count > 0 && arr.First is JObject)
                {
                    return node;
                }
                TreeNode? child = FindArrayNode(node.Nodes);
                if (child != null)
                {
                    return child;
                }
            }
            return null;
        }

        /// <summary>
        /// Loads JSON from a file selected via OpenFileDialog. Used by the "Load JSON" button.
        /// </summary>
        private void ButtonLoad_Click(object? sender, EventArgs e)
        {
            using var dialog = new OpenFileDialog();
            dialog.Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*";
            dialog.Title = "Select JSON File";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                LoadJsonFromFile(dialog.FileName);
            }
        }

        /// <summary>
        /// Writes the currently loaded JSON back into the text box. Used by the "Save JSON" button.
        /// </summary>
        private void ButtonSave_Click(object? sender, EventArgs e)
        {
            if (rootJson != null)
            {
                // If a file path is known, prompt to overwrite or choose a file
                string? savePath = currentFilePath;
                using var dialog = new SaveFileDialog();
                dialog.Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*";
                dialog.Title = savePath != null ? "Save JSON" : "Save JSON As";
                dialog.FileName = savePath != null ? Path.GetFileName(savePath) : string.Empty;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    savePath = dialog.FileName;
                }

                if (savePath != null)
                {
                    try
                    {
                        File.WriteAllText(savePath, rootJson.ToString(Formatting.Indented));
                        currentFilePath = savePath;
                        MessageBox.Show($"JSON saved to {savePath}.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to save JSON: {ex.Message}");
                    }
                }
                else
                {
                    MessageBox.Show("Save operation cancelled.");
                }
            }
        }

        /// <summary>
        /// Recursively creates TreeNodes from a JToken and attaches them to the parent.
        /// A top-level name is provided to label the root node.
        /// </summary>
        private void AddNode(JToken token, TreeNode? parent, string name)
        {
            TreeNode node;
            if (parent == null)
            {
                node = treeView.Nodes.Add(name);
            }
            else
            {
                node = parent.Nodes.Add(name);
            }
            node.Tag = token;

            switch (token)
            {
                case JObject obj:
                    foreach (var prop in obj.Properties())
                    {
                        AddNode(prop.Value, node, prop.Name);
                    }
                    break;
                case JArray arr:
                    for (int i = 0; i < arr.Count; i++)
                    {
                        AddNode(arr[i], node, "[" + i + "]");
                    }
                    break;
                default:
                    node.Text += " : " + token.ToString();
                    break;
            }
        }

        /// <summary>
        /// When a TreeView node is selected, display the array of objects (if applicable)
        /// in the DataGridView so that it can be edited.
        /// </summary>
        private void TreeView_AfterSelect(object? sender, TreeViewEventArgs e)
        {
            // Clear the grid's data source and tag
            dataGridView.DataSource = null;
            dataGridView.Tag = null;

            if (e.Node == null)
            {
                return;
            }

            JToken? token = e.Node.Tag as JToken;
            if (token == null)
            {
                return;
            }

            // Determine the type of token selected and convert to a DataTable accordingly
            DataTable? table = CreateDataTableForToken(token);
            if (table != null)
            {
                dataGridView.DataSource = table;
                // Store the selected token on the grid so we can update it later
                dataGridView.Tag = token;
            }
        }

        /// <summary>
        /// Converts a JArray of JObject instances into a DataTable. Columns are based
        /// on the union of all property names across the objects.
        /// </summary>
        private static DataTable ConvertArrayToDataTable(JArray array)
        {
            DataTable dt = new DataTable();
            var columns = array
                .SelectMany(jt => jt.Type == JTokenType.Object ? jt.Children<JProperty>() : Enumerable.Empty<JProperty>())
                .Where(p => p.Value.Type == JTokenType.String || p.Value.Type == JTokenType.Integer || p.Value.Type == JTokenType.Float || p.Value.Type == JTokenType.Boolean || p.Value.Type == JTokenType.Null)
                .Select(p => p.Name)
                .Distinct()
                .ToList();
            foreach (var col in columns)
            {
                dt.Columns.Add(col);
            }
            foreach (JObject obj in array.OfType<JObject>())
            {
                DataRow row = dt.NewRow();
                foreach (var col in columns)
                {
                    // Only assign primitive values; nested objects/arrays are ignored
                    if (obj.TryGetValue(col, out JToken? value) && (value.Type == JTokenType.String || value.Type == JTokenType.Integer || value.Type == JTokenType.Float || value.Type == JTokenType.Boolean || value.Type == JTokenType.Null))
                    {
                        row[col] = value.ToString();
                    }
                    else
                    {
                        row[col] = null;
                    }
                }
                dt.Rows.Add(row);
            }
            // Attach metadata to the DataTable so we know how to write back changes
            dt.ExtendedProperties["Type"] = "ArrayOfObjects";
            dt.ExtendedProperties["Columns"] = columns;
            return dt;
        }

        /// <summary>
        /// Creates a DataTable representation of a JToken for editing in the DataGridView.
        /// - If the token is a JArray of objects, a table is created with columns for each primitive property.
        /// - If the token is a JArray of primitives, a single-column table is created.
        /// - If the token is a JObject, a single-row table is created for its primitive properties.
        /// - Otherwise, returns null (no editable table).
        /// The DataTable stores metadata in ExtendedProperties to aid writing back changes.
        /// </summary>
        private static DataTable? CreateDataTableForToken(JToken token)
        {
            switch (token)
            {
                case JArray arr:
                    // Check if this is an array of objects (for example, students or scores)
                    if (arr.Count > 0 && arr.First is JObject)
                    {
                        return ConvertArrayToDataTable(arr);
                    }
                    // Array of primitives (e.g., [1,2,3])
                    else if (arr.Count > 0 && arr.First is JValue)
                    {
                        DataTable dt = new DataTable();
                        dt.Columns.Add("Value");
                        foreach (JValue val in arr.OfType<JValue>())
                        {
                            DataRow row = dt.NewRow();
                            row[0] = val.ToString();
                            dt.Rows.Add(row);
                        }
                        dt.ExtendedProperties["Type"] = "ArrayOfValues";
                        return dt;
                    }
                    break;
                case JObject objToken:
                    // Single object: create a table with a single row for primitive properties
                    var primitiveProps = objToken.Properties()
                        .Where(p => p.Value.Type == JTokenType.String || p.Value.Type == JTokenType.Integer || p.Value.Type == JTokenType.Float || p.Value.Type == JTokenType.Boolean || p.Value.Type == JTokenType.Null)
                        .ToList();
                    if (primitiveProps.Any())
                    {
                        DataTable dt = new DataTable();
                        foreach (var prop in primitiveProps)
                        {
                            dt.Columns.Add(prop.Name);
                        }
                        DataRow row = dt.NewRow();
                        foreach (var prop in primitiveProps)
                        {
                            row[prop.Name] = prop.Value.ToString();
                        }
                        dt.Rows.Add(row);
                        dt.ExtendedProperties["Type"] = "Object";
                        dt.ExtendedProperties["Columns"] = primitiveProps.Select(p => p.Name).ToList();
                        return dt;
                    }
                    break;
                case JValue jVal:
                    // Single value: create single cell table
                    DataTable dv = new DataTable();
                    dv.Columns.Add("Value");
                    DataRow r = dv.NewRow();
                    r[0] = jVal.ToString();
                    dv.Rows.Add(r);
                    dv.ExtendedProperties["Type"] = "Value";
                    return dv;
            }
            // Other structures (nested arrays or objects) are not displayed for editing
            return null;
        }

        /// <summary>
        /// Updates the underlying JArray when a cell value changes in the DataGridView.
        /// </summary>
        private void DataGridView_CellValueChanged(object? sender, DataGridViewCellEventArgs e)
        {
            // Ensure there is a selected token and table metadata
            if (dataGridView.Tag is JToken token && dataGridView.DataSource is DataTable dt && e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                string? type = dt.ExtendedProperties["Type"] as string;
                string columnName = dataGridView.Columns[e.ColumnIndex].HeaderText;
                var newValue = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString();

                switch (type)
                {
                    case "ArrayOfObjects":
                        if (token is JArray arr)
                        {
                            if (e.RowIndex < arr.Count && arr[e.RowIndex] is JObject obj)
                            {
                                obj[columnName] = JToken.FromObject(newValue ?? string.Empty);
                            }
                        }
                        break;
                    case "ArrayOfValues":
                        if (token is JArray valArr)
                        {
                            if (e.RowIndex < valArr.Count)
                            {
                                valArr[e.RowIndex] = JToken.FromObject(newValue ?? string.Empty);
                            }
                        }
                        break;
                    case "Object":
                        if (token is JObject jObj)
                        {
                            jObj[columnName] = JToken.FromObject(newValue ?? string.Empty);
                        }
                        break;
                    case "Value":
                        if (token is JValue valTok)
                        {
                            // Update the value via its parent, since Replace requires a parent
                            JToken newTok = JToken.FromObject(newValue ?? string.Empty);
                            if (valTok.Parent is JProperty parentProp)
                            {
                                parentProp.Value = newTok;
                            }
                            else if (valTok.Parent is JArray parentArr)
                            {
                                int idx = parentArr.IndexOf(valTok);
                                if (idx >= 0)
                                {
                                    parentArr[idx] = newTok;
                                }
                            }
                        }
                        break;
                }
            }
        }

        /// <summary>
        /// Handles the end of cell editing to update the underlying JSON and refresh the preview text box.
        /// This ensures that edits made in the DataGridView are immediately reflected in the JSON string.
        /// </summary>
        private void DataGridView_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            // Ensure the value is committed
            dataGridView.CommitEdit(DataGridViewDataErrorContexts.Commit);

            // Update the JSON object via the existing CellValueChanged logic
            DataGridView_CellValueChanged(sender, e);

            if (rootJson != null)
            {
                // Rebuild the tree and attempt to reselect the edited token's node
                if (dataGridView.Tag is JToken editedToken)
                {
                    RebuildTreeAndReselect(editedToken);
                }
            }
        }

        /// <summary>
        /// Rebuilds the tree view from the current rootJson and re-selects the node corresponding
        /// to the given edited token, if possible. This keeps the tree in sync with edits.
        /// </summary>
        private void RebuildTreeAndReselect(JToken editedToken)
        {
            string path = editedToken.Path;
            // Save the current root node name
            string rootName = treeView.Nodes.Count > 0 ? treeView.Nodes[0].Text : (currentFilePath != null ? Path.GetFileName(currentFilePath) : "root");
            treeView.BeginUpdate();
            treeView.Nodes.Clear();
            if (rootJson != null)
            {
                AddNode(rootJson, null, rootName);
                treeView.ExpandAll();
                // Try to find and select the node corresponding to path
                TreeNode? nodeToSelect = FindNodeByPath(treeView.Nodes, path);
                if (nodeToSelect != null)
                {
                    treeView.SelectedNode = nodeToSelect;
                }
            }
            treeView.EndUpdate();
        }

        /// <summary>
        /// Parses the JToken.Path into segments and recursively finds the corresponding TreeNode.
        /// Example path: "students[0].name".
        /// </summary>
        private TreeNode? FindNodeByPath(TreeNodeCollection nodes, string path)
        {
            if (string.IsNullOrEmpty(path)) return null;
            // Split path into segments (handling array indices)
            var segments = SplitPath(path);
            return FindNodeRecursive(nodes, segments, 0);
        }

        private TreeNode? FindNodeRecursive(TreeNodeCollection nodes, string[] segments, int index)
        {
            if (index >= segments.Length)
            {
                return null;
            }
            string segment = segments[index];
            foreach (TreeNode node in nodes)
            {
                // Node names include brackets for array indices and property names match
                if (node.Text.StartsWith(segment))
                {
                    if (index == segments.Length - 1)
                    {
                        return node;
                    }
                    return FindNodeRecursive(node.Nodes, segments, index + 1);
                }
            }
            return null;
        }

        /// <summary>
        /// Splits a JToken.Path string into segments for tree navigation.
        /// For example, "students[0].name" becomes ["students", "[0]", "name"].
        /// </summary>
        private static string[] SplitPath(string path)
        {
            var segments = new System.Collections.Generic.List<string>();
            int i = 0;
            while (i < path.Length)
            {
                if (path[i] == '[')
                {
                    int end = path.IndexOf(']', i);
                    if (end >= 0)
                    {
                        segments.Add(path.Substring(i, end - i + 1));
                        i = end + 1;
                    }
                    else
                    {
                        // Malformed path; break
                        break;
                    }
                }
                else
                {
                    int dotIndex = path.IndexOfAny(new[] { '.', '[' }, i);
                    if (dotIndex == -1)
                    {
                        segments.Add(path.Substring(i));
                        break;
                    }
                    else
                    {
                        segments.Add(path.Substring(i, dotIndex - i));
                        i = dotIndex;
                        if (path[i] == '.')
                        {
                            i++; // skip dot
                        }
                    }
                }
            }
            return segments.ToArray();
        }

        /// <summary>
        /// Handles key presses on the DataGridView. When Enter is pressed, commits the current edit
        /// and updates the tree. Without this, pressing Enter may not trigger CellEndEdit.
        /// </summary>
        private void DataGridView_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Commit the edit in the current cell. This will trigger CellEndEdit and update the tree.
                if (dataGridView.IsCurrentCellInEditMode)
                {
                    dataGridView.EndEdit();
                }
                e.Handled = true;
            }
        }
    }
}
