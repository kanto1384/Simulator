# WinForms OPC UA Client (.NET Framework)

- 대상 프레임워크: **.NET Framework 4.7.2**
- UI: **Windows Forms**
- 기능: 서버 연결(익명/사용자), 노드 브라우즈, **Read/Write**

## 빌드/실행 방법
1. Windows에서 **Visual Studio 2019/2022**로 `WinFormsOpcUaClient.sln` 또는 `WinFormsOpcUaClient\WinFormsOpcUaClient.csproj`를 엽니다.
2. NuGet 패키지 복원을 허용합니다. (자동으로 `OPCFoundation.NetStandard.Opc.Ua` 1.x 버전이 설치됩니다)
3. 빌드하고 실행합니다.

## 사용법
- 기본 Endpoint: `opc.tcp://localhost:4840`
- Anonymous 체크 시 익명 로그인 / 해제 시 사용자/비밀번호 입력 가능
- 좌측 트리에서 노드를 펼치고 선택하면 NodeId가 우측에 자동 표시됩니다.
- **Read** 버튼: 해당 노드의 Value를 읽습니다.
- **Write** 버튼: 입력한 값으로 쓰기 시도 (대상 노드의 DataType을 읽어 가능한 범위에서 자동 변환)

> 보안 모드가 `None`인 엔드포인트를 우선 선택합니다. 보안이 요구되는 서버의 경우 인증서 구성이 필요합니다.
> 데모/테스트 서버를 사용할 때는 서버가 쓰기를 허용하는 노드에 한해 Write가 성공합니다.

## 참고
- 본 예제는 단순 동작을 위한 최소 구현이며, 실서비스 적용 시 예외 처리, 재연결, 인증서 저장소/보안 정책 등을 강화해 주세요.