using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<SpecRange> _spec = new List<SpecRange>();
        private List<string> _lastExcelRows = new List<string>();

        private static readonly HashSet<char> HexAreas = new HashSet<char>(new[] { 'B', 'W', 'X', 'Y' });
        private static readonly HashSet<char> DecAreas = new HashSet<char>(new[] { 'M', 'D', 'R', 'L', 'Z' }); // ZR -> Z
        private const int MaxGap = 130;

        public MainForm()
        {
            InitializeComponent();
            txtInput.Text = "W:1000,1082&W:10960:10&D:10960:10";
            AllowDrop = true;
            DragEnter += MainForm_DragEnter;
            DragDrop += MainForm_DragDrop;
            cboSpecMode.Items.AddRange(new object[] { "최적화(LENGTH/주소 규칙)", "원본 주소 목록" });
            cboSpecMode.SelectedIndex = 0;
            cboSpecMode.SelectedIndexChanged += (_, __) => UpdateNormalizedBox();
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Any(f => Path.GetExtension(f).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))) { e.Effect = DragDropEffects.Copy; return; }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;

                var allRows = new List<string>();
                int used = 0, skipped = 0;
                foreach (var file in files)
                {
                    if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)) { skipped++; continue; }
                    var sheet = SimpleXlsx.FindSheetByName(file, "VARIABLES");
                    if (sheet == null) { skipped++; continue; }
                    var rows = SimpleXlsx.ReadColumnStrings(file, sheet.Target, "H");
                    if (rows.Count == 0) { skipped++; continue; }
                    allRows.AddRange(rows); used++;
                }
                if (allRows.Count == 0) { MessageBox.Show("가져올 데이터가 없습니다. (.xlsx / VARIABLES 시트 / H열)"); return; }
                _lastExcelRows = allRows;
                lblSheetInfo.Text = $"VARIABLES/H  Files={used}, Skipped={skipped}";
                BuildFromExcelRows(allRows);
            }
            catch (Exception ex) { MessageBox.Show("엑셀 처리 오류: " + ex.Message); }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                var dict = ParseAreaAddressLenList(txtInput.Text ?? string.Empty);
                BuildFromAreaEntries(dict, "(수동 입력)");
                _lastExcelRows.Clear();
            }
            catch (Exception ex) { txtOutput.Text = "[에러] " + ex.Message; }
        }

        private void BuildFromExcelRows(List<string> rows)
        {
            var entries = new Dictionary<char, List<Entry>>();
            foreach (var row in rows)
            {
                var kv = ParseKeyValues(row);
                if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;

                bool hasLen = false;
                int len = 1;
                if (kv.TryGetValue("LENGTH", out var lt) && !string.IsNullOrWhiteSpace(lt) && lt.Trim() != "@")
                { hasLen = int.TryParse(lt.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out len) && len > 0; if (!hasLen) len = 1; }

                char area = dev.Trim().ToUpperInvariant()[0]; // ZR -> Z
                if (!TryParseByArea(area, addr, out int start)) continue;

                int span = hasLen ? len * 2 : 0;
                int endInc = hasLen ? (start + span - 1) : start;

                if (!entries.TryGetValue(area, out var list)) { list = new List<Entry>(); entries[area] = list; }
                list.Add(new Entry(area, start, endInc, span, hasLen));
            }
            BuildFromAreaEntries(entries, "Excel");
        }

        private void BuildFromAreaEntries(Dictionary<char, List<Entry>> perAreaEntries, string sourceLabel)
        {
            var sb = new StringBuilder();
            var outSpec = new List<SpecRange>();
            var map = new MemoryMap();

            foreach (var kv in perAreaEntries.OrderBy(p => AreaOrderKey(p.Key)))
            {
                char area = kv.Key;
                var list = kv.Value.OrderBy(e => e.Start).ThenBy(e => e.EndInc).ToList();
                if (list.Count == 0) continue;

                sb.AppendLine($"[{area}] 입력건수={list.Count}  예: {FormatByArea(area, list[0].Start)} {(list[0].HasLength ? $"len*2={list[0].Span}" : "(addr)") }");

                var chains = new List<List<Entry>>();
                var cur = new List<Entry>();
                foreach (var e in list)
                {
                    if (cur.Count == 0) { cur.Add(e); continue; }
                    var last = cur[cur.Count - 1];
                    int gap = e.Start - last.EndInc;
                    if (gap <= MaxGap) cur.Add(e);
                    else { chains.Add(cur); cur = new List<Entry> { e }; }
                }
                if (cur.Count > 0) chains.Add(cur);

                foreach (var chain in chains)
                {
                    foreach (var g in SplitByHasLength(chain))
                    {
                        if (g.Count == 0) continue;
                        bool lenMode = g[0].HasLength;

                        if (lenMode)
                        {
                            if (area == 'W')
                            {
                                foreach (var piece in SplitLengthGroupByHexThousand(g))
                                {
                                    outSpec.Add(new SpecRange(area, piece.Start, piece.TotalSpan));
                                    sb.AppendLine($"  -> LEN W split: {FormatByArea(area, piece.Start)} Count={piece.TotalSpan}");
                                }
                            }
                            else
                            {
                                int sumSpan = g.Sum(x => x.Span);
                                outSpec.Add(new SpecRange(area, g.First().Start, sumSpan));
                                sb.AppendLine($"  -> LEN chain: {FormatByArea(area, g.First().Start)} Count={sumSpan}");
                            }
                        }
                        else
                        {
                            int start = g.First().Start;
                            int lastStart = g.Last().Start;
                            int count = (lastStart - start) + 2;
                            outSpec.Add(new SpecRange(area, start, count));
                            sb.AppendLine($"  -> ADDR chain: {FormatByArea(area, start)} ~ {FormatByArea(area, lastStart)}  Count={count}");
                        }
                    }

                    int chainStart = chain.Min(x => x.Start);
                    int chainEndInc = chain.Max(x => x.EndInc);
                    map.Segments.Add(new Segment(area, chainStart, chainEndInc - chainStart + 1));
                    sb.AppendLine($" -> 체인(맵): {FormatByArea(area, chainStart)} ~ {FormatByArea(area, chainEndInc)}");
                }
                sb.AppendLine();
            }

            _spec = outSpec.OrderBy(s => AreaOrderKey(s.Area)).ThenBy(s => s.StartHex).ToList();
            _map = map;

            txtOutput.Text = $"[소스] {sourceLabel}
" + sb.ToString();
            UpdateNormalizedBox();
            FillAreaAndPages();
        }

        private static List<List<Entry>> SplitByHasLength(List<Entry> chain)
        {
            var result = new List<List<Entry>>();
            List<Entry> cur = null;
            bool? mode = null;
            foreach (var e in chain)
            {
                bool m = e.HasLength;
                if (cur == null || mode == null || mode.Value != m)
                {
                    if (cur != null && cur.Count > 0) result.Add(cur);
                    cur = new List<Entry>(); mode = m;
                }
                cur.Add(e);
            }
            if (cur != null && cur.Count > 0) result.Add(cur);
            return result;
        }

        private static List<SpanPiece> SplitLengthGroupByHexThousand(List<Entry> group)
        {
            var pieces = new List<SpanPiece>();
            foreach (var e in group)
            {
                int p = e.Start;
                int endInc = e.EndInc;
                while (p <= endInc)
                {
                    int nextBoundary = ((p / 0x1000) + 1) * 0x1000;
                    int segEndInc = Math.Min(endInc, nextBoundary - 1);
                    int span = segEndInc - p + 1;
                    if (pieces.Count > 0 && (pieces[pieces.Count - 1].Start / 0x1000) == (p / 0x1000) &&
                        pieces[pieces.Count - 1].Start + pieces[pieces.Count - 1].TotalSpan == p)
                    { pieces[pieces.Count - 1].TotalSpan += span; }
                    else { pieces.Add(new SpanPiece { Start = p, TotalSpan = span }); }
                    p = segEndInc + 1;
                }
            }
            return pieces;
        }

        private static Dictionary<char, List<Entry>> ParseAreaAddressLenList(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) throw new ArgumentException("입력이 비어 있습니다.");
            if (s.StartsWith("MEMORY=", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);
            var dict = new Dictionary<char, List<Entry>>();
            foreach (var part in s.Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = part.Trim();
                int colon = p.IndexOf(':');
                if (colon <= 0) throw new FormatException($"형식 오류: '{p}' (예: W:10960:10 또는 W:1000,1082)");
                char area = p.Substring(0, colon).Trim().ToUpperInvariant()[0];
                var rest = p.Substring(colon + 1);

                foreach (var token in rest.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var t = token.Trim();
                    int addr; int len;
                    var parts2 = t.Split(':');
                    bool hasLen = (parts2.Length >= 2) && int.TryParse(parts2[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out len) && len > 0;
                    if (!TryParseByArea(area, parts2[0], out addr)) continue;
                    int span = hasLen ? len * 2 : 0;
                    int endInc = hasLen ? (addr + span - 1) : addr;
                    if (!dict.TryGetValue(area, out var list)) { list = new List<Entry>(); dict[area] = list; }
                    list.Add(new Entry(area, addr, endInc, span, hasLen));
                }
            }
            return dict;
        }

        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var part in s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var kv = part.Split(new[] { '=' }, 2);
                if (kv.Length == 2) dict[kv[0].Trim()] = kv[1].Trim();
            }
            return dict;
        }

        private static bool TryParseByArea(char area, string token, out int val)
        {
            val = 0; if (string.IsNullOrWhiteSpace(token)) return false;
            token = token.Trim(); area = char.ToUpperInvariant(area);
            if (DecAreas.Contains(area))
            {
                if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    return int.TryParse(token.Substring(2), System.Globalization.NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
                return int.TryParse(token, System.Globalization.NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
            }
            else
            {
                if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    return int.TryParse(token.Substring(2), System.Globalization.NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
                return int.TryParse(token, System.Globalization.NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            }
        }

        private static string FormatByArea(char area, int value)
        {
            area = char.ToUpperInvariant(area);
            if (HexAreas.Contains(area)) return $"0x{value:X}";
            return value.ToString(CultureInfo.InvariantCulture);
        }

        private static string StartStringForArea(char area, int start)
        {
            area = char.ToUpperInvariant(area);
            if (HexAreas.Contains(area)) return start.ToString("X");
            return start.ToString(CultureInfo.InvariantCulture);
        }

        private void UpdateNormalizedBox()
        {
            if (_spec == null) { txtNormalized.Text = string.Empty; return; }
            if (cboSpecMode.SelectedIndex == 1)
            {
                if (_lastExcelRows.Count > 0)
                {
                    var dict = new Dictionary<char, SortedSet<string>>();
                    foreach (var row in _lastExcelRows)
                    {
                        var kv = ParseKeyValues(row);
                        if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                        if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;
                        char area = dev.Trim().ToUpperInvariant()[0];
                        if (!dict.TryGetValue(area, out var set)) { set = new SortedSet<string>(); dict[area] = set; }
                        set.Add(addr.Trim());
                    }
                    txtNormalized.Text = string.Join("&", dict.OrderBy(p => AreaOrderKey(p.Key)).Select(p => $"{p.Key}:{string.Join(",", p.Value)}"));
                }
                else txtNormalized.Text = txtInput.Text;
            }
            else
            {
                txtNormalized.Text = string.Join("&",
                    _spec.OrderBy(s => AreaOrderKey(s.Area)).ThenBy(s => s.StartHex)
                         .Select(s => $"{s.Area}:{StartStringForArea(s.Area, s.StartHex)}:{s.CountOut}"));
            }
        }

        private void FillAreaAndPages()
        {
            cboArea.Items.Clear();
            foreach (char area in _map.Segments.Select(s => s.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                cboArea.Items.Add(area);
            if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
            else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) => RefreshPages();
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) => ShowSelectedPage();

        private class PageItem { public int Start; public string Text; public override string ToString() => Text; }

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_map == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _map.Segments.Where(m => m.Area == area).ToList();
            var pages = new SortedSet<int>();
            foreach (var r in ranges)
            {
                int start = r.StartHex;
                int endInc = r.StartHex + r.Count - 1;
                int pageStart = start & ~0xFF;
                int pageEnd = endInc & ~0xFF;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
            {
                string label = HexAreas.Contains(area) ? $"0x{p:X5} - 0x{p + 0xFF:X5}" : $"{p} - {p + 0xFF}";
                lstPages.Items.Add(new PageItem { Start = p, Text = label });
            }
            lblPageInfo.Text = pages.Count > 0 ? $"페이지 {pages.Count}개" : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_map == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var item = lstPages.SelectedItem as PageItem; if (item == null) return;
            int pageStart = item.Start;
            var counts = new byte[256];
            foreach (var s in _map.Segments.Where(mg => char.ToUpperInvariant(mg.Area) == area))
            {
                int sAddr = Math.Max(s.StartHex, pageStart);
                int eAddr = Math.Min(s.StartHex + s.Count - 1, pageStart + 0xFF);
                if (eAddr < sAddr) continue;
                for (int addr = sAddr; addr <= eAddr; addr++)
                {
                    int idx = addr - pageStart;
                    if (idx >= 0 && idx < 256 && counts[idx] < 255) counts[idx]++;
                }
            }
            bool isHex = HexAreas.Contains(area);
            pageView.SetPage(area, pageStart, counts, isHex);
        }

        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }
    }

    public class Entry { public char Area; public int Start; public int EndInc; public int Span; public bool HasLength; public Entry(char area,int start,int endInc,int span,bool hasLength){Area=area;Start=start;EndInc=endInc;Span=span;HasLength=hasLength;} }
    public class SpanPiece { public int Start; public int TotalSpan; }
    public class Segment { public char Area; public int StartHex; public int Count; public Segment(char area,int startHex,int used){Area=area;StartHex=startHex;Count=used;} }
    public class MemoryMap { public List<Segment> Segments { get; } = new List<Segment>(); }
    public class SpecRange { public char Area; public int StartHex; public int CountOut; public SpecRange(char area,int start,int countOut){Area=area;StartHex=start;CountOut=countOut;} }
}