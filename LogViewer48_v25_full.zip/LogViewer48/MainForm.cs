using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogViewer48
{
    public enum ActionKind { Other, Start, Success, Fail, End }

    public class LogRow
    {
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Device { get; set; }
        public string Var { get; set; }
        public string SourceFile { get; set; }
        public long LineIndex { get; set; }
        public double? DurationSeconds { get; set; }
        public bool IsOneLiner { get; set; }
        public ActionKind Kind { get; set; }
    }

    public class CombinedRow
    {
        public string Var { get; set; }
        public DateTime StartTs { get; set; }
        public DateTime? SuccessTs { get; set; }
        public DateTime? EndTs { get; set; }
        public string Status { get; set; } // Success / NG / Unknown
        public double? DurationSeconds { get; set; }
        public string SourceFile { get; set; }
        public int StartIdx { get; set; }
        public int EndIdx { get; set; }
    }

    public class MainForm : Form
    {
        TextBox txtFolder;
        Button btnBrowse;
        TextBox txtPrefix;
        Button btnList;
        Button btnOpen;

        CheckBox chkBROneLiners;
        CheckBox chkCombine;
        Label lblThresh;
        NumericUpDown numThreshold;
        Label lblSearch;
        TextBox txtSearchVar;
        Button btnSearch, btnClear;

        SplitContainer split;
        Panel leftPanelTop;
        ListBox lstFiles;

        Panel panelRight;
        DataGridView gridLines;
        DataGridView gridMerged;
        StatusStrip statusStrip;
        ToolStripStatusLabel statusLabel;
        ToolStripProgressBar statusProgress;

        readonly object locker = new object();
        readonly List<LogRow> rows = new List<LogRow>();
        List<LogRow> viewRows = new List<LogRow>();
        readonly BindingSource bsLines = new BindingSource();

        List<CombinedRow> mergedRows = new List<CombinedRow>();
        readonly BindingSource bsMerged = new BindingSource();

        readonly Dictionary<string, bool> sortAscLines = new Dictionary<string, bool>();
        readonly Dictionary<string, bool> sortAscMerged = new Dictionary<string, bool>();

        readonly Regex headRx = new Regex(
            @"^(?<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+\[(?<level>[^\]]+)\]\s+(?<rest>.*)$",
            RegexOptions.Compiled);

        readonly Regex bracketRx = new Regex(@"^\[(?<tok>[^\]]+)\]\s*", RegexOptions.Compiled);

        int colIndexTimestampLines;
        string currentFile = null;

        public MainForm()
        {
            Text = "EIF Log Viewer (.NET Framework 4.8)";
            Width = 1400;
            Height = 860;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(6), AutoSize = false, WrapContents = false };
            txtFolder = new TextBox { Width = 420 };
            btnBrowse = new Button { Text = "경로...", Width = 70 };
            txtPrefix = new TextBox { Width = 120, Text = "RollMapElm" };
            btnList = new Button { Text = "불러오기", Width = 90 };
            chkBROneLiners = new CheckBox { Text = "BR_ 1줄만", AutoSize = true, Margin = new Padding(8, 12, 0, 0) };
            chkCombine = new CheckBox { Text = "BR 결합 보기", AutoSize = true, Margin = new Padding(8, 12, 0, 0), Checked = true };
            lblThresh = new Label { Text = "소요(초) ≥", AutoSize = true, Margin = new Padding(12, 12, 4, 0) };
            numThreshold = new NumericUpDown { Width = 80, DecimalPlaces = 3, Increment = 0.100M, Minimum = 0, Maximum = 3600, Value = 5.000M };
            lblSearch = new Label { Text = "변수 검색:", AutoSize = true, Margin = new Padding(12, 12, 4, 0) };
            txtSearchVar = new TextBox { Width = 160 };
            btnSearch = new Button { Text = "검색", Width = 60 };
            btnClear = new Button { Text = "초기화", Width = 60 };

            top.Controls.Add(new Label { Text = "폴더:", AutoSize = true, Margin = new Padding(0, 12, 4, 0) });
            top.Controls.Add(txtFolder);
            top.Controls.Add(btnBrowse);
            top.Controls.Add(new Label { Text = "Prefix:", AutoSize = true, Margin = new Padding(12, 12, 4, 0) });
            top.Controls.Add(txtPrefix);
            top.Controls.Add(btnList);
            top.Controls.Add(chkBROneLiners);
            top.Controls.Add(chkCombine);
            top.Controls.Add(lblThresh);
            top.Controls.Add(numThreshold);
            top.Controls.Add(lblSearch);
            top.Controls.Add(txtSearchVar);
            top.Controls.Add(btnSearch);
            top.Controls.Add(btnClear);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 240, IsSplitterFixed = False, FixedPanel = FixedPanel.Panel1 };
            leftPanelTop = new Panel { Dock = DockStyle.Top, Height = 40 };
            btnOpen = new Button { Text = "열기", Dock = DockStyle.Right, Width = 60 };
            var leftInfo = new Label { Text = "날짜(파일) 선택 후 '열기'", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            leftPanelTop.Controls.Add(btnOpen);
            leftPanelTop.Controls.Add(leftInfo);
            lstFiles = new ListBox { Dock = DockStyle.Fill, IntegralHeight = False };
            split.Panel1.Controls.Add(lstFiles);
            split.Panel1.Controls.Add(leftPanelTop);

            panelRight = new Panel { Dock = DockStyle.Fill };
            gridLines = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoGenerateColumns = false,
                AllowUserToOrderColumns = true,
                Visible = false
            };
            var colTs = new DataGridViewTextBoxColumn { HeaderText = "날짜시간", DataPropertyName = "Timestamp", Width = 200, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd HH:mm:ss.fff" } };
            var colLevel = new DataGridViewTextBoxColumn { HeaderText = "레벨", DataPropertyName = "Level", Width = 80, SortMode = DataGridViewColumnSortMode.Programmatic };
            var colDevice = new DataGridViewTextBoxColumn { HeaderText = "장비", DataPropertyName = "Device", Width = 180, SortMode = DataGridViewColumnSortMode.Programmatic };
            var colVar = new DataGridViewTextBoxColumn { HeaderText = "변수", DataPropertyName = "Var", Width = 360, SortMode = DataGridViewColumnSortMode.Programmatic };
            var colDur = new DataGridViewTextBoxColumn { HeaderText = "소요(초)", DataPropertyName = "DurationSeconds", Width = 110, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "N3" } };
            gridLines.Columns.AddRange(new DataGridViewColumn[] { colTs, colLevel, colDevice, colVar, colDur });
            colIndexTimestampLines = 0;

            gridMerged = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoGenerateColumns = false,
                AllowUserToOrderColumns = true,
                Visible = true
            };
            var mStart = new DataGridViewTextBoxColumn { HeaderText = "시작", DataPropertyName = "StartTs", Width = 200, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd HH:mm:ss.fff" } };
            var mVar = new DataGridViewTextBoxColumn { HeaderText = "변수(BR_)", DataPropertyName = "Var", Width = 360, SortMode = DataGridViewColumnSortMode.Programmatic };
            var mStatus = new DataGridViewTextBoxColumn { HeaderText = "결과", DataPropertyName = "Status", Width = 100, SortMode = DataGridViewColumnSortMode.Programmatic };
            var mEnd = new DataGridViewTextBoxColumn { HeaderText = "종료", DataPropertyName = "EndTs", Width = 200, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd HH:mm:ss.fff" } };
            var mDur = new DataGridViewTextBoxColumn { HeaderText = "소요(초)", DataPropertyName = "DurationSeconds", Width = 110, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "N3" } };
            gridMerged.Columns.AddRange(new DataGridViewColumn[] { mStart, mVar, mStatus, mEnd, mDur });

            panelRight.Controls.Add(gridMerged);
            panelRight.Controls.Add(gridLines);
            split.Panel2.Controls.Add(panelRight);

            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel("대기 중");
            statusProgress = new ToolStripProgressBar() { Style = ProgressBarStyle.Blocks, Visible = false };
            statusStrip.Items.Add(statusLabel);
            statusStrip.Items.Add(new ToolStripStatusLabel() { Spring = true });
            statusStrip.Items.Add(statusProgress);

            Controls.Add(split);
            Controls.Add(top);
            Controls.Add(statusStrip);

            btnBrowse.Click += (s, e) => BrowseFolder();
            btnList.Click += (s, e) => BuildFileListOnly();
            btnOpen.Click += async (s, e) => await LoadSelectedFileAsync();
            btnSearch.Click += (s, e) => ApplyFilterAndBind();
            btnClear.Click += (s, e) => { txtSearchVar.Text = ""; ApplyFilterAndBind(); };
            numThreshold.ValueChanged += (s, e) => { gridLines.Refresh(); gridMerged.Refresh(); };
            chkBROneLiners.CheckedChanged += (s, e) => ApplyFilterAndBind();
            chkCombine.CheckedChanged += (s, e) => ToggleMode();

            lstFiles.DoubleClick += async (s, e) => await LoadSelectedFileAsync();

            gridLines.CellDoubleClick += GridLines_CellDoubleClick;
            gridLines.ColumnHeaderMouseClick += GridLines_ColumnHeaderMouseClick;
            gridLines.RowPrePaint += GridLines_RowPrePaint;

            gridMerged.CellDoubleClick += GridMerged_CellDoubleClick;
            gridMerged.ColumnHeaderMouseClick += GridMerged_ColumnHeaderMouseClick;
            gridMerged.RowPrePaint += GridMerged_RowPrePaint;
        }

        private void ToggleMode()
        {
            gridMerged.Visible = chkCombine.Checked;
            gridLines.Visible = !chkCombine.Checked;
        }

        private void GridMerged_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= gridMerged.Rows.Count) return;
            var row = gridMerged.Rows[e.RowIndex].DataBoundItem as CombinedRow;
            if (row == null) return;

            var list = rows.Where(r => string.Equals(r.Var, row.Var, StringComparison.OrdinalIgnoreCase)
                                     && r.Timestamp >= row.StartTs
                                     && (!row.EndTs.HasValue || r.Timestamp <= row.EndTs.Value))
                           .OrderBy(r => r.Timestamp).ThenBy(r => r.LineIndex).ToList();

            var sb = new StringBuilder();
            foreach (var h in list)
                sb.Append(ReadBlock(row.SourceFile, (int)h.LineIndex));
            ShowText(sb.ToString(), $"{row.Var} 결합 상세 ({row.StartTs:HH:mm:ss.fff} ~ {(row.EndTs.HasValue ? row.EndTs.Value.ToString("HH:mm:ss.fff") : "…")})");
        }

        private string ReadBlock(string file, int headerIdx)
        {
            var fp = Path.Combine(txtFolder.Text, file);
            var sb = new StringBuilder();
            int current = 0;
            using (var fs = new FileStream(fp, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs, System.Text.Encoding.UTF8, true, 1024 * 64))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (current < headerIdx) { current++; continue; }
                    if (current == headerIdx)
                    {
                        sb.AppendLine(line);
                        current++;
                        break;
                    }
                    current++;
                }
                while ((line = sr.ReadLine()) != null)
                {
                    if (headRx.IsMatch(line)) break;
                    sb.AppendLine(line);
                }
            }
            return sb.ToString();
        }

        private void GridMerged_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= gridMerged.Rows.Count) return;
            var row = gridMerged.Rows[e.RowIndex].DataBoundItem as CombinedRow;
            if (row == null) return;
            var th = (double)numThreshold.Value;
            gridMerged.Rows[e.RowIndex].DefaultCellStyle.BackColor =
                (row.DurationSeconds.HasValue && row.DurationSeconds.Value >= th)
                ? Color.FromArgb(255, 255, 220, 220) : Color.White;
        }

        private void GridMerged_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var col = gridMerged.Columns[e.ColumnIndex];
            var prop = col.DataPropertyName;
            bool asc;
            if (!sortAscMerged.TryGetValue(prop, out asc)) asc = true; else asc = !asc;
            sortAscMerged[prop] = asc;

            IEnumerable<CombinedRow> sorted;
            switch (prop)
            {
                case "StartTs": sorted = asc ? mergedRows.OrderBy(r => r.StartTs) : mergedRows.OrderByDescending(r => r.StartTs); break;
                case "Var": sorted = asc ? mergedRows.OrderBy(r => r.Var) : mergedRows.OrderByDescending(r => r.Var); break;
                case "Status": sorted = asc ? mergedRows.OrderBy(r => r.Status) : mergedRows.OrderByDescending(r => r.Status); break;
                case "EndTs": sorted = asc ? mergedRows.OrderBy(r => r.EndTs) : mergedRows.OrderByDescending(r => r.EndTs); break;
                case "DurationSeconds": sorted = asc ? mergedRows.OrderBy(r => r.DurationSeconds ?? double.MaxValue) : mergedRows.OrderByDescending(r => r.DurationSeconds ?? -1); break;
                default: sorted = mergedRows; break;
            }
            bsMerged.DataSource = sorted.ToList();
        }

        private void GridLines_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= gridLines.Rows.Count) return;
            var row = gridLines.Rows[e.RowIndex].DataBoundItem as LogRow;
            if (row == null) return;
            if (e.ColumnIndex == colIndexTimestampLines)
            {
                var fp = Path.Combine(txtFolder.Text, row.SourceFile);
                try { Process.Start(new ProcessStartInfo(fp) { UseShellExecute = true }); }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
            else
            {
                ShowSingleBlockStream(row.SourceFile, (int)row.LineIndex, $"{row.Var} 현재 블록");
            }
        }

        private void GridLines_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= gridLines.Rows.Count) return;
            var row = gridLines.Rows[e.RowIndex].DataBoundItem as LogRow;
            if (row == null) return;
            var th = (double)numThreshold.Value;
            gridLines.Rows[e.RowIndex].DefaultCellStyle.BackColor =
                (row.DurationSeconds.HasValue && row.DurationSeconds.Value >= th)
                ? Color.FromArgb(255, 255, 220, 220) : Color.White;
        }

        private void GridLines_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var col = gridLines.Columns[e.ColumnIndex];
            var prop = col.DataPropertyName;
            bool asc;
            if (!sortAscLines.TryGetValue(prop, out asc)) asc = true; else asc = !asc;
            sortAscLines[prop] = asc;

            IEnumerable<LogRow> sorted;
            switch (prop)
            {
                case "Timestamp": sorted = asc ? viewRows.OrderBy(r => r.Timestamp) : viewRows.OrderByDescending(r => r.Timestamp); break;
                case "Level": sorted = asc ? viewRows.OrderBy(r => r.Level) : viewRows.OrderByDescending(r => r.Level); break;
                case "Device": sorted = asc ? viewRows.OrderBy(r => r.Device) : viewRows.OrderByDescending(r => r.Device); break;
                case "Var": sorted = asc ? viewRows.OrderBy(r => r.Var) : viewRows.OrderByDescending(r => r.Var); break;
                case "DurationSeconds": sorted = asc ? viewRows.OrderBy(r => r.DurationSeconds ?? double.MaxValue) : viewRows.OrderByDescending(r => r.DurationSeconds ?? -1); break;
                default: sorted = viewRows; break;
            }
            BindLines(sorted.ToList());
            col.HeaderText = col.HeaderText.Split(' ')[0] + (asc ? " ▲" : " ▼");
        }

        private void SetBusy(string text, bool busy)
        {
            statusLabel.Text = text;
            statusProgress.Visible = busy;
            statusProgress.Style = busy ? ProgressBarStyle.Marquee : ProgressBarStyle.Blocks;
            btnList.Enabled = !busy;
            btnOpen.Enabled = !busy;
            btnBrowse.Enabled = !busy;
            txtFolder.Enabled = !busy;
            txtPrefix.Enabled = !busy;
            Cursor = busy ? Cursors.AppStarting : Cursors.Default;
        }

        private void BrowseFolder()
        {
            using (var f = new FolderBrowserDialog())
            {
                if (f.ShowDialog(this) == DialogResult.OK)
                    txtFolder.Text = f.SelectedPath;
            }
        }

        private void BuildFileListOnly()
        {
            lstFiles.Items.Clear();
            currentFile = null;
            lock (locker) { rows.Clear(); }
            bsLines.DataSource = null;
            bsMerged.DataSource = null;
            gridLines.Rows.Clear();
            gridMerged.Rows.Clear();

            if (string.IsNullOrWhiteSpace(txtFolder.Text) || !Directory.Exists(txtFolder.Text))
            {
                MessageBox.Show("올바른 폴더를 선택하세요.");
                return;
            }

            var prefix = txtPrefix.Text?.Trim() ?? "";
            var files = Directory.GetFiles(txtFolder.Text, $"{prefix}_*.log")
                .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
                .ToList();
            foreach (var f in files)
                lstFiles.Items.Add(Path.GetFileName(f));
            statusLabel.Text = $"{files.Count}개 파일 발견. 날짜(파일) 선택 후 '열기'를 누르세요.";
        }

        private async Task LoadSelectedFileAsync()
        {
            if (lstFiles.SelectedItem == null) return;
            var fname = lstFiles.SelectedItem.ToString();
            var full = Path.Combine(txtFolder.Text, fname);
            await LoadOneFileAsync(full);
        }

        private async Task LoadOneFileAsync(string file)
        {
            SetBusy("파일 읽는 중…", true);
            try
            {
                currentFile = Path.GetFileName(file);
                lock (locker) { rows.Clear(); }
                await Task.Run(async () => { await ParseFileAsync(file); });
                ApplyFilterAndBind();
                statusLabel.Text = $"완료: {Path.GetFileName(file)}  라인 {rows.Count}";
            }
            catch (Exception ex)
            {
                statusLabel.Text = "오류 발생";
                MessageBox.Show(ex.ToString(), "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetBusy(statusLabel.Text, false);
            }
        }

        private void ApplyFilterAndBind()
        {
            IEnumerable<LogRow> q = rows;

            if (chkBROneLiners.Checked)
                q = q.Where(r => (r.Var ?? string.Empty).StartsWith("BR_", StringComparison.OrdinalIgnoreCase) && r.IsOneLiner);

            var s = (txtSearchVar.Text ?? "").Trim();
            if (!string.IsNullOrEmpty(s))
                q = q.Where(r => (r.Var ?? "").IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0);

            viewRows = q.OrderBy(r => r.Timestamp).ThenBy(r=>r.LineIndex).ToList();
            BindLines(viewRows);

            var forMerged = rows.AsEnumerable();
            if (!string.IsNullOrEmpty(s))
                forMerged = forMerged.Where(r => (r.Var ?? "").IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0);
            mergedRows = BuildMerged(forMerged.OrderBy(r=>r.Timestamp).ThenBy(r=>r.LineIndex));
            bsMerged.DataSource = mergedRows;
            gridMerged.DataSource = bsMerged;

            ToggleMode();
        }

        private void BindLines(List<LogRow> data)
        {
            for (int i = 0; i < data.Count; i++)
            {
                if (i < data.Count - 1)
                {
                    var dt = (data[i + 1].Timestamp - data[i].Timestamp).TotalSeconds;
                    data[i].DurationSeconds = Math.Max(0, Math.Round(dt, 3));
                }
                else data[i].DurationSeconds = null;
            }
            bsLines.DataSource = data;
            gridLines.DataSource = bsLines;
            gridLines.Refresh();
        }

        private ActionKind DetectKind(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return ActionKind.Other;
            var t = text.ToLowerInvariant();
            if (Regex.IsMatch(t, @"(^|\b)start\b|:\s*start\b")) return ActionKind.Start;
            if (t.Contains("success") || t.Contains("succes") || Regex.IsMatch(t, @"\bok\b")) return ActionKind.Success;
            if (Regex.IsMatch(t, @"\bng\b|\bfail(ed)?\b|\berror\b")) return ActionKind.Fail;
            if (Regex.IsMatch(t, @"(^|[\s\-])end\b")) return ActionKind.End;
            return ActionKind.Other;
        }

        private async Task ParseFileAsync(string file)
        {
            using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs, System.Text.Encoding.UTF8, true, 1024 * 64))
            {
                string line;
                long idx = 0;
                var source = Path.GetFileName(file);

                while ((line = await sr.ReadLineAsync()) != null)
                {
                    var m = headRx.Match(line);
                    if (!m.Success) { idx++; continue; }
                    DateTime ts;
                    if (!DateTime.TryParse(m.Groups["dt"].Value, out ts)) { idx++; continue; }
                    var level = m.Groups["level"].Value;
                    var rest = m.Groups["rest"].Value;

                    var tokens = new List<string>();
                    string tmp = rest;
                    int guard = 0;
                    while (guard < 8) // up to 8 bracket tokens
                    {
                        var bm = bracketRx.Match(tmp);
                        if (!bm.Success) break;
                        tokens.Add(bm.Groups["tok"].Value);
                        tmp = tmp.Substring(bm.Length);
                        guard++;
                    }

                    string device = null, varName = null;
                    if (tokens.Count >= 2) { device = tokens[0]; varName = tokens[1]; }
                    else if (tokens.Count == 1) { varName = tokens[0]; }
                    if (string.IsNullOrEmpty(device))
                    {
                        var n = Path.GetFileNameWithoutExtension(file);
                        var cut = n.LastIndexOf('_');
                        device = cut > 0 ? n.Substring(0, cut) : n;
                    }
                    if (string.IsNullOrEmpty(varName)) varName = device ?? "GLOBAL";

                    var kind = DetectKind(tmp);
                    bool isOne = (kind == ActionKind.Start) && !varName.StartsWith("BR_", StringComparison.OrdinalIgnoreCase);

                    lock (locker)
                    {
                        rows.Add(new LogRow
                        {
                            Timestamp = ts,
                            Level = level,
                            Device = device,
                            Var = varName,
                            SourceFile = source,
                            LineIndex = idx,
                            IsOneLiner = isOne,
                            Kind = kind
                        });
                    }
                    idx++;
                }
            }
        }

        private List<CombinedRow> BuildMerged(IEnumerable<LogRow> ordered)
        {
            var list = new List<CombinedRow>();
            var open = new Dictionary<string, CombinedRow>(StringComparer.OrdinalIgnoreCase);

            foreach (var r in ordered)
            {
                if (string.IsNullOrEmpty(r.Var) || !r.Var.StartsWith("BR_", StringComparison.OrdinalIgnoreCase))
                    continue;

                switch (r.Kind)
                {
                    case ActionKind.Start:
                        if (open.TryGetValue(r.Var, out var prev))
                        {
                            if (!prev.EndTs.HasValue)
                            {
                                prev.EndTs = prev.SuccessTs ?? prev.StartTs;
                                prev.DurationSeconds = Math.Max(0, Math.Round((prev.EndTs.Value - prev.StartTs).TotalSeconds, 3));
                                list.Add(prev);
                            }
                        }
                        var cur = new CombinedRow { Var = r.Var, StartTs = r.Timestamp, Status = "Unknown", SourceFile = r.SourceFile, StartIdx = (int)r.LineIndex, EndIdx = -1 };
                        open[r.Var] = cur;
                        break;

                    case ActionKind.Success:
                        if (open.TryGetValue(r.Var, out var sOpen))
                        {
                            sOpen.SuccessTs = r.Timestamp;
                            sOpen.Status = "Success";
                        }
                        else
                        {
                            var s = new CombinedRow { Var = r.Var, StartTs = r.Timestamp, SuccessTs = r.Timestamp, Status = "Success", SourceFile = r.SourceFile, StartIdx = (int)r.LineIndex, EndIdx = -1 };
                            list.Add(s);
                        }
                        break;

                    case ActionKind.Fail:
                        if (open.TryGetValue(r.Var, out var fOpen))
                        {
                            fOpen.SuccessTs = r.Timestamp;
                            fOpen.Status = "NG";
                        }
                        else
                        {
                            var f = new CombinedRow { Var = r.Var, StartTs = r.Timestamp, SuccessTs = r.Timestamp, Status = "NG", SourceFile = r.SourceFile, StartIdx = (int)r.LineIndex, EndIdx = -1 };
                            list.Add(f);
                        }
                        break;

                    case ActionKind.End:
                        if (open.TryGetValue(r.Var, out var eOpen))
                        {
                            eOpen.EndTs = r.Timestamp;
                            eOpen.EndIdx = (int)r.LineIndex;
                            if (eOpen.Status == "Unknown") eOpen.Status = eOpen.SuccessTs.HasValue ? "Success" : "Unknown";
                            eOpen.DurationSeconds = Math.Max(0, Math.Round((eOpen.EndTs.Value - eOpen.StartTs).TotalSeconds, 3));
                            list.Add(eOpen);
                            open.Remove(r.Var);
                        }
                        else
                        {
                            var e = new CombinedRow { Var = r.Var, StartTs = r.Timestamp, EndTs = r.Timestamp, Status = "Unknown", SourceFile = r.SourceFile, StartIdx = (int)r.LineIndex, EndIdx = (int)r.LineIndex, DurationSeconds = 0 };
                            list.Add(e);
                        }
                        break;
                }
            }

            foreach (var kv in open)
            {
                var v = kv.Value;
                v.EndTs = v.SuccessTs ?? v.StartTs;
                v.DurationSeconds = Math.Max(0, Math.Round((v.EndTs.Value - v.StartTs).TotalSeconds, 3));
                list.Add(v);
            }

            return list.OrderBy(x => x.StartTs).ToList();
        }

        private void ShowSingleBlockStream(string file, int headerIdx, string title)
        {
            try
            {
                var fp = Path.Combine(txtFolder.Text, file);
                var sb = new StringBuilder();
                int current = 0;
                using (var fs = new FileStream(fp, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, System.Text.Encoding.UTF8, true, 1024 * 64))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (current < headerIdx) { current++; continue; }
                        if (current == headerIdx)
                        {
                            sb.AppendLine(line);
                            current++;
                            break;
                        }
                        current++;
                    }
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (headRx.IsMatch(line)) break;
                        sb.AppendLine(line);
                    }
                }
                ShowText(sb.ToString(), title);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "블록 표시 오류");
            }
        }

        private void ShowText(string text, string title)
        {
            var frm = new Form { Text = title, Width = 1100, Height = 780 };
            var tb = new TextBox
            {
                Multiline = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                ReadOnly = true,
                Font = new System.Drawing.Font("Consolas", 10),
                Text = text
            };
            frm.Controls.Add(tb);
            frm.Show();
        }
    }
}
