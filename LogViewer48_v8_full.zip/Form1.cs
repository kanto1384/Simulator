
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;

namespace LogViewer48
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Setup DataGridView and other UI elements here.
            // v7 improvements: duration calc, bracket handling, memory optimization.
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            // Load .log files, parse headers, bind to grid.
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string colName = dataGridView1.Columns[e.ColumnIndex].Name;
                if (colName == "Date")
                {
                    string filePath = dataGridView1.Rows[e.RowIndex].Cells["FilePath"].Value.ToString();
                    if (File.Exists(filePath))
                    {
                        Process.Start(filePath);
                    }
                }
                else
                {
                    // Open detail popup showing full log block
                    var popup = new DetailForm("Full log block here...");
                    popup.ShowDialog();
                }
            }
        }
    }
}
