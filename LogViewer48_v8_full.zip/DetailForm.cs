
using System;
using System.Windows.Forms;

namespace LogViewer48
{
    public partial class DetailForm : Form
    {
        private string logContent;
        public DetailForm(string content)
        {
            logContent = content;
            InitializeComponent();
        }

        private void DetailForm_Load(object sender, EventArgs e)
        {
            textBox1.Text = logContent;
        }
    }
}
