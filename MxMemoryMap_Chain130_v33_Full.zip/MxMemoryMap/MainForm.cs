using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<SpecRange> _spec = new List<SpecRange>();
        private List<string> _lastExcelRows = new List<string>();

        // 영역별 표시/파싱 규칙
        private static readonly HashSet<char> HexAreas = new HashSet<char>(new[] { 'B', 'W', 'X', 'Y' });
        private static readonly HashSet<char> DecAreas = new HashSet<char>(new[] { 'M', 'D', 'R', 'L', 'Z' }); // ZR 포함(Z)

        public MainForm()
        {
            InitializeComponent();

            txtInput.Text = "W:1000,1082";

            AllowDrop = true;
            DragEnter += MainForm_DragEnter;
            DragDrop += MainForm_DragDrop;

            cboSpecMode.Items.AddRange(new object[] { "최적화(연결체인 130)", "원본 주소 목록" });
            cboSpecMode.SelectedIndex = 0;
            cboSpecMode.SelectedIndexChanged += (_, __) => UpdateNormalizedBox();
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Any(f => Path.GetExtension(f).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)))
                { e.Effect = DragDropEffects.Copy; return; }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;

                var allRows = new List<string>();
                int used = 0, skipped = 0;
                foreach (var file in files)
                {
                    if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)) { skipped++; continue; }
                    var sheet = SimpleXlsx.FindSheetByName(file, "VARIABLES");
                    if (sheet == null) { skipped++; continue; }
                    var rows = SimpleXlsx.ReadColumnStrings(file, sheet.Target, "H");
                    if (rows.Count == 0) { skipped++; continue; }
                    allRows.AddRange(rows);
                    used++;
                }

                if (allRows.Count == 0)
                {
                    MessageBox.Show("가져올 데이터가 없습니다. (.xlsx / VARIABLES 시트 / H열)");
                    return;
                }

                _lastExcelRows = allRows;
                lblSheetInfo.Text = $"VARIABLES/H  Files={used}, Skipped={skipped}";

                BuildFromExcelRows(allRows);
            }
            catch (Exception ex)
            {
                MessageBox.Show("엑셀 처리 오류: " + ex.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                var dict = ParseAreaAddressList(txtInput.Text ?? string.Empty);
                BuildFromAreaAddressDict(dict, sourceLabel: "(수동 입력)");
                _lastExcelRows.Clear();
            }
            catch (Exception ex)
            {
                txtOutput.Text = "[에러] " + ex.Message;
            }
        }

        private const int MaxGap = 130; // 두 주소 간 차 ≤ 130 → 같은 체인

        private void BuildFromExcelRows(List<string> rows)
        {
            var dict = new Dictionary<char, SortedSet<int>>();
            foreach (var row in rows)
            {
                var kv = ParseKeyValues(row);
                if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;

                string devTrim = dev.Trim().ToUpperInvariant();
                char areaChar = devTrim[0]; // 'ZR' → 'Z'
                if (!TryParseByArea(areaChar, addr, out int a)) continue;

                if (!dict.TryGetValue(areaChar, out var set)) { set = new SortedSet<int>(); dict[areaChar] = set; }
                set.Add(a);
            }
            BuildFromAreaAddressDict(dict.ToDictionary(k => k.Key, v => v.Value.ToList()), "Excel");
        }

        private void BuildFromAreaAddressDict(Dictionary<char, List<int>> areaAddrs, string sourceLabel)
        {
            var map = new MemoryMap();
            var spec = new List<SpecRange>();
            var sb = new StringBuilder();

            sb.AppendLine($"[원본 주소 개수]  {string.Join(\"  \", areaAddrs.OrderBy(p=>p.Key).Select(p=>$\"{p.Key}:{p.Value.Count}\"))}");
            sb.AppendLine();

            foreach (var kv in areaAddrs.OrderBy(p => AreaOrderKey(p.Key)))
            {
                char area = kv.Key;
                var addrs = kv.Value.Distinct().OrderBy(x => x).ToList();
                if (addrs.Count == 0) continue;
                sb.AppendLine($"[{area}] 입력주소: {string.Join(\",\", addrs.Select(x => FormatByArea(area, x)))}");

                int start = addrs[0];
                int last = start;
                for (int i = 1; i < addrs.Count; i++)
                {
                    int a = addrs[i];
                    if (a - last <= MaxGap) { last = a; continue; }
                    int used = last - start + 1;
                    spec.Add(new SpecRange(area, start, used + 1));
                    map.Segments.Add(new Segment(area, start, used));
                    sb.AppendLine($\" -> 체인: {FormatByArea(area, start)} ~ {FormatByArea(area, last)}  used={used}  count_out={used + 1}\");
                    start = last = a;
                }
                int usedLast = last - start + 1;
                spec.Add(new SpecRange(area, start, usedLast + 1));
                map.Segments.Add(new Segment(area, start, usedLast));
                sb.AppendLine($\" -> 체인: {FormatByArea(area, start)} ~ {FormatByArea(area, last)}  used={usedLast}  count_out={usedLast + 1}\");
                sb.AppendLine();
            }

            _map = map;
            _spec = spec;

            txtOutput.Text = $"[소스] {sourceLabel}\r\n" + sb.ToString();
            UpdateNormalizedBox();
            FillAreaAndPages();
        }

        private static Dictionary<char, List<int>> ParseAreaAddressList(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) throw new ArgumentException("입력이 비어 있습니다.");
            if (s.StartsWith("MEMORY=", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);

            var dict = new Dictionary<char, List<int>>();
            foreach (var part in s.Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = part.Trim();
                int colon = p.IndexOf(':');
                if (colon <= 0) throw new FormatException($"형식 오류: '{p}' (예: W:1000,1082)");
                string areaToken = p.Substring(0, colon).Trim().ToUpperInvariant();
                char area = areaToken[0]; // 'ZR' → 'Z'
                var addrList = p.Substring(colon + 1).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var token in addrList)
                {
                    if (!TryParseByArea(area, token.Trim(), out int a)) continue;
                    if (!dict.TryGetValue(area, out var list)) { list = new List<int>(); dict[area] = list; }
                    list.Add(a);
                }
            }
            return dict.ToDictionary(k => k.Key, v => v.Value.Distinct().OrderBy(x => x).ToList());
        }

        private void UpdateNormalizedBox()
        {
            if (cboSpecMode.SelectedIndex == 1)
            {
                if (_lastExcelRows.Count > 0)
                {
                    var dict = new Dictionary<char, SortedSet<int>>();
                    foreach (var row in _lastExcelRows)
                    {
                        var kv = ParseKeyValues(row);
                        if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                        if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;
                        char area = dev.Trim().ToUpperInvariant()[0];
                        if (!TryParseByArea(area, addr, out int a)) continue;
                        if (!dict.TryGetValue(area, out var set)) { set = new SortedSet<int>(); dict[area] = set; }
                        set.Add(a);
                    }
                    txtNormalized.Text = string.Join("&", dict.OrderBy(p => AreaOrderKey(p.Key)).Select(p => $"{p.Key}:{string.Join(\",\", p.Value.Select(x => FormatByArea(p.Key, x).Replace(\"0x\",\"\")))}"));
                }
                else
                {
                    txtNormalized.Text = txtInput.Text;
                }
            }
            else
            {
                txtNormalized.Text = string.Join("&", _spec.OrderBy(p => AreaOrderKey(p.Area)).ThenBy(p => p.StartHex).Select(p => $"{p.Area}:{FormatByArea(p.Area, p.StartHex).Replace(\"0x\",\"\")}:{p.CountOut}"));
            }
        }

        private void FillAreaAndPages()
        {
            cboArea.Items.Clear();
            foreach (char area in _map.Segments.Select(s => s.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                cboArea.Items.Add(area);
            if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
            else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) => RefreshPages();
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) => ShowSelectedPage();

        private class PageItem
        {
            public int Start;
            public string Text;
            public override string ToString() => Text;
        }

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_map == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _map.Segments.Where(m => m.Area == area).ToList();

            var pages = new SortedSet<int>();
            foreach (var r in ranges)
            {
                int start = r.StartHex;
                int endIncl = r.StartHex + r.Count - 1;
                int pageStart = start & ~0xFF;
                int pageEnd = endIncl & ~0xFF;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
            {
                string label = HexAreas.Contains(area)
                    ? $"0x{p:X5} - 0x{p + 0xFF:X5}"
                    : $"{p} - {p + 0xFF}";
                lstPages.Items.Add(new PageItem { Start = p, Text = label });
            }
            lblPageInfo.Text = pages.Count > 0 ? $"페이지 {pages.Count}개" : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_map == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var item = lstPages.SelectedItem as PageItem;
            if (item == null) return;
            int pageStart = item.Start;

            var counts = new byte[256];
            foreach (var s in _map.Segments.Where(mg => char.ToUpperInvariant(mg.Area) == area))
            {
                int sAddr = Math.Max(s.StartHex, pageStart);
                int eAddr = Math.Min(s.StartHex + s.Count - 1, pageStart + 0xFF);
                if (eAddr < sAddr) continue;
                for (int addr = sAddr; addr <= eAddr; addr++)
                {
                    int idx = addr - pageStart;
                    if (idx >= 0 && idx < 256)
                    {
                        if (counts[idx] < 255) counts[idx]++;
                    }
                }
            }
            bool isHex = HexAreas.Contains(area);
            pageView.SetPage(area, pageStart, counts, isHex);
        }

        // --- helpers ---
        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }

        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var parts = s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var kv = p.Split(new[] { '=' }, 2);
                if (kv.Length == 2) dict[kv[0].Trim()] = kv[1].Trim();
            }
            return dict;
        }

        private static bool TryParseByArea(char area, string token, out int val)
        {
            val = 0; if (string.IsNullOrWhiteSpace(token)) return false;
            token = token.Trim();
            area = char.ToUpperInvariant(area);
            if (DecAreas.Contains(area))
            {
                // decimal 영역 (M/D/R/L/Z=ZR)
                if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
                return int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
            }
            else
            {
                // hex 영역 (B/W/X/Y)
                if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
                return int.TryParse(token, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            }
        }

        private static string FormatByArea(char area, int value)
        {
            area = char.ToUpperInvariant(area);
            if (HexAreas.Contains(area)) return $"0x{value:X}";
            return value.ToString(CultureInfo.InvariantCulture);
        }
    }

    // 내부 데이터 구조
    public class Segment
    {
        public char Area;
        public int StartHex;
        public int Count; // used = end - start + 1

        public Segment(char area, int startHex, int used)
        {
            Area = area; StartHex = startHex; Count = used;
        }
    }

    public class MemoryMap
    {
        public List<Segment> Segments { get; } = new List<Segment>();
    }

    // 출력 스펙용(CountOut = used + 1)
    public class SpecRange
    {
        public char Area;
        public int StartHex;
        public int CountOut;

        public SpecRange(char area, int start, int countOut)
        {
            Area = area; StartHex = start; CountOut = countOut;
        }
    }
}
