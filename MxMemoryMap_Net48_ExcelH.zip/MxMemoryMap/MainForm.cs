using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<MergedRange> _merged = new List<MergedRange>();

        public MainForm()
        {
            InitializeComponent();
            txtInput.Text = "MEMORY=W:3000:4&W:3A00:4&W:4000:10&B:3000:10";
            txtNormalized.ReadOnly = true; // copy-only
            txtNormalized.ShortcutsEnabled = true; // allow Ctrl+C
            txtNormalized.Cursor = Cursors.IBeam;

            // Drag & Drop for Excel
            this.AllowDrop = true;
            this.DragEnter += MainForm_DragEnter;
            this.DragDrop += MainForm_DragDrop;
        }

        private void MainForm_Load(object sender, EventArgs e) { }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Length > 0 && Path.GetExtension(files[0]).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    e.Effect = DragDropEffects.Copy;
                    return;
                }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;
                var file = files[0];
                if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("엑셀 .xlsx 파일만 지원합니다.");
                    return;
                }

                var rows = SimpleXlsx.ReadColumnHStrings(file);
                if (rows.Count == 0)
                {
                    MessageBox.Show("H열에서 읽을 문자열이 없습니다.");
                    return;
                }

                var map = new MemoryMap();
                int accepted = 0, skipped = 0;

                foreach (var row in rows)
                {
                    var dict = ParseKeyValues(row);
                    string dev, addr;
                    if (!dict.TryGetValue("DEVICE_TYPE", out dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@")
                    { skipped++; continue; }
                    if (!dict.TryGetValue("ADDRESS_NO", out addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@")
                    { skipped++; continue; }

                    int count = 1;
                    int tmp;
                    if (TryGetInt(dict, new[] { "COUNT", "POINT", "POINTS", "LEN", "LENGTH", "SIZE" }, out tmp))
                        count = Math.Max(1, tmp);

                    char area = char.ToUpperInvariant(dev.Trim()[0]);
                    int startHex;
                    if (!TryParseFlexibleInt(addr, out startHex))
                    { skipped++; continue; }

                    map.Segments.Add(new Segment(area, startHex, count));
                    accepted++;
                }

                _map = map;
                _merged = MergeRanges(_map);
                txtOutput.Text = string.Format("[Excel 로드]\r\n읽은 행: {0}, 사용: {1}, 제외: {2}\r\n\r\n", rows.Count, accepted, skipped)
                               + MemoryMapFormatter.FormatSummary(_map, _merged);
                txtNormalized.Text = BuildNormalizedSpec(_map);

                cboArea.Items.Clear();
                foreach (char area in _merged.Select(m => m.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                    cboArea.Items.Add(area);
                if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
                else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
            }
            catch (Exception ex)
            {
                MessageBox.Show("엑셀 로드 실패: " + ex.Message);
            }
        }

        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var parts = s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var kv = p.Split(new[] { '=' }, 2);
                if (kv.Length == 2)
                {
                    var key = kv[0].Trim();
                    var val = kv[1].Trim();
                    dict[key] = val;
                }
            }
            return dict;
        }

        private static bool TryGetInt(Dictionary<string, string> dict, string[] keys, out int value)
        {
            foreach (var k in keys)
            {
                string s;
                if (dict.TryGetValue(k, out s) && TryParseFlexibleInt(s, out value))
                    return true;
            }
            value = 0;
            return false;
        }

        private static bool TryParseFlexibleInt(string token, out int val)
        {
            if (string.IsNullOrWhiteSpace(token)) { val = 0; return false; }
            token = token.Trim();
            if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
            {
                return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            }
            // strip commas
            token = token.Replace(",", "");
            // hex-like?
            bool hasHex = false;
            foreach (char ch in token)
            {
                if ((ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f')) { hasHex = true; break; }
            }
            if (hasHex) return int.TryParse(token, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            return int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                _map = MemoryMapParser.Parse(txtInput.Text ?? string.Empty);
                _merged = MergeRanges(_map); // inclusive end: start + count

                txtOutput.Text = MemoryMapFormatter.FormatSummary(_map, _merged);
                txtNormalized.Text = BuildNormalizedSpec(_map);

                cboArea.Items.Clear();
                foreach (char area in _merged.Select(m => m.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                    cboArea.Items.Add(area);
                if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
                else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
            }
            catch (Exception ex)
            {
                txtOutput.Text = "[에러] " + ex.Message;
                txtNormalized.Text = "";
            }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) { RefreshPages(); }
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) { ShowSelectedPage(); }

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_merged == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _merged.Where(m => m.Area == area).ToList();

            var pages = new SortedSet<int>(); // 0xXX00 페이지
            foreach (var r in ranges)
            {
                int pageStart = r.StartHex & 0xFF00;
                int pageEnd = r.EndHex & 0xFF00;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
                lstPages.Items.Add(string.Format("0x{0:X4} - 0x{1:X4}", p, p + 0xFF));
            lblPageInfo.Text = pages.Count > 0 ? string.Format("페이지 {0}개", pages.Count) : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_merged == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var text = lstPages.SelectedItem.ToString();
            if (string.IsNullOrEmpty(text)) return;

            int pageStart = int.Parse(text.Substring(2, 4), NumberStyles.HexNumber);
            var active = new bool[256];
            foreach (var r in _merged.Where(m => m.Area == area))
            {
                int s = Math.Max(r.StartHex, pageStart);
                int e = Math.Min(r.EndHex, pageStart + 0xFF);
                if (e < s) continue;
                for (int addr = s; addr <= e; addr++) active[addr - pageStart] = true;
            }
            pageView.SetPage(area, pageStart, active);
        }

        // B, W 우선 정렬 키
        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }

        // 영역 정렬 + 시작주소 정렬, 포맷 "A:STARTHEX:COUNT" & 연결
        private static string BuildNormalizedSpec(MemoryMap map)
        {
            var parts = new List<string>();
            foreach (var g in map.Segments.GroupBy(s => s.Area).OrderBy(g => AreaOrderKey(g.Key)))
            {
                foreach (var s in g.OrderBy(x => x.StartHex))
                {
                    parts.Add(string.Format("{0}:{1:X}:{2}", char.ToUpperInvariant(s.Area), s.StartHex, s.Count));
                }
            }
            return string.Join("&", parts.ToArray());
        }

        // 범위 병합: 같은 Area 내에서 겹치거나 인접한 범위를 하나로 (끝 = 시작 + 개수, 포함)
        private static List<MergedRange> MergeRanges(MemoryMap map)
        {
            var result = new List<MergedRange>();
            foreach (var g in map.Segments.GroupBy(s => s.Area))
            {
                var intervals = g.Select(s => new { Start = s.StartHex, End = s.StartHex + s.Count }) // inclusive
                                 .OrderBy(t => t.Start).ToList();
                int? curS = null; int? curE = null;
                foreach (var it in intervals)
                {
                    int s = it.Start; int e = it.End;
                    if (curS == null) { curS = s; curE = e; continue; }
                    if (s <= curE + 1) curE = Math.Max(curE.Value, e);
                    else { result.Add(new MergedRange(g.Key, curS.Value, curE.Value)); curS = s; curE = e; }
                }
                if (curS != null) result.Add(new MergedRange(g.Key, curS.Value, curE.Value));
            }
            return result;
        }
    }
}
