using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace MxMemoryMap
{
    // 최소한의 XLSX 리더: 첫 번째 시트의 H열 문자열만 읽는다.
    public static class SimpleXlsx
    {
        public static List<string> ReadColumnHStrings(string path)
        {
            var result = new List<string>();
            using (var fs = File.OpenRead(path))
            using (var zip = new ZipArchive(fs, ZipArchiveMode.Read))
            {
                var shared = ReadSharedStrings(zip);
                var sheetPath = GetFirstWorksheetPath(zip);
                if (sheetPath == null) return result;
                var entry = zip.GetEntry(sheetPath.Replace("\\", "/"));
                if (entry == null) return result;
                XDocument wsDoc;
                using (var s = entry.Open())
                {
                    wsDoc = XDocument.Load(s);
                }
                XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
                foreach (var c in wsDoc.Descendants(ns + "c"))
                {
                    var r = (string)c.Attribute("r");
                    if (string.IsNullOrEmpty(r) || !(r.StartsWith("H") || r.StartsWith("h"))) continue;
                    var t = (string)c.Attribute("t");
                    string text = null;
                    if (t == "s")
                    {
                        var v = (string)c.Element(ns + "v");
                        int idx;
                        if (int.TryParse(v, out idx) && idx >= 0 && idx < shared.Count) text = shared[idx];
                    }
                    else if (t == "inlineStr")
                    {
                        var isElem = c.Element(ns + "is");
                        if (isElem != null)
                        {
                            var tnode = isElem.Element(ns + "t");
                            if (tnode != null) text = tnode.Value;
                        }
                    }
                    else
                    {
                        var v = (string)c.Element(ns + "v");
                        text = v;
                    }
                    if (!string.IsNullOrWhiteSpace(text)) result.Add(text.Trim());
                }
            }
            return result;
        }

        private static List<string> ReadSharedStrings(ZipArchive zip)
        {
            var list = new List<string>();
            var entry = zip.GetEntry("xl/sharedStrings.xml");
            if (entry == null) return list;
            XDocument sst;
            using (var s = entry.Open())
            {
                sst = XDocument.Load(s);
            }
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            foreach (var si in sst.Descendants(ns + "si"))
            {
                // si may have multiple t (rich text). Concatenate.
                var texts = si.Descendants(ns + "t").Select(t => t.Value);
                list.Add(string.Concat(texts));
            }
            return list;
        }

        private static string GetFirstWorksheetPath(ZipArchive zip)
        {
            var wbEntry = zip.GetEntry("xl/workbook.xml");
            if (wbEntry == null) return null;
            XDocument wb;
            using (var s = wbEntry.Open()) { wb = XDocument.Load(s); }
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            XNamespace relNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
            var sheet = wb.Root.Element(ns + "sheets")?.Elements(ns + "sheet")?.FirstOrDefault();
            if (sheet == null) return null;
            var rId = (string)sheet.Attribute(relNs + "id");
            if (string.IsNullOrEmpty(rId)) return null;

            var relEntry = zip.GetEntry("xl/_rels/workbook.xml.rels");
            if (relEntry == null) return null;
            XDocument rels;
            using (var s = relEntry.Open()) { rels = XDocument.Load(s); }
            XNamespace relsNs = "http://schemas.openxmlformats.org/package/2006/relationships";
            var rel = rels.Root.Elements().FirstOrDefault(e => (string)e.Attribute("Id") == rId);
            if (rel == null) return null;
            var target = (string)rel.Attribute("Target");
            if (string.IsNullOrEmpty(target)) return null;
            if (!target.StartsWith("xl/", StringComparison.OrdinalIgnoreCase)) target = "xl/" + target;
            return target;
        }
    }
}
