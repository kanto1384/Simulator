using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace RemotePortalMapper;

public sealed class MainForm : Form
{
    private readonly SplitContainer _split = new();
    private readonly Panel _leftTop = new();
    private readonly TextBox _txtUrl = new();
    private readonly Button _btnGo = new();
    private readonly Button _btnExtract = new();
    private readonly Button _btnReloadMap = new();
    private readonly Label _lblStatus = new();
    private readonly WebView2 _web = new();

    private readonly Panel _rightTop = new();
    private readonly TextBox _txtSearch = new();
    private readonly Button _btnClearSearch = new();
    private readonly DataGridView _grid = new();
    private readonly Label _lblMapPath = new();

    private DeviceIndex _index = new();
    private List<ViewRow> _currentRows = new();

    private string MapPath => Path.Combine(AppContext.BaseDirectory, "data", "device_map.json");

    public MainForm()
    {
        Text = "Remote Portal Mapper (WebView2 + JSON map)";
        Width = 1400;
        Height = 900;
        StartPosition = FormStartPosition.CenterScreen;

        BuildLayout();

        Load += async (_, _) =>
        {
            try
            {
                await EnsureWebViewAsync();
                ReloadMap();
                _lblStatus.Text = "Ready";
            }
            catch (Exception ex)
            {
                _lblStatus.Text = "Init failed";
                MessageBox.Show(this, ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        };
    }

    private void BuildLayout()
    {
        // Split
        _split.Dock = DockStyle.Fill;
        _split.Orientation = Orientation.Vertical;
        _split.SplitterDistance = (int)(Width * 0.62);
        Controls.Add(_split);

        // LEFT: top bar
        _leftTop.Dock = DockStyle.Top;
        _leftTop.Height = 44;
        _leftTop.Padding = new Padding(8, 8, 8, 8);
        _split.Panel1.Controls.Add(_leftTop);

        _txtUrl.Dock = DockStyle.Fill;
        _txtUrl.PlaceholderText = "https://<internal-ip>/ ...";
        _leftTop.Controls.Add(_txtUrl);

        var leftButtons = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = 360,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoSize = false
        };
        _leftTop.Controls.Add(leftButtons);

        _btnGo.Text = "Go";
        _btnGo.Width = 70;
        _btnGo.Click += (_, _) => Navigate();

        _btnExtract.Text = "Extract";
        _btnExtract.Width = 90;
        _btnExtract.Click += async (_, _) => await ExtractAndShowAsync();

        _btnReloadMap.Text = "Reload map";
        _btnReloadMap.Width = 110;
        _btnReloadMap.Click += (_, _) => { ReloadMap(); ApplySearchFilter(); };

        _lblStatus.Text = "";
        _lblStatus.AutoSize = true;
        _lblStatus.Padding = new Padding(6, 7, 6, 0);

        leftButtons.Controls.Add(_btnGo);
        leftButtons.Controls.Add(_btnExtract);
        leftButtons.Controls.Add(_btnReloadMap);
        leftButtons.Controls.Add(_lblStatus);

        // LEFT: WebView2
        _web.Dock = DockStyle.Fill;
        _split.Panel1.Controls.Add(_web);

        // RIGHT: top bar
        _rightTop.Dock = DockStyle.Top;
        _rightTop.Height = 44;
        _rightTop.Padding = new Padding(8, 8, 8, 8);
        _split.Panel2.Controls.Add(_rightTop);

        _txtSearch.Dock = DockStyle.Fill;
        _txtSearch.PlaceholderText = "Search (host / ip / equipment / location / note)";
        _txtSearch.TextChanged += (_, _) => ApplySearchFilter();
        _rightTop.Controls.Add(_txtSearch);

        _btnClearSearch.Text = "Clear";
        _btnClearSearch.Dock = DockStyle.Right;
        _btnClearSearch.Width = 80;
        _btnClearSearch.Click += (_, _) => _txtSearch.Text = "";
        _rightTop.Controls.Add(_btnClearSearch);

        // RIGHT: grid
        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AllowUserToResizeRows = false;
        _grid.MultiSelect = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.RowHeadersVisible = false;
        _grid.DataSource = new List<ViewRow>();
        _split.Panel2.Controls.Add(_grid);

        // RIGHT: bottom map path label
        _lblMapPath.Dock = DockStyle.Bottom;
        _lblMapPath.Height = 28;
        _lblMapPath.Padding = new Padding(8, 6, 8, 0);
        _lblMapPath.Text = "map: (not loaded)";
        _split.Panel2.Controls.Add(_lblMapPath);

        // Keyboard shortcuts
        KeyPreview = true;
        KeyDown += async (_, e) =>
        {
            if (e.Control && e.KeyCode == Keys.L) { _txtUrl.Focus(); _txtUrl.SelectAll(); e.Handled = true; }
            if (e.Control && e.KeyCode == Keys.E) { await ExtractAndShowAsync(); e.Handled = true; }
            if (e.Control && e.KeyCode == Keys.F) { _txtSearch.Focus(); _txtSearch.SelectAll(); e.Handled = true; }
        };
    }

    private async Task EnsureWebViewAsync()
    {
        // Ensure WebView2 runtime is present on the machine.
        await _web.EnsureCoreWebView2Async();

        _web.CoreWebView2.NewWindowRequested += (s, e) =>
        {
            // Keep navigation inside the same view (optional)
            try
            {
                e.Handled = true;
                _web.CoreWebView2.Navigate(e.Uri);
            }
            catch
            {
                // If for some reason navigation fails, allow default.
                e.Handled = false;
            }
        };
    }

    private void Navigate()
    {
        if (_web.CoreWebView2 is null)
        {
            MessageBox.Show(this, "WebView2 is not initialized yet.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var url = _txtUrl.Text.Trim();
        if (string.IsNullOrWhiteSpace(url)) return;

        if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
            !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            url = "https://" + url;
        }

        _web.CoreWebView2.Navigate(url);
    }

    private void ReloadMap()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(MapPath)!);
            if (!File.Exists(MapPath))
            {
                File.WriteAllText(MapPath,
                    "{\n  \"version\": 1,\n  \"updatedAt\": \"" + DateTime.Now.ToString("yyyy-MM-dd") + "\",\n  \"devices\": []\n}\n");
            }

            _index = DeviceIndex.Load(MapPath);
            _lblMapPath.Text = $"map: {MapPath}   (host={_index.ByHost.Count}, ip={_index.ByIp.Count})";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.ToString(), "Map load failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task ExtractAndShowAsync()
    {
        if (_web.CoreWebView2 is null)
        {
            MessageBox.Show(this, "WebView2 is not initialized yet.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        try
        {
            _lblStatus.Text = "Extracting...";
            await WaitForTableAsync(timeoutMs: 8000);

            var extracted = await ExtractIpHostAsync();
            _currentRows = BuildRows(extracted, _index);
            ApplySearchFilter();

            _lblStatus.Text = $"OK ({_currentRows.Count} rows)";
        }
        catch (Exception ex)
        {
            _lblStatus.Text = "Failed";
            MessageBox.Show(this, ex.ToString(), "Extract failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ApplySearchFilter()
    {
        var q = _txtSearch.Text.Trim();
        if (string.IsNullOrWhiteSpace(q))
        {
            _grid.DataSource = _currentRows;
            return;
        }

        // Simple contains filter across key fields
        var filtered = _currentRows
            .Where(r =>
                ContainsIgnoreCase(r.Host, q) ||
                ContainsIgnoreCase(r.Ip, q) ||
                ContainsIgnoreCase(r.EquipmentGroup, q) ||
                ContainsIgnoreCase(r.EquipmentListText, q) ||
                ContainsIgnoreCase(r.Location, q) ||
                ContainsIgnoreCase(r.Note, q) ||
                ContainsIgnoreCase(r.Status, q))
            .ToList();

        _grid.DataSource = filtered;
    }

    private static bool ContainsIgnoreCase(string? s, string q)
        => (s ?? "").IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0;

    // ===== DOM extraction =====

    private async Task WaitForTableAsync(int timeoutMs)
    {
        var sw = Stopwatch.StartNew();
        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            const string js = """
            (() => {
              const t = document.querySelector('#seltable');
              const rows = document.querySelectorAll('#seltable tbody tr');
              return !!t && !!rows && rows.length > 0;
            })();
            """;

            var okJson = await _web.CoreWebView2.ExecuteScriptAsync(js);
            if (okJson == "true") return;
            await Task.Delay(200);
        }
    }

    private async Task<List<(string Ip, string Host)>> ExtractIpHostAsync()
    {
        // Structure you described:
        //  - table id="seltable"
        //  - multiple tbody
        //  - each row is tr/td
        //  - 6th td = IP, 7th td = Hostname
        const string js = """
        (() => {
          const rows = Array.from(document.querySelectorAll('#seltable tbody tr'));
          const out = [];
          for (const tr of rows) {
            const tds = tr.querySelectorAll('td');
            if (!tds || tds.length < 7) continue;
            const ip = (tds[5].innerText || '').trim();
            const host = (tds[6].innerText || '').trim();
            if (!ip && !host) continue;
            out.push({ ip, host });
          }
          const seen = new Set();
          const uniq = [];
          for (const x of out) {
            const key = (x.ip + '|' + x.host).toLowerCase();
            if (seen.has(key)) continue;
            seen.add(key);
            uniq.push(x);
          }
          return uniq;
        })();
        """;

        var json = await _web.CoreWebView2.ExecuteScriptAsync(js);
        var items = JsonSerializer.Deserialize<List<IpHostDto>>(json) ?? new();

        return items
            .Select(x => (Ip: (x.ip ?? "").Trim(), Host: (x.host ?? "").Trim()))
            .Where(x => !string.IsNullOrWhiteSpace(x.Ip) || !string.IsNullOrWhiteSpace(x.Host))
            .ToList();
    }

    private sealed class IpHostDto
    {
        public string? ip { get; set; }
        public string? host { get; set; }
    }

    // ===== mapping + view =====

    private static List<ViewRow> BuildRows(List<(string Ip, string Host)> extracted, DeviceIndex index)
    {
        var rows = new List<ViewRow>(extracted.Count);

        foreach (var (ip, host) in extracted)
        {
            DeviceItem? item = null;

            if (!string.IsNullOrWhiteSpace(host) && index.ByHost.TryGetValue(host, out var byHost))
                item = byHost;
            else if (!string.IsNullOrWhiteSpace(ip) && index.ByIp.TryGetValue(ip, out var byIp))
                item = byIp;

            if (item is null)
            {
                rows.Add(new ViewRow(ip, host, "", "", "", "", "매핑 없음"));
                continue;
            }

            var listText = item.equipmentList is { Count: > 0 }
                ? string.Join(", ", item.equipmentList)
                : "";

            rows.Add(new ViewRow(
                ip,
                host,
                item.equipmentGroup ?? "",
                listText,
                item.location ?? "",
                item.note ?? "",
                "OK"));
        }

        // sort: mapped first, then equipmentGroup, then host
        return rows
            .OrderBy(r => r.Status == "매핑 없음" ? 1 : 0)
            .ThenBy(r => r.EquipmentGroup)
            .ThenBy(r => r.Host)
            .ToList();
    }

    public sealed record ViewRow(
        string Ip,
        string Host,
        string EquipmentGroup,
        string EquipmentListText,
        string Location,
        string Note,
        string Status);
}
