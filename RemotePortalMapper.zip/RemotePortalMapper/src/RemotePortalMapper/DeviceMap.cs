using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace RemotePortalMapper;

public sealed class DeviceMapRoot
{
    public int version { get; set; }
    public string? updatedAt { get; set; }
    public List<DeviceItem> devices { get; set; } = new();
}

public sealed class DeviceItem
{
    public string? host { get; set; }
    public string? ip { get; set; }
    public string? equipmentGroup { get; set; }
    public List<string>? equipmentList { get; set; }
    public string? location { get; set; }
    public string? note { get; set; }
}

public sealed class DeviceIndex
{
    public Dictionary<string, DeviceItem> ByHost { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, DeviceItem> ByIp { get; } = new(StringComparer.OrdinalIgnoreCase);

    public static DeviceIndex Load(string path)
    {
        var json = File.ReadAllText(path);
        var root = JsonSerializer.Deserialize<DeviceMapRoot>(json) ?? new DeviceMapRoot();

        var idx = new DeviceIndex();
        foreach (var d in root.devices)
        {
            if (!string.IsNullOrWhiteSpace(d.host))
                idx.ByHost[d.host.Trim()] = d;
            if (!string.IsNullOrWhiteSpace(d.ip))
                idx.ByIp[d.ip.Trim()] = d;
        }
        return idx;
    }
}
