GATEONE - Auto ID/PW Fill (Main + Popup) + "안전하지 않음" Proceed

✅ 동작
- 처음 접속 시 "안전하지 않음" 화면에서 Proceed(계속) 자동 클릭 시도
- 로그인 폼이 iframe 안에 있어도 FrameCreated 기반으로 USERID/PASSWD 자동 입력
- 로그인 버튼은 자동 클릭하지 않음(값만 채움)

✅ device_map.json (최상위) credentials 추가
{
  "version": 1,
  "updatedAt": "2026-02-12",
  "credentials": { "id": "YOUR_ID", "pw": "YOUR_PW" },
  "devices": []
}

✅ 로그인 input 셀렉터
- input#USERID.input_txt
- input#PASSWD.input_txt

참고
- interstitial DOM이 다른 환경이면 #details-button / #proceed-link가 다를 수 있습니다.
