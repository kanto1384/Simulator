\
# OPC UA WinForms Client (.NET Framework 4.7.2)

간단한 OPC UA C# 클라이언트 예제입니다. WinForms UI에서 **Connect / Read / Write** 를 지원합니다.
NuGet 패키지 추가 후 바로 빌드할 수 있습니다.

## 요구사항
- Windows + Visual Studio 2019/2022
- .NET Framework 4.7.2 개발자팩
- NuGet 패키지(아래 3개) 설치:
  - `Opc.Ua.Core` (OPC Foundation)
  - `Opc.Ua.Client` (OPC Foundation)
  - `Opc.Ua.Configuration` (OPC Foundation)

> **팁:** 위 세 패키지는 동일한 메이저/마이너 버전으로 맞추세요(예: 1.4.xxx). NuGet에서 최신 안정 버전을 선택해 설치하면 됩니다.

## 실행 방법
1. Visual Studio에서 `OPCUAWinFormsClient.csproj` 를 엽니다.
2. NuGet 패키지 관리자에서 위 3개 패키지를 설치합니다.
3. 빌드 후 실행(F5).
4. 기본 Endpoint URL(`opc.tcp://localhost:4840`)과 NodeId 예시를 입력하고 **Connect** → **Read**/**Write** 를 눌러 테스트합니다.

## 보안 관련
- 예제는 기본적으로 **보안 비활성화(Anonymous, SecurityMode=None)** 로 접속합니다.
- 실환경에서는 적절한 SecurityPolicy/사용자 인증/인증서 신뢰 설정을 구성하세요.
- 코드 상에서 `AutoAcceptUntrustedCertificates = true` 설정이 포함되어 있어 테스트에 편리하지만, 운영환경에서는 꼭 false로 두고 신뢰 루트를 구성하세요.

## 주의
- 서버의 노드 데이터타입과 일치하지 않으면 Write가 실패합니다. 입력값은 자동으로 `bool → int → long → double → string` 순으로 변환을 시도합니다.
- 서버/네트워크 상태, 권한, 접근제어에 따라 연결/쓰기 실패가 날 수 있습니다.
