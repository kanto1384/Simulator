\
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

// NuGet: Opc.Ua.Core, Opc.Ua.Client, Opc.Ua.Configuration (OPC Foundation)
using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Configuration;

namespace OPCUAWinFormsClient
{
    public class MainForm : Form
    {
        private TextBox txtEndpoint;
        private Button btnConnect;
        private Button btnDisconnect;
        private TextBox txtNodeId;
        private Button btnRead;
        private TextBox txtReadValue;
        private TextBox txtWriteValue;
        private Button btnWrite;
        private ListBox lstLog;
        private Session _session;

        public MainForm()
        {
            Text = "OPC UA WinForms Client (.NET Framework)";
            Width = 900;
            Height = 600;

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 6,
                AutoSize = true
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));

            // Row 0: Endpoint
            layout.Controls.Add(new Label { Text = "Endpoint URL", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
            txtEndpoint = new TextBox { Text = "opc.tcp://localhost:4840", Dock = DockStyle.Fill };
            layout.Controls.Add(txtEndpoint, 1, 0);
            btnConnect = new Button { Text = "Connect", Dock = DockStyle.Fill };
            btnDisconnect = new Button { Text = "Disconnect", Dock = DockStyle.Fill };
            layout.Controls.Add(btnConnect, 2, 0);
            layout.Controls.Add(btnDisconnect, 3, 0);

            // Row 1: NodeId
            layout.Controls.Add(new Label { Text = "NodeId", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 1);
            txtNodeId = new TextBox { Text = "ns=2;s=Demo.Dynamic.Scalar.Int32", Dock = DockStyle.Fill };
            layout.Controls.Add(txtNodeId, 1, 1);
            btnRead = new Button { Text = "Read", Dock = DockStyle.Fill };
            btnWrite = new Button { Text = "Write", Dock = DockStyle.Fill };
            layout.Controls.Add(btnRead, 2, 1);
            layout.Controls.Add(btnWrite, 3, 1);

            // Row 2: Read/Write Values
            layout.Controls.Add(new Label { Text = "Read Value", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 2);
            txtReadValue = new TextBox { ReadOnly = true, Dock = DockStyle.Fill };
            layout.Controls.Add(txtReadValue, 1, 2);

            layout.Controls.Add(new Label { Text = "Write Value", AutoSize = true, Anchor = AnchorStyles.Left }, 2, 2);
            txtWriteValue = new TextBox { Dock = DockStyle.Fill };
            layout.Controls.Add(txtWriteValue, 3, 2);

            // Row 3+: Log
            layout.Controls.Add(new Label { Text = "Log", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 3);
            lstLog = new ListBox { Dock = DockStyle.Fill };
            layout.SetColumnSpan(lstLog, 3);
            layout.Controls.Add(lstLog, 1, 3);
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            Controls.Add(layout);

            btnConnect.Click += async (s, e) => await ConnectAsync();
            btnDisconnect.Click += (s, e) => Disconnect();
            btnRead.Click += async (s, e) => await ReadAsync();
            btnWrite.Click += async (s, e) => await WriteAsync();
        }

        private void Log(string msg)
        {
            lstLog.Items.Add($"[{DateTime.Now:HH:mm:ss}] {msg}");
            lstLog.TopIndex = lstLog.Items.Count - 1;
        }

        private async Task ConnectAsync()
        {
            try
            {
                if (_session?.Connected == true)
                {
                    Log("Already connected.");
                    return;
                }

                var endpointUrl = txtEndpoint.Text.Trim();
                if (string.IsNullOrWhiteSpace(endpointUrl))
                {
                    MessageBox.Show("Endpoint URL을 입력하세요.");
                    return;
                }

                Log($"Connecting to {endpointUrl} ...");

                // Build minimal app configuration
                var config = new ApplicationConfiguration()
                {
                    ApplicationName = "OPCUAWinFormsClient",
                    ApplicationType = ApplicationType.Client,
                    SecurityConfiguration = new SecurityConfiguration
                    {
                        ApplicationCertificate = new CertificateIdentifier
                        {
                            StoreType = "Directory",
                            StorePath = "OPC Foundation/CertificateStores/MachineDefault",
                            SubjectName = "OPCUAWinFormsClient"
                        },
                        AutoAcceptUntrustedCertificates = true, // Demo only!
                        AddAppCertToTrustedStore = true
                    },
                    TransportQuotas = new TransportQuotas
                    {
                        OperationTimeout = 15000,
                        MaxStringLength = 1_048_576,
                        MaxByteStringLength = 1_048_576,
                        MaxArrayLength = 65_536,
                        MaxMessageSize = 4_194_304,
                        MaxBufferSize = 65535,
                        ChannelLifetime = 300000,
                        SecurityTokenLifetime = 3600000
                    },
                    ClientConfiguration = new ClientConfiguration
                    {
                        DefaultSessionTimeout = 60000,
                        WellKnownDiscoveryUrls = { "opc.tcp://localhost:4840" }
                    },
                    DisableHiResClock = false
                };

                var app = new ApplicationInstance
                {
                    ApplicationName = "OPCUAWinFormsClient",
                    ApplicationType = ApplicationType.Client,
                    ApplicationConfiguration = config
                };

                await config.Validate(ApplicationType.Client);
                bool haveCert = await app.CheckApplicationInstanceCertificate(false, 0);
                if (!haveCert)
                {
                    Log("Warning: No application certificate created.");
                }

                // Select endpoint (no security for demo)
                var endpointDescription = CoreClientUtils.SelectEndpoint(endpointUrl, useSecurity: false, 15000);
                var endpointConfiguration = EndpointConfiguration.Create(config);
                var endpoint = new ConfiguredEndpoint(null, endpointDescription, endpointConfiguration);

                // Create session
                _session = await Session.Create(
                    config,
                    endpoint,
                    updateBeforeConnect: false,
                    sessionName: "OPCUAWinFormsClient",
                    sessionTimeout: 60000,
                    identity: new UserIdentity(new AnonymousIdentityToken()),
                    preferredLocales: null);

                if (_session != null && _session.Connected)
                {
                    Log("Connected.");
                }
                else
                {
                    Log("Failed to connect.");
                }
            }
            catch (Exception ex)
            {
                Log("Connect error: " + ex.Message);
                MessageBox.Show(ex.ToString(), "Connect Error");
            }
        }

        private void Disconnect()
        {
            try
            {
                if (_session != null)
                {
                    _session.Close();
                    _session.Dispose();
                    _session = null;
                    Log("Disconnected.");
                }
            }
            catch (Exception ex)
            {
                Log("Disconnect error: " + ex.Message);
            }
        }

        private async Task ReadAsync()
        {
            try
            {
                if (_session == null || !_session.Connected)
                {
                    MessageBox.Show("먼저 서버에 연결하세요.");
                    return;
                }

                var nodeIdText = txtNodeId.Text.Trim();
                if (string.IsNullOrWhiteSpace(nodeIdText))
                {
                    MessageBox.Show("NodeId를 입력하세요.");
                    return;
                }

                var nodeId = NodeId.Parse(nodeIdText);
                Log($"Reading {nodeId} ...");

                // Simple value read
                DataValue value = await Task.Run(() => _session.ReadValue(nodeId));
                if (StatusCode.IsGood(value.StatusCode))
                {
                    txtReadValue.Text = value.WrappedValue.ToString();
                    Log($"Read OK: {value.WrappedValue} (Status: {value.StatusCode})");
                }
                else
                {
                    txtReadValue.Text = "";
                    Log($"Read failed: {value.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                Log("Read error: " + ex.Message);
                MessageBox.Show(ex.ToString(), "Read Error");
            }
        }

        private async Task WriteAsync()
        {
            try
            {
                if (_session == null || !_session.Connected)
                {
                    MessageBox.Show("먼저 서버에 연결하세요.");
                    return;
                }

                var nodeIdText = txtNodeId.Text.Trim();
                var input = txtWriteValue.Text.Trim();
                if (string.IsNullOrWhiteSpace(nodeIdText))
                {
                    MessageBox.Show("NodeId를 입력하세요.");
                    return;
                }

                var nodeId = NodeId.Parse(nodeIdText);

                // Try convert input to a reasonable type
                object converted = TrySmartConvert(input);
                var valueToWrite = new WriteValue
                {
                    NodeId = nodeId,
                    AttributeId = Attributes.Value,
                    Value = new DataValue(new Variant(converted))
                };

                var nodesToWrite = new WriteValueCollection { valueToWrite };

                StatusCodeCollection results;
                DiagnosticInfoCollection diagnosticInfos;
                Log($"Writing '{converted}' to {nodeId} ...");

                await Task.Run(() =>
                    _session.Write(
                        null,
                        nodesToWrite,
                        out results,
                        out diagnosticInfos));

                if (results != null && results.Count > 0 && StatusCode.IsGood(results[0]))
                {
                    Log("Write OK.");
                }
                else
                {
                    var status = results != null && results.Count > 0 ? results[0].ToString() : "Unknown";
                    Log("Write failed: " + status);
                }
            }
            catch (Exception ex)
            {
                Log("Write error: " + ex.Message);
                MessageBox.Show(ex.ToString(), "Write Error");
            }
        }

        private object TrySmartConvert(string input)
        {
            if (bool.TryParse(input, out var b)) return b;
            if (int.TryParse(input, out var i)) return i;
            if (long.TryParse(input, out var l)) return l;
            if (double.TryParse(input, out var d)) return d;
            return input; // fallback to string
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            try
            {
                if (_session != null)
                {
                    _session.Close();
                    _session.Dispose();
                    _session = null;
                }
            }
            catch { /* ignore */ }
            base.OnFormClosed(e);
        }
    }
}
