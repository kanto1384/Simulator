using System;
using System.Drawing;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public class MemoryPageView : Control
    {
        private byte[] _counts = new byte[256];
        private int _pageStart;
        private char _area;
        private readonly ToolTip _tip = new ToolTip();

        public MemoryPageView()
        {
            this.DoubleBuffered = true;
            _tip.SetToolTip(this, "칸 위에 마우스를 올리면 주소/중복이 표시됩니다.");
            this.MouseMove += MemoryPageView_MouseMove;
        }

        public void Clear()
        {
            _counts = new byte[256];
            _pageStart = 0; _area = '\\0';
            Invalidate();
        }

        public void SetPage(char area, int pageStart, byte[] counts)
        {
            _area = area; _pageStart = pageStart; _counts = counts ?? new byte[256];
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.White);
            Rectangle rc = this.ClientRectangle;

            string title = _area == '\\0'
                ? "페이지 없음"
                : string.Format("[{0}] 0x{1:X5} - 0x{2:X5}", _area, _pageStart, _pageStart + 0xFF);
            using (Font titleFont = new Font(this.Font.FontFamily, 12f, FontStyle.Bold))
            {
                g.DrawString(title, titleFont, Brushes.Black, 8, 8);
            }

            int top = 56;
            int left = 26; // 좌측 여백 26
            int cols = 16, rows = 16;
            int cell = Math.Min((rc.Width - left - 24) / cols, (rc.Height - top - 24) / rows);
            if (cell < 10) cell = 10;

            using (Pen pen = new Pen(Color.LightGray))
            using (Pen penBold = new Pen(Color.Gray, 1.5f))
            using (SolidBrush brushSingle = new SolidBrush(Color.FromArgb(120, Color.SkyBlue)))
            using (SolidBrush brushDup = new SolidBrush(Color.FromArgb(180, Color.Yellow)))
            using (SolidBrush brushText = new SolidBrush(Color.Black))
            using (Font font = new Font("Consolas", Math.Max(9, cell / 3f)))
            {
                for (int c = 0; c < cols; c++)
                {
                    int x = left + c * cell;
                    g.DrawString(c.ToString("X"), font, brushText, x + 2, top - (int)font.GetHeight() - 4);
                }
                for (int r = 0; r < rows; r++)
                {
                    int y = top + r * cell;
                    g.DrawString(r.ToString("X"), font, brushText, left - (int)font.GetHeight() - 6, y + 2);
                }

                for (int r = 0; r < rows; r++)
                {
                    for (int c = 0; c < cols; c++)
                    {
                        int idx = r * 16 + c;
                        int x = left + c * cell;
                        int y = top + r * cell;
                        Rectangle cellRect = new Rectangle(x, y, cell, cell);
                        g.DrawRectangle((r % 4 == 0 && c % 4 == 0) ? penBold : pen, cellRect);
                        byte cnt = _counts[idx];
                        if (cnt >= 2) g.FillRectangle(brushDup, cellRect);
                        else if (cnt == 1) g.FillRectangle(brushSingle, cellRect);
                    }
                }
            }
        }

        private void MemoryPageView_MouseMove(object sender, MouseEventArgs e)
        {
            Rectangle rc = this.ClientRectangle;
            int top = 56; int left = 26; int cols = 16, rows = 16;
            int cell = Math.Min((rc.Width - left - 24) / cols, (rc.Height - top - 24) / rows);
            if (cell < 10) cell = 10;
            int col = (e.X - left) / cell;
            int row = (e.Y - top) / cell;
            if (col >= 0 && col < cols && row >= 0 && row < rows)
            {
                int idx = row * 16 + col;
                int addr = _pageStart + idx;
                int cnt = (idx >= 0 && idx < 256) ? _counts[idx] : 0;
                _tip.SetToolTip(this, cnt >= 2 ? string.Format("0x{0:X5} (x{1})", addr, cnt) : string.Format("0x{0:X5}", addr));
            }
        }
    }
}
