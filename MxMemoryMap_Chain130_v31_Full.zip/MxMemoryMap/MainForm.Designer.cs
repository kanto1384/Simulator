using System.Windows.Forms;
using System.Drawing;

namespace MxMemoryMap
{
    partial class MainForm
    {
        private Panel panelTop;
        private TextBox txtInput;
        private TextBox txtNormalized;
        private Button btnGenerate;
        private Label lblHint;
        private SplitContainer splitMain;
        private TextBox txtOutput;
        private TableLayoutPanel tableRight;
        private ComboBox cboArea;
        private Label lblPageInfo;
        private Panel panelHeader;
        private ListBox lstPages;
        private MemoryPageView pageView;
        private Label lblSheetInfo;
        private ComboBox cboSpecMode;

        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblHint = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.txtNormalized = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.splitMain = new System.Windows.Forms.SplitContainer();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.tableRight = new System.Windows.Forms.TableLayoutPanel();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.cboArea = new System.Windows.Forms.ComboBox();
            this.lblPageInfo = new System.Windows.Forms.Label();
            this.lblSheetInfo = new System.Windows.Forms.Label();
            this.cboSpecMode = new System.Windows.Forms.ComboBox();
            this.lstPages = new System.Windows.Forms.ListBox();
            this.pageView = new MxMemoryMap.MemoryPageView();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMain)).BeginInit();
            this.splitMain.Panel1.SuspendLayout();
            this.splitMain.Panel2.SuspendLayout();
            this.splitMain.SuspendLayout();
            this.tableRight.SuspendLayout();
            this.panelHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.lblHint);
            this.panelTop.Controls.Add(this.btnGenerate);
            this.panelTop.Controls.Add(this.txtNormalized);
            this.panelTop.Controls.Add(this.txtInput);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Padding = new System.Windows.Forms.Padding(8);
            this.panelTop.Size = new System.Drawing.Size(1184, 120);
            this.panelTop.TabIndex = 0;
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Location = new System.Drawing.Point(8, 96);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(1094, 12);
            this.lblHint.TabIndex = 5;
            this.lblHint.Text = "엑셀 다중 드래그: VARIABLES/H. 수동: W:1000,1082&B:3000. 체인 규칙 ≤130. 페이지/툴팁/목록은 0xXXXXX 표기(5자리). 주소는 0xXXXXX00~0xXXXXXFF 단위로 표시.";
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(8, 64);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(160, 28);
            this.btnGenerate.TabIndex = 3;
            this.btnGenerate.Text = "메모리맵 생성";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // txtNormalized
            // 
            this.txtNormalized.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtNormalized.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtNormalized.Location = new System.Drawing.Point(8, 33);
            this.txtNormalized.Name = "txtNormalized";
            this.txtNormalized.ReadOnly = true;
            this.txtNormalized.Size = new System.Drawing.Size(1168, 25);
            this.txtNormalized.TabIndex = 2;
            // 
            // txtInput
            // 
            this.txtInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtInput.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtInput.Location = new System.Drawing.Point(8, 8);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(1168, 25);
            this.txtInput.TabIndex = 1;
            // 
            // splitMain
            // 
            this.splitMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitMain.Location = new System.Drawing.Point(0, 120);
            this.splitMain.Name = "splitMain";
            // 
            // splitMain.Panel1
            // 
            this.splitMain.Panel1.Controls.Add(this.txtOutput);
            // 
            // splitMain.Panel2
            // 
            this.splitMain.Panel2.Controls.Add(this.tableRight);
            this.splitMain.Size = new System.Drawing.Size(1184, 541);
            this.splitMain.SplitterDistance = 520;
            this.splitMain.TabIndex = 1;
            // 
            // txtOutput
            // 
            this.txtOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtOutput.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtOutput.Location = new System.Drawing.Point(0, 0);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOutput.Size = new System.Drawing.Size(520, 541);
            this.txtOutput.TabIndex = 0;
            this.txtOutput.WordWrap = false;
            // 
            // tableRight
            // 
            this.tableRight.ColumnCount = 2;
            this.tableRight.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320F));
            this.tableRight.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableRight.Controls.Add(this.panelHeader, 0, 0);
            this.tableRight.Controls.Add(this.lstPages, 0, 1);
            this.tableRight.Controls.Add(this.pageView, 1, 1);
            this.tableRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableRight.Location = new System.Drawing.Point(0, 0);
            this.tableRight.Name = "tableRight";
            this.tableRight.RowCount = 2;
            this.tableRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tableRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableRight.Size = new System.Drawing.Size(660, 541);
            this.tableRight.TabIndex = 0;
            // 
            // panelHeader
            // 
            this.tableRight.SetColumnSpan(this.panelHeader, 2);
            this.panelHeader.Controls.Add(this.cboSpecMode);
            this.panelHeader.Controls.Add(this.lblSheetInfo);
            this.panelHeader.Controls.Add(this.cboArea);
            this.panelHeader.Controls.Add(this.lblPageInfo);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHeader.Location = new System.Drawing.Point(3, 3);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Padding = new System.Windows.Forms.Padding(4, 8, 4, 4);
            this.panelHeader.Size = new System.Drawing.Size(654, 58);
            this.panelHeader.TabIndex = 0;
            // 
            // cboArea
            // 
            this.cboArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboArea.FormattingEnabled = true;
            this.cboArea.Location = new System.Drawing.Point(8, 16);
            this.cboArea.Name = "cboArea";
            this.cboArea.Size = new System.Drawing.Size(60, 20);
            this.cboArea.TabIndex = 0;
            this.cboArea.SelectedIndexChanged += new System.EventHandler(this.cboArea_SelectedIndexChanged);
            // 
            // lblPageInfo
            // 
            this.lblPageInfo.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblPageInfo.Location = new System.Drawing.Point(418, 8);
            this.lblPageInfo.Name = "lblPageInfo";
            this.lblPageInfo.Size = new System.Drawing.Size(232, 46);
            this.lblPageInfo.TabIndex = 7;
            this.lblPageInfo.Text = "페이지 없음";
            this.lblPageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSheetInfo
            // 
            this.lblSheetInfo.AutoSize = true;
            this.lblSheetInfo.Location = new System.Drawing.Point(72, 19);
            this.lblSheetInfo.Name = "lblSheetInfo";
            this.lblSheetInfo.Size = new System.Drawing.Size(277, 12);
            this.lblSheetInfo.TabIndex = 6;
            this.lblSheetInfo.Text = "Sheet: VARIABLES/H  (Excel drag&drop, 5-hex view)";
            // 
            // cboSpecMode
            // 
            this.cboSpecMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSpecMode.FormattingEnabled = true;
            this.cboSpecMode.Location = new System.Drawing.Point(72, 35);
            this.cboSpecMode.Name = "cboSpecMode";
            this.cboSpecMode.Size = new System.Drawing.Size(200, 20);
            this.cboSpecMode.TabIndex = 8;
            // 
            // lstPages
            // 
            this.lstPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstPages.Font = new System.Drawing.Font("Consolas", 10F);
            this.lstPages.FormattingEnabled = true;
            this.lstPages.IntegralHeight = false;
            this.lstPages.ItemHeight = 15;
            this.lstPages.Location = new System.Drawing.Point(3, 67);
            this.lstPages.Name = "lstPages";
            this.lstPages.Size = new System.Drawing.Size(314, 471);
            this.lstPages.TabIndex = 1;
            this.lstPages.SelectedIndexChanged += new System.EventHandler(this.lstPages_SelectedIndexChanged);
            // 
            // pageView
            // 
            this.pageView.BackColor = System.Drawing.Color.White;
            this.pageView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageView.Location = new System.Drawing.Point(323, 67);
            this.pageView.Name = "pageView";
            this.pageView.Size = new System.Drawing.Size(334, 471);
            this.pageView.TabIndex = 2;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 661);
            this.Controls.Add(this.splitMain);
            this.Controls.Add(this.panelTop);
            this.Name = "MainForm";
            this.Text = "MxComponent Memory Map (5-hex pages + Chain-130)";
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMain)).EndInit();
            this.splitMain.Panel1.ResumeLayout(false);
            this.splitMain.Panel1.PerformLayout();
            this.splitMain.Panel2.ResumeLayout(false);
            this.splitMain.ResumeLayout(false);
            this.tableRight.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}
