namespace MxMemoryMap
{
    public static class CoreInfo
    {
        public const int MaxGap = 130;
    }
}
