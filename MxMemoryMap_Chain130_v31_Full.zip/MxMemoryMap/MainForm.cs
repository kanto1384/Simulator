using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<SpecRange> _spec = new List<SpecRange>();
        private List<string> _lastExcelRows = new List<string>();

        public MainForm()
        {
            InitializeComponent();

            // 샘플: 수동 입력은 "W:1000,1082&B:3000" 형식
            txtInput.Text = "W:1000,1082";

            // 드래그&드롭
            this.AllowDrop = true;
            this.DragEnter += MainForm_DragEnter;
            this.DragDrop += MainForm_DragDrop;

            cboSpecMode.Items.AddRange(new object[] { "최적화(연결체인 130)", "원본 주소 목록" });
            cboSpecMode.SelectedIndex = 0;
            cboSpecMode.SelectedIndexChanged += (_, __) => UpdateNormalizedBox();
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Any(f => Path.GetExtension(f).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)))
                { e.Effect = DragDropEffects.Copy; return; }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;

                var allRows = new List<string>();
                int used = 0, skipped = 0;
                foreach (var file in files)
                {
                    if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)) { skipped++; continue; }
                    var sheet = SimpleXlsx.FindSheetByName(file, "VARIABLES");
                    if (sheet == null) { skipped++; continue; }
                    var rows = SimpleXlsx.ReadColumnStrings(file, sheet.Target, "H");
                    if (rows.Count == 0) { skipped++; continue; }
                    allRows.AddRange(rows);
                    used++;
                }

                if (allRows.Count == 0)
                {
                    MessageBox.Show("가져올 데이터가 없습니다. (.xlsx / VARIABLES 시트 / H열)");
                    return;
                }

                _lastExcelRows = allRows;
                lblSheetInfo.Text = $"VARIABLES/H  Files={used}, Skipped={skipped}";

                BuildFromExcelRows(allRows);
            }
            catch (Exception ex)
            {
                MessageBox.Show("엑셀 처리 오류: " + ex.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            // 수동 입력 파싱: "A:1000,1010,10FF&B:3000" ...
            try
            {
                var dict = ParseAreaAddressList(txtInput.Text ?? string.Empty);
                BuildFromAreaAddressDict(dict, sourceLabel: "(수동 입력)");
                _lastExcelRows.Clear(); // 수동으로 전환 시 엑셀캐시 무시
            }
            catch (Exception ex)
            {
                txtOutput.Text = "[에러] " + ex.Message;
            }
        }

        private const int MaxGap = 130; // 두 주소 간 차 ≤130 이면 같은 체인

        private void BuildFromExcelRows(List<string> rows)
        {
            var dict = new Dictionary<char, SortedSet<int>>();
            foreach (var row in rows)
            {
                var kv = ParseKeyValues(row);
                if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;

                char area = char.ToUpperInvariant(dev.Trim()[0]);
                if (!TryParseHex(addr, out int a)) continue;

                if (!dict.TryGetValue(area, out var set)) { set = new SortedSet<int>(); dict[area] = set; }
                set.Add(a);
            }
            BuildFromAreaAddressDict(dict.ToDictionary(k => k.Key, v => v.Value.ToList()), "Excel");
        }

        private void BuildFromAreaAddressDict(Dictionary<char, List<int>> areaAddrs, string sourceLabel)
        {
            var map = new MemoryMap();
            var spec = new List<SpecRange>();
            var sb = new StringBuilder();

            sb.AppendLine($"[원본 주소 개수]  {string.Join(\"  \", areaAddrs.OrderBy(p=>p.Key).Select(p=>$\"{p.Key}:{p.Value.Count}\"))}");
            sb.AppendLine();

            foreach (var kv in areaAddrs.OrderBy(p => AreaOrderKey(p.Key)))
            {
                char area = kv.Key;
                var addrs = kv.Value.Distinct().OrderBy(x => x).ToList();
                if (addrs.Count == 0) continue;
                sb.AppendLine($\"[{area}] 입력주소: {string.Join(\",\", addrs.Select(x => $\"0x{x:X}\"))}\");

                int start = addrs[0];
                int last = start;
                for (int i = 1; i < addrs.Count; i++)
                {
                    int a = addrs[i];
                    if (a - last <= MaxGap) { last = a; continue; } // 같은 체인
                    // 체인 종료 기록
                    int used = last - start + 1;            // 실제 사용 개수
                    spec.Add(new SpecRange(area, start, used + 1)); // 출력 count = used+1
                    map.Segments.Add(new Segment(area, start, used));
                    sb.AppendLine($\" -> 체인: 0x{start:X} ~ 0x{last:X}  used={used}  count_out={used + 1}  end_excl=0x{(start + used):X}\");
                    // 새 체인
                    start = last = a;
                }
                // 마지막 체인
                int usedLast = last - start + 1;
                spec.Add(new SpecRange(area, start, usedLast + 1));
                map.Segments.Add(new Segment(area, start, usedLast));
                sb.AppendLine($\" -> 체인: 0x{start:X} ~ 0x{last:X}  used={usedLast}  count_out={usedLast + 1}  end_excl=0x{(start + usedLast):X}\");
                sb.AppendLine();
            }

            _map = map;
            _spec = spec;

            txtOutput.Text = $"[소스] {sourceLabel}\r\n" + sb.ToString();
            UpdateNormalizedBox();
            FillAreaAndPages();
        }

        private static Dictionary<char, List<int>> ParseAreaAddressList(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) throw new ArgumentException("입력이 비어 있습니다.");
            if (s.StartsWith("MEMORY=", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);

            var dict = new Dictionary<char, List<int>>();
            foreach (var part in s.Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = part.Trim();
                if (p.Length < 3 || p[1] != ':') throw new FormatException($"형식 오류: '{p}' (예: W:1000,1082)");
                char area = char.ToUpperInvariant(p[0]);
                var addrList = p.Substring(2).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var token in addrList)
                {
                    if (!TryParseHex(token.Trim(), out int a)) continue;
                    if (!dict.TryGetValue(area, out var list)) { list = new List<int>(); dict[area] = list; }
                    list.Add(a);
                }
            }
            return dict.ToDictionary(k => k.Key, v => v.Value.Distinct().OrderBy(x => x).ToList());
        }

        private void UpdateNormalizedBox()
        {
            if (cboSpecMode.SelectedIndex == 1)
            {
                // 원본 주소 보기
                if (_lastExcelRows.Count > 0)
                {
                    var dict = new Dictionary<char, SortedSet<int>>();
                    foreach (var row in _lastExcelRows)
                    {
                        var kv = ParseKeyValues(row);
                        if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                        if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;
                        char area = char.ToUpperInvariant(dev.Trim()[0]);
                        if (!TryParseHex(addr, out int a)) continue;
                        if (!dict.TryGetValue(area, out var set)) { set = new SortedSet<int>(); dict[area] = set; }
                        set.Add(a);
                    }
                    txtNormalized.Text = string.Join(\"&\", dict.OrderBy(p => AreaOrderKey(p.Key)).Select(p => $\"{p.Key}:{string.Join(\",\", p.Value.Select(x => x.ToString(\"X\")))}\"));
                }
                else
                {
                    txtNormalized.Text = txtInput.Text;
                }
            }
            else
            {
                txtNormalized.Text = string.Join(\"&\", _spec.OrderBy(p => AreaOrderKey(p.Area)).ThenBy(p => p.StartHex).Select(p => $\"{p.Area}:{p.StartHex:X}:{p.CountOut}\"));
            }
        }

        private void FillAreaAndPages()
        {
            cboArea.Items.Clear();
            foreach (char area in _map.Segments.Select(s => s.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                cboArea.Items.Add(area);
            if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
            else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) => RefreshPages();
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) => ShowSelectedPage();

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_map == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _map.Segments.Where(m => m.Area == area).ToList();

            var pages = new SortedSet<int>(); // 상위는 보존, 하위 8비트 0: 0xXXXXX00
            foreach (var r in ranges)
            {
                int start = r.StartHex;
                int endIncl = r.StartHex + r.Count - 1; // used inclusive
                int pageStart = start & ~0xFF;
                int pageEnd = endIncl & ~0xFF;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
                lstPages.Items.Add($"0x{p:X5} - 0x{p + 0xFF:X5}");
            lblPageInfo.Text = pages.Count > 0 ? $"페이지 {pages.Count}개" : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_map == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var text = lstPages.SelectedItem.ToString();
            if (string.IsNullOrEmpty(text)) return;

            var m = Regex.Match(text, @"0x([0-9A-Fa-f]+)");
            if (!m.Success) return;
            int pageStart = int.Parse(m.Groups[1].Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture);

            var counts = new byte[256];
            foreach (var s in _map.Segments.Where(mg => char.ToUpperInvariant(mg.Area) == area))
            {
                int sAddr = Math.Max(s.StartHex, pageStart);
                int eAddr = Math.Min(s.StartHex + s.Count - 1, pageStart + 0xFF);
                if (eAddr < sAddr) continue;
                for (int addr = sAddr; addr <= eAddr; addr++)
                {
                    int idx = addr - pageStart;
                    if (idx >= 0 && idx < 256)
                    {
                        if (counts[idx] < 255) counts[idx]++;
                    }
                }
            }
            pageView.SetPage(area, pageStart, counts);
        }

        // --- helpers ---
        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }

        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var parts = s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var kv = p.Split(new[] { '=' }, 2);
                if (kv.Length == 2) dict[kv[0].Trim()] = kv[1].Trim();
            }
            return dict;
        }

        private static bool TryParseHex(string token, out int val)
        {
            val = 0;
            if (string.IsNullOrWhiteSpace(token)) return false;
            token = token.Trim();
            // 허용: "0x1083" 또는 "1083" (항상 16진)
            if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            return int.TryParse(token, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
        }
    }

    // 내부 데이터 구조
    public class Segment
    {
        public char Area;
        public int StartHex;
        public int Count; // used = end - start + 1

        public Segment(char area, int startHex, int used)
        {
            Area = area; StartHex = startHex; Count = used;
        }
    }

    public class MemoryMap
    {
        public List<Segment> Segments { get; } = new List<Segment>();
    }

    // 출력 스펙: count_out = used + 1
    public class SpecRange
    {
        public char Area;
        public int StartHex;
        public int CountOut;

        public SpecRange(char area, int start, int countOut)
        {
            Area = area; StartHex = start; CountOut = countOut;
        }
    }
}
