# RemotePortalMapper

WinForms (.NET 9) sample app that:
- Shows your internal HTTPS portal inside **WebView2**
- Extracts IP/Hostname from `table#seltable` (6th td = IP, 7th td = Host)
- Maps them to equipment metadata from a local JSON file (`data/device_map.json`)
- Shows the mapped result in a right-side DataGridView.

## Build
1. Install .NET SDK 9.x
2. Open `src/RemotePortalMapper/RemotePortalMapper.csproj` in Visual Studio (or run `dotnet build`)
3. Restore NuGet packages (WebView2)
4. Run

## How to use
- Enter portal URL (or internal IP) and click **Go**
- Log in + 2FA inside the WebView
- Use portal's own filter/favorites to narrow the list
- Click **Extract**
- Edit mapping file: `bin/.../data/device_map.json` (or the one under project `data/`), then click **Reload map**

## Shortcuts
- Ctrl+L: focus URL
- Ctrl+E: extract
- Ctrl+F: focus search

## Mapping file format
See `data/device_map.json` for an example.
