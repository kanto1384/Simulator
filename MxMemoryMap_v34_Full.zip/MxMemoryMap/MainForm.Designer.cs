
using System.Windows.Forms;
using System.Drawing;

namespace MxMemoryMap
{
    partial class MainForm
    {
        private Panel panelTop;
        private TextBox txtInput;
        private TextBox txtNormalized;
        private Button btnGenerate;
        private Label lblHint;
        private SplitContainer splitMain;
        private TextBox txtOutput;
        private TableLayoutPanel tableRight;
        private ComboBox cboArea;
        private Label lblPageInfo;
        private Panel panelHeader;
        private ListBox lstPages;
        private MemoryPageView pageView;
        private Label lblSheetInfo;
        private ComboBox cboSpecMode;

        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblHint = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.txtNormalized = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.splitMain = new System.Windows.Forms.SplitContainer();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.tableRight = new System.Windows.Forms.TableLayoutPanel();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.cboArea = new System.Windows.Forms.ComboBox();
            this.lblPageInfo = new System.Windows.Forms.Label();
            this.lblSheetInfo = new System.Windows.Forms.Label();
            this.cboSpecMode = new System.Windows.Forms.ComboBox();
            this.lstPages = new System.Windows.Forms.ListBox();
            this.pageView = new MxMemoryMap.MemoryPageView();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMain)).BeginInit();
            this.splitMain.Panel1.SuspendLayout();
            this.splitMain.Panel2.SuspendLayout();
            this.splitMain.SuspendLayout();
            this.tableRight.SuspendLayout();
            this.panelHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.lblHint);
            this.panelTop.Controls.Add(this.btnGenerate);
            this.panelTop.Controls.Add(this.txtNormalized);
            this.panelTop.Controls.Add(this.txtInput);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Padding = new System.Windows.Forms.Padding(8);
            this.panelTop.Size = new System.Drawing.Size(1184, 120);
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Location = new System.Drawing.Point(8, 96);
            this.lblHint.Size = new System.Drawing.Size(1000, 12);
            this.lblHint.Text = "엑셀 드래그: VARIABLES/H. 수동: W:10960:10&D:10960:10  • HEX(B/W/X/Y) 16진 • DEC(M/D/R/L/ZR) 10진 • LENGTH*2 • 체인≤130 • W체인 0x???000 분할";
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(8, 64);
            this.btnGenerate.Size = new System.Drawing.Size(160, 28);
            this.btnGenerate.Text = "메모리맵 생성";
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // txtNormalized
            // 
            this.txtNormalized.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtNormalized.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtNormalized.ReadOnly = true;
            this.txtNormalized.Size = new System.Drawing.Size(1168, 25);
            // 
            // txtInput
            // 
            this.txtInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtInput.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtInput.Size = new System.Drawing.Size(1168, 25);
            // 
            // splitMain
            // 
            this.splitMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitMain.SplitterDistance = 520;
            // 
            // splitMain.Panel1
            // 
            this.splitMain.Panel1.Controls.Add(this.txtOutput);
            // 
            // splitMain.Panel2
            // 
            this.splitMain.Panel2.Controls.Add(this.tableRight);
            // 
            // txtOutput
            // 
            this.txtOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtOutput.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtOutput.Multiline = true;
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOutput.WordWrap = false;
            // 
            // tableRight
            // 
            this.tableRight.ColumnCount = 2;
            this.tableRight.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320F));
            this.tableRight.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableRight.Controls.Add(this.panelHeader, 0, 0);
            this.tableRight.Controls.Add(this.lstPages, 0, 1);
            this.tableRight.Controls.Add(this.pageView, 1, 1);
            this.tableRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableRight.RowCount = 2;
            this.tableRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tableRight.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            // 
            // panelHeader
            // 
            this.tableRight.SetColumnSpan(this.panelHeader, 2);
            this.panelHeader.Controls.Add(this.cboSpecMode);
            this.panelHeader.Controls.Add(this.lblSheetInfo);
            this.panelHeader.Controls.Add(this.cboArea);
            this.panelHeader.Controls.Add(this.lblPageInfo);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHeader.Padding = new System.Windows.Forms.Padding(4, 8, 4, 4);
            this.panelHeader.Size = new System.Drawing.Size(654, 58);
            // 
            // cboArea
            // 
            this.cboArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboArea.Location = new System.Drawing.Point(8, 16);
            this.cboArea.Size = new System.Drawing.Size(60, 20);
            this.cboArea.SelectedIndexChanged += new System.EventHandler(this.cboArea_SelectedIndexChanged);
            // 
            // lblPageInfo
            // 
            this.lblPageInfo.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblPageInfo.Size = new System.Drawing.Size(232, 46);
            this.lblPageInfo.Text = "페이지 없음";
            this.lblPageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSheetInfo
            // 
            this.lblSheetInfo.AutoSize = true;
            this.lblSheetInfo.Location = new System.Drawing.Point(72, 19);
            this.lblSheetInfo.Text = "Sheet: VARIABLES/H (Excel drag&drop)";
            // 
            // cboSpecMode
            // 
            this.cboSpecMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSpecMode.Location = new System.Drawing.Point(72, 35);
            this.cboSpecMode.Size = new System.Drawing.Size(220, 20);
            // 
            // lstPages
            // 
            this.lstPages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstPages.Font = new System.Drawing.Font("Consolas", 10F);
            this.lstPages.IntegralHeight = false;
            this.lstPages.ItemHeight = 15;
            this.lstPages.SelectedIndexChanged += new System.EventHandler(this.lstPages_SelectedIndexChanged);
            // 
            // pageView
            // 
            this.pageView.BackColor = System.Drawing.Color.White;
            this.pageView.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(1184, 661);
            this.Controls.Add(this.splitMain);
            this.Controls.Add(this.panelTop);
            this.Text = "MxComponent Memory Map (v3.4)";
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitMain)).EndInit();
            this.splitMain.Panel1.ResumeLayout(false);
            this.splitMain.Panel1.PerformLayout();
            this.splitMain.Panel2.ResumeLayout(false);
            this.splitMain.ResumeLayout(false);
            this.tableRight.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}
