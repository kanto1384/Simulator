
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<SpecRange> _spec = new List<SpecRange>();
        private List<string> _lastExcelRows = new List<string>();

        private static readonly HashSet<char> HexAreas = new HashSet<char>(new[] { 'B', 'W', 'X', 'Y' });
        private static readonly HashSet<char> DecAreas = new HashSet<char>(new[] { 'M', 'D', 'R', 'L', 'Z' }); // ZR -> Z
        private const int MaxGap = 130;

        public MainForm()
        {
            InitializeComponent();
            txtInput.Text = "W:10960:10&D:10960:10";
            AllowDrop = true;
            DragEnter += MainForm_DragEnter;
            DragDrop += MainForm_DragDrop;
            cboSpecMode.Items.AddRange(new object[] { "최적화(LENGTH 기반, 체인≤130)", "원본 주소 목록" });
            cboSpecMode.SelectedIndex = 0;
            cboSpecMode.SelectedIndexChanged += (_, __) => UpdateNormalizedBox();
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Any(f => Path.GetExtension(f).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))) { e.Effect = DragDropEffects.Copy; return; }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;

                var allRows = new List<string>();
                int used = 0, skipped = 0;
                foreach (var file in files)
                {
                    if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)) { skipped++; continue; }
                    var sheet = SimpleXlsx.FindSheetByName(file, "VARIABLES");
                    if (sheet == null) { skipped++; continue; }
                    var rows = SimpleXlsx.ReadColumnStrings(file, sheet.Target, "H");
                    if (rows.Count == 0) { skipped++; continue; }
                    allRows.AddRange(rows); used++;
                }
                if (allRows.Count == 0) { MessageBox.Show("가져올 데이터가 없습니다. (.xlsx / VARIABLES 시트 / H열)"); return; }
                _lastExcelRows = allRows;
                lblSheetInfo.Text = $"VARIABLES/H  Files={used}, Skipped={skipped}";
                BuildFromExcelRows(allRows);
            }
            catch (Exception ex) { MessageBox.Show("엑셀 처리 오류: " + ex.Message); }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                var dict = ParseAreaAddressLenList(txtInput.Text ?? string.Empty);
                BuildFromAreaEntries(dict, "(수동 입력)");
                _lastExcelRows.Clear();
            }
            catch (Exception ex) { txtOutput.Text = "[에러] " + ex.Message; }
        }

        private void BuildFromExcelRows(List<string> rows)
        {
            var entries = new Dictionary<char, List<Entry>>();
            foreach (var row in rows)
            {
                var kv = ParseKeyValues(row);
                if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;

                int len = 1;
                if (kv.TryGetValue("LENGTH", out var lt) && !string.IsNullOrWhiteSpace(lt)) { int.TryParse(lt.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out len); if (len <= 0) len = 1; }
                var areaChar = dev.Trim().ToUpperInvariant()[0]; // ZR -> Z
                if (!TryParseByArea(areaChar, addr, out int start)) continue;
                int span = len * 2;
                int end = start + span;

                if (!entries.TryGetValue(areaChar, out var list)) { list = new List<Entry>(); entries[areaChar] = list; }
                list.Add(new Entry(areaChar, start, end, span));
            }
            BuildFromAreaEntries(entries, "Excel");
        }

        private void BuildFromAreaEntries(Dictionary<char, List<Entry>> perAreaEntries, string sourceLabel)
        {
            var sb = new StringBuilder();
            var outSpec = new List<SpecRange>();
            var map = new MemoryMap();

            foreach (var kv in perAreaEntries.OrderBy(p => AreaOrderKey(p.Key)))
            {
                char area = kv.Key;
                var list = kv.Value.OrderBy(e => e.Start).ThenBy(e => e.End).ToList();
                if (list.Count == 0) continue;

                sb.AppendLine($"[{area}] 입력건수={list.Count}  예: {FormatByArea(area, list[0].Start)},LEN*2={list[0].Span}");
                // 체인화 (gap ≤130)
                var chains = new List<List<Entry>>();
                var cur = new List<Entry>();
                foreach (var e in list)
                {
                    if (cur.Count == 0) { cur.Add(e); continue; }
                    var last = cur[cur.Count - 1];
                    if (e.Start - last.End <= 130) cur.Add(e);
                    else { chains.Add(cur); cur = new List<Entry> { e }; }
                }
                if (cur.Count > 0) chains.Add(cur);

                foreach (var chain in chains)
                {
                    int chainStart = chain.First().Start;
                    int chainEnd = chain.Last().End;
                    if (HexAreas.Contains(area))
                    {
                        foreach (var piece in SplitByHexThousand(chain))
                            outSpec.Add(new SpecRange(area, piece.Start, piece.TotalSpan));
                    }
                    else
                    {
                        outSpec.Add(new SpecRange(area, chainStart, chain.Sum(e => e.Span)));
                    }
                    map.Segments.Add(new Segment(area, chainStart, chainEnd - chainStart));
                    sb.AppendLine($" -> 체인: {FormatByArea(area, chainStart)} ~ {FormatByArea(area, chainEnd)}  spanSum={chain.Sum(e=>e.Span)}");
                }
                sb.AppendLine();
            }

            _spec = outSpec.OrderBy(s => AreaOrderKey(s.Area)).ThenBy(s => s.StartHex).ToList();
            _map = map;

            txtOutput.Text = $"[소스] {sourceLabel}
" + sb.ToString();
            UpdateNormalizedBox();
            FillAreaAndPages();
        }

        private static List<SpanPiece> SplitByHexThousand(List<Entry> chain)
        {
            var pieces = new List<SpanPiece>();
            foreach (var e in chain)
            {
                int p = e.Start;
                int end = e.End;
                while (p < end)
                {
                    int nextBoundary = ((p / 0x1000) + 1) * 0x1000;
                    int segEnd = Math.Min(end, nextBoundary);
                    int span = segEnd - p;
                    if (pieces.Count > 0 && pieces[pieces.Count - 1].Start + pieces[pieces.Count - 1].TotalSpan == p &&
                        (p / 0x1000) == (pieces[pieces.Count - 1].Start / 0x1000))
                        pieces[pieces.Count - 1].TotalSpan += span;
                    else
                        pieces.Add(new SpanPiece { Start = p, TotalSpan = span });
                    p = segEnd;
                }
            }
            return pieces;
        }

        private static Dictionary<char, List<Entry>> ParseAreaAddressLenList(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) throw new ArgumentException("입력이 비어 있습니다.");
            if (s.StartsWith("MEMORY=", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);
            var dict = new Dictionary<char, List<Entry>>();
            foreach (var part in s.Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = part.Trim();
                int colon = p.IndexOf(':');
                if (colon <= 0) throw new FormatException($"형식 오류: '{p}' (예: W:10960:10 또는 W:10960,1082)");
                string areaToken = p.Substring(0, colon).Trim().ToUpperInvariant();
                char area = areaToken[0];
                var rest = p.Substring(colon + 1);

                foreach (var token in rest.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var t = token.Trim();
                    int addr; int len = 1;
                    var parts2 = t.Split(':');
                    if (parts2.Length == 1)
                    {
                        if (!TryParseByArea(area, parts2[0], out addr)) continue;
                    }
                    else
                    {
                        if (!TryParseByArea(area, parts2[0], out addr)) continue;
                        int.TryParse(parts2[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out len);
                        if (len <= 0) len = 1;
                    }
                    int span = len * 2;
                    int end = addr + span;
                    if (!dict.TryGetValue(area, out var list)) { list = new List<Entry>(); dict[area] = list; }
                    list.Add(new Entry(area, addr, end, span));
                }
            }
            return dict;
        }

        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var part in s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var kv = part.Split(new[] { '=' }, 2);
                if (kv.Length == 2) dict[kv[0].Trim()] = kv[1].Trim();
            }
            return dict;
        }

        private static bool TryParseByArea(char area, string token, out int val)
        {
            val = 0; if (string.IsNullOrWhiteSpace(token)) return false;
            token = token.Trim(); area = char.ToUpperInvariant(area);
            if (DecAreas.Contains(area))
            {
                if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
                return int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
            }
            else
            {
                if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
                return int.TryParse(token, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            }
        }

        private static string FormatByArea(char area, int value)
        {
            area = char.ToUpperInvariant(area);
            if (HexAreas.Contains(area)) return $"0x{value:X}";
            return value.ToString(CultureInfo.InvariantCulture);
        }

        // UI helpers
        private void UpdateNormalizedBox()
        {
            if (_spec == null) { txtNormalized.Text = string.Empty; return; }
            if (cboSpecMode.SelectedIndex == 1)
            {
                if (_lastExcelRows.Count > 0)
                {
                    var dict = new Dictionary<char, SortedSet<string>>();
                    foreach (var row in _lastExcelRows)
                    {
                        var kv = ParseKeyValues(row);
                        if (!kv.TryGetValue("DEVICE_TYPE", out var dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@") continue;
                        if (!kv.TryGetValue("ADDRESS_NO", out var addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@") continue;
                        char area = dev.Trim().ToUpperInvariant()[0];
                        if (!dict.TryGetValue(area, out var set)) { set = new SortedSet<string>(); dict[area] = set; }
                        set.Add(addr.Trim());
                    }
                    txtNormalized.Text = string.Join("&", dict.OrderBy(p => AreaOrderKey(p.Key)).Select(p => $"{p.Key}:{string.Join(",", p.Value)}"));
                }
                else txtNormalized.Text = txtInput.Text;
            }
            else
            {
                txtNormalized.Text = string.Join("&",
                    _spec.OrderBy(s => AreaOrderKey(s.Area)).ThenBy(s => s.StartHex)
                         .Select(s => $"{s.Area}:{FormatByArea(s.Area, s.StartHex).Replace("0x", "")}:{s.CountOut}"));
            }
        }

        private void FillAreaAndPages()
        {
            cboArea.Items.Clear();
            foreach (char area in _map.Segments.Select(s => s.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                cboArea.Items.Add(area);
            if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
            else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) => RefreshPages();
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) => ShowSelectedPage();

        private class PageItem { public int Start; public string Text; public override string ToString() => Text; }

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_map == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _map.Segments.Where(m => m.Area == area).ToList();
            var pages = new SortedSet<int>();
            foreach (var r in ranges)
            {
                int start = r.StartHex;
                int endExcl = r.StartHex + r.Count;
                int pageStart = start & ~0xFF;
                int pageEnd = (endExcl - 1) & ~0xFF;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
            {
                string label = HexAreas.Contains(area) ? $"0x{p:X5} - 0x{p + 0xFF:X5}" : $"{p} - {p + 0xFF}";
                lstPages.Items.Add(new PageItem { Start = p, Text = label });
            }
            lblPageInfo.Text = pages.Count > 0 ? $"페이지 {pages.Count}개" : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_map == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var item = lstPages.SelectedItem as PageItem; if (item == null) return;
            int pageStart = item.Start;
            var counts = new byte[256];
            foreach (var s in _map.Segments.Where(mg => char.ToUpperInvariant(mg.Area) == area))
            {
                int sAddr = Math.Max(s.StartHex, pageStart);
                int eAddr = Math.Min(s.StartHex + s.Count - 1, pageStart + 0xFF);
                if (eAddr < sAddr) continue;
                for (int addr = sAddr; addr <= eAddr; addr++)
                {
                    int idx = addr - pageStart;
                    if (idx >= 0 && idx < 256 && counts[idx] < 255) counts[idx]++;
                }
            }
            bool isHex = HexAreas.Contains(area);
            pageView.SetPage(area, pageStart, counts, isHex);
        }

        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }
    }

    // Data structures
    public class Entry
    {
        public char Area; public int Start; public int End; public int Span;
        public Entry(char area, int start, int end, int span) { Area = area; Start = start; End = end; Span = span; }
    }

    public class SpanPiece { public int Start; public int TotalSpan; }

    public class Segment
    {
        public char Area; public int StartHex; public int Count; // end-exclusive offset
        public Segment(char area, int startHex, int used) { Area = area; StartHex = startHex; Count = used; }
    }

    public class MemoryMap { public List<Segment> Segments { get; } = new List<Segment>(); }

    public class SpecRange
    {
        public char Area; public int StartHex; public int CountOut;
        public SpecRange(char area, int start, int countOut) { Area = area; StartHex = start; CountOut = countOut; }
    }
}
