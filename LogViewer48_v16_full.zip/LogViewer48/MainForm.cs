using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogViewer48
{
    public class LogRow
    {
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Device { get; set; }
        public string Var { get; set; }
        public string SourceFile { get; set; }
        public long LineIndex { get; set; }
        public double? DurationSeconds { get; set; }
        public bool IsOneLiner { get; set; } // "... : START" notification style
    }

    public class Session
    {
        public string Var { get; set; }
        public string StartFile { get; set; }
        public int StartIdx { get; set; } = -1;
        public DateTime StartTs { get; set; }

        public string SuccessFile { get; set; }
        public int SuccessIdx { get; set; } = -1;
        public DateTime SuccessTs { get; set; }

        public string EndFile { get; set; }
        public int EndIdx { get; set; } = -1;
        public DateTime EndTs { get; set; }
    }

    public class MainForm : Form
    {
        TextBox txtFolder;
        Button btnBrowse;
        TextBox txtPrefix;
        Button btnLoad;
        CheckBox chkBROneLiners;
        Label lblThresh;
        NumericUpDown numThreshold;
        Label lblSearch;
        TextBox txtSearchVar;
        Button btnSearch, btnClear;

        DataGridView grid;
        SplitContainer split;
        StatusStrip statusStrip;
        ToolStripStatusLabel statusLabel;
        ToolStripProgressBar statusProgress;

        FileSystemWatcher watcher;
        readonly object locker = new object();
        readonly List<LogRow> rows = new List<LogRow>();
        List<LogRow> viewRows = new List<LogRow>();
        readonly BindingSource bs = new BindingSource();
        readonly Dictionary<string, bool> sortAsc = new Dictionary<string, bool>();

        readonly List<Session> sessions = new List<Session>();
        readonly Dictionary<string, string[]> fileCache = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);

        readonly Regex headRx = new Regex(
            @"^(?<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+\[(?<level>[^\]]+)\]\s+(?<rest>.*)$",
            RegexOptions.Compiled);

        readonly Regex bracketRx = new Regex(@"^\[(?<tok>[^\]]+)\]\s*", RegexOptions.Compiled);

        int colIndexTimestamp, colIndexVar;

        public MainForm()
        {
            Text = "Log Viewer (.NET Framework 4.8)";
            Width = 1400;
            Height = 820;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, Padding = new Padding(6), AutoSize = false, WrapContents = false };
            txtFolder = new TextBox { Width = 430 };
            btnBrowse = new Button { Text = "경로...", Width = 70 };
            txtPrefix = new TextBox { Width = 120, Text = "RollMapElm" };
            btnLoad = new Button { Text = "불러오기", Width = 90 };
            chkBROneLiners = new CheckBox { Text = "BR_ 1줄만", AutoSize = true, Margin = new Padding(6, 10, 0, 0) };

            lblThresh = new Label { Text = "소요(초) ≥", AutoSize = true, Margin = new Padding(12, 10, 4, 0) };
            numThreshold = new NumericUpDown { Width = 80, DecimalPlaces = 3, Increment = 0.100M, Minimum = 0, Maximum = 3600, Value = 5.000M };

            lblSearch = new Label { Text = "변수 검색:", AutoSize = true, Margin = new Padding(12, 10, 4, 0) };
            txtSearchVar = new TextBox { Width = 160 };
            btnSearch = new Button { Text = "검색", Width = 60 };
            btnClear = new Button { Text = "초기화", Width = 60 };

            top.Controls.Add(new Label { Text = "폴더:", AutoSize = true, Margin = new Padding(0, 10, 4, 0) });
            top.Controls.Add(txtFolder);
            top.Controls.Add(btnBrowse);
            top.Controls.Add(new Label { Text = "Prefix:", AutoSize = true, Margin = new Padding(12, 10, 4, 0) });
            top.Controls.Add(txtPrefix);
            top.Controls.Add(btnLoad);
            top.Controls.Add(chkBROneLiners);
            top.Controls.Add(lblThresh);
            top.Controls.Add(numThreshold);
            top.Controls.Add(lblSearch);
            top.Controls.Add(txtSearchVar);
            top.Controls.Add(btnSearch);
            top.Controls.Add(btnClear);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 760 };
            split.Panel1.Padding = new Padding(0, 0, 0, 10);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoGenerateColumns = false,
                AllowUserToOrderColumns = true
            };

            var colTs = new DataGridViewTextBoxColumn { HeaderText = "날짜시간", DataPropertyName = "Timestamp", Width = 200, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd HH:mm:ss.fff" } };
            colTs.Tag = "날짜시간";
            var colLevel = new DataGridViewTextBoxColumn { HeaderText = "레벨", DataPropertyName = "Level", Width = 80, SortMode = DataGridViewColumnSortMode.Programmatic };
            colLevel.Tag = "레벨";
            var colDevice = new DataGridViewTextBoxColumn { HeaderText = "장비", DataPropertyName = "Device", Width = 180, SortMode = DataGridViewColumnSortMode.Programmatic };
            colDevice.Tag = "장비";
            var colVar = new DataGridViewTextBoxColumn { HeaderText = "변수", DataPropertyName = "Var", Width = 260, SortMode = DataGridViewColumnSortMode.Programmatic };
            colVar.Tag = "변수";
            var colDur = new DataGridViewTextBoxColumn { HeaderText = "소요(초)", DataPropertyName = "DurationSeconds", Width = 110, SortMode = DataGridViewColumnSortMode.Programmatic, DefaultCellStyle = new DataGridViewCellStyle { Format = "N3" } };
            colDur.Tag = "소요(초)";

            grid.Columns.AddRange(new DataGridViewColumn[] { colTs, colLevel, colDevice, colVar, colDur });
            colIndexTimestamp = 0;
            colIndexVar = 3;

            split.Panel1.Controls.Add(grid);
            split.Panel2Collapsed = true;

            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel("대기 중");
            statusProgress = new ToolStripProgressBar() { Style = ProgressBarStyle.Blocks, Visible = false };
            statusStrip.Items.Add(statusLabel);
            statusStrip.Items.Add(new ToolStripStatusLabel() { Spring = true });
            statusStrip.Items.Add(statusProgress);

            Controls.Add(split);
            Controls.Add(top);
            Controls.Add(statusStrip);

            btnBrowse.Click += (s, e) => BrowseFolder();
            btnLoad.Click += async (s, e) => await LoadAllAsync();
            btnSearch.Click += (s, e) => ApplyFilterAndBind();
            btnClear.Click += (s, e) => { txtSearchVar.Text = ""; ApplyFilterAndBind(); };
            numThreshold.ValueChanged += (s, e) => grid.Refresh();
            chkBROneLiners.CheckedChanged += (s, e) => ApplyFilterAndBind();

            grid.CellDoubleClick += Grid_CellDoubleClick;
            grid.ColumnHeaderMouseClick += Grid_ColumnHeaderMouseClick;
            grid.RowPrePaint += Grid_RowPrePaint;
        }

        private void Grid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= grid.Rows.Count) return;
            var row = grid.Rows[e.RowIndex].DataBoundItem as LogRow;
            if (row == null) return;

            if (e.ColumnIndex == colIndexTimestamp)
            {
                var fp = Path.Combine(txtFolder.Text, row.SourceFile);
                try { Process.Start(new ProcessStartInfo(fp) { UseShellExecute = true }); }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
            else
            {
                ShowDetailBySession(row);
            }
        }

        private void Grid_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= grid.Rows.Count) return;
            var row = grid.Rows[e.RowIndex].DataBoundItem as LogRow;
            if (row == null) return;
            var th = (double)numThreshold.Value;
            grid.Rows[e.RowIndex].DefaultCellStyle.BackColor =
                (row.DurationSeconds.HasValue && row.DurationSeconds.Value >= th)
                ? Color.FromArgb(255, 255, 220, 220) : Color.White;
        }

        private void Grid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex < 0) return;
            var col = grid.Columns[e.ColumnIndex];
            string prop = col.DataPropertyName;
            bool asc;
            if (!sortAsc.TryGetValue(prop, out asc)) asc = true; else asc = !asc;
            sortAsc[prop] = asc;

            foreach (DataGridViewColumn c in grid.Columns)
                c.HeaderText = (string)(c.Tag ?? c.HeaderText);

            IEnumerable<LogRow> sorted;
            switch (prop)
            {
                case "Timestamp": sorted = asc ? viewRows.OrderBy(r => r.Timestamp) : viewRows.OrderByDescending(r => r.Timestamp); break;
                case "Level": sorted = asc ? viewRows.OrderBy(r => r.Level) : viewRows.OrderByDescending(r => r.Level); break;
                case "Device": sorted = asc ? viewRows.OrderBy(r => r.Device) : viewRows.OrderByDescending(r => r.Device); break;
                case "Var": sorted = asc ? viewRows.OrderBy(r => r.Var) : viewRows.OrderByDescending(r => r.Var); break;
                case "DurationSeconds": sorted = asc ? viewRows.OrderBy(r => r.DurationSeconds ?? double.MaxValue) : viewRows.OrderByDescending(r => r.DurationSeconds ?? -1); break;
                default: sorted = viewRows; break;
            }
            Bind(sorted.ToList());
            col.HeaderText = ((string)(col.Tag ?? col.HeaderText)) + (asc ? " ▲" : " ▼");
        }

        private void SetBusy(string text, bool busy)
        {
            statusLabel.Text = text;
            statusProgress.Visible = busy;
            statusProgress.Style = busy ? ProgressBarStyle.Marquee : ProgressBarStyle.Blocks;
            btnLoad.Enabled = !busy;
            btnBrowse.Enabled = !busy;
            txtFolder.Enabled = !busy;
            txtPrefix.Enabled = !busy;
            Cursor = busy ? Cursors.AppStarting : Cursors.Default;
            statusStrip.Refresh();
        }

        private void BrowseFolder()
        {
            using (var f = new FolderBrowserDialog())
            {
                if (f.ShowDialog(this) == DialogResult.OK)
                    txtFolder.Text = f.SelectedPath;
            }
        }

        private async Task LoadAllAsync()
        {
            if (string.IsNullOrWhiteSpace(txtFolder.Text) || !Directory.Exists(txtFolder.Text))
            {
                MessageBox.Show("올바른 폴더를 선택하세요.");
                return;
            }

            SetBusy("불러오는 중…", true);
            try
            {
                lock (locker) { rows.Clear(); sessions.Clear(); fileCache.Clear(); }

                var prefix = txtPrefix.Text?.Trim() ?? "";
                var files = Directory.GetFiles(txtFolder.Text, $"{prefix}_*.log")
                    .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                int k = 0;
                foreach (var file in files)
                {
                    k++;
                    statusLabel.Text = $"불러오는 중… ({k}/{files.Count}) {Path.GetFileName(file)}";
                    await ParseFileAsync(file);
                }

                BuildSessionsAcrossAll();

                ApplyFilterAndBind();
                statusLabel.Text = $"불러오기 완료: 파일 {files.Count}개, 라인 {rows.Count}개, 세션 {sessions.Count}개";

                SetupWatcher(prefix);
            }
            catch (Exception ex)
            {
                statusLabel.Text = "오류 발생";
                MessageBox.Show(ex.ToString(), "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetBusy(statusLabel.Text, false);
            }
        }

        private void ApplyFilterAndBind()
        {
            IEnumerable<LogRow> q = rows;

            // BR_ 1줄만 보기 (체크되면: BR_로 시작 + IsOneLiner == true)
            if (chkBROneLiners.Checked)
            {
                q = q.Where(r => (r.Var ?? string.Empty).StartsWith("BR_", StringComparison.OrdinalIgnoreCase) && r.IsOneLiner);
            }

            // 검색어
            var s = (txtSearchVar.Text ?? "").Trim();
            if (!string.IsNullOrEmpty(s))
                q = q.Where(r => (r.Var ?? "").IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0);

            viewRows = q.OrderBy(r => r.Timestamp).ToList();
            Bind(viewRows);
        }

        private void Bind(List<LogRow> data)
        {
            for (int i = 0; i < data.Count; i++)
            {
                if (i < data.Count - 1)
                {
                    var dt = (data[i + 1].Timestamp - data[i].Timestamp).TotalSeconds;
                    data[i].DurationSeconds = Math.Max(0, Math.Round(dt, 3));
                }
                else data[i].DurationSeconds = null;
            }
            bs.DataSource = data;
            grid.DataSource = bs;
            grid.Refresh();
        }

        private void SetupWatcher(string prefix)
        {
            watcher?.Dispose();
            watcher = new FileSystemWatcher(txtFolder.Text, $"{prefix}_*.log")
            {
                IncludeSubdirectories = false,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size
            };
            watcher.Changed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Created += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Renamed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.EnableRaisingEvents = true;
        }

        private async Task ParseFileAsync(string file)
        {
            try
            {
                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, System.Text.Encoding.UTF8, true, 1024 * 16))
                {
                    string line;
                    long idx = 0;
                    var source = Path.GetFileName(file);
                    fileCache[source] = File.ReadAllLines(file, System.Text.Encoding.UTF8); // cache whole file once

                    while ((line = await sr.ReadLineAsync()) != null)
                    {
                        var m = headRx.Match(line);
                        if (!m.Success) { idx++; continue; }
                        if (!DateTime.TryParse(m.Groups["dt"].Value, out var ts)) { idx++; continue; }
                        var level = m.Groups["level"].Value;
                        var rest = m.Groups["rest"].Value;

                        // extract [tokens]
                        var tokens = new List<string>();
                        string tmp = rest;
                        while (true)
                        {
                            var bm = bracketRx.Match(tmp);
                            if (!bm.Success) break;
                            tokens.Add(bm.Groups["tok"].Value);
                            tmp = tmp.Substring(bm.Length);
                        }

                        string device = null, varName = null;
                        if (tokens.Count >= 2) { device = tokens[0]; varName = tokens[1]; }
                        else if (tokens.Count == 1) { varName = tokens[0]; }
                        if (string.IsNullOrEmpty(device))
                        {
                            var n = Path.GetFileNameWithoutExtension(file);
                            var cut = n.LastIndexOf('_');
                            device = cut > 0 ? n.Substring(0, cut) : n;
                        }
                        if (string.IsNullOrEmpty(varName)) varName = device ?? "GLOBAL";

                        bool isOne = IsOneLineStart(tmp);

                        lock (locker)
                        {
                            rows.Add(new LogRow
                            {
                                Timestamp = ts,
                                Level = level,
                                Device = device,
                                Var = varName,
                                SourceFile = source,
                                LineIndex = idx,
                                IsOneLiner = isOne
                            });
                        }
                        idx++;
                    }
                }
            }
            catch (Exception ex) { Console.WriteLine(ex); }
        }

        private bool IsOneLineStart(string remaining)
        {
            if (string.IsNullOrWhiteSpace(remaining)) return false;
            var r = remaining.Trim();
            var low = r.ToLowerInvariant();
            // if contains success or end -> not one-liner-start
            if (low.Contains("success") || low.Contains("succes") || low.Contains(" end") || low.EndsWith("end"))
                return false;
            // cases: "… : START", or ends with " START"
            if (Regex.IsMatch(r, @":\s*START\b", RegexOptions.IgnoreCase)) return true;
            if (Regex.IsMatch(r, @"\bSTART\s*$", RegexOptions.IgnoreCase)) return true;
            return false;
        }

        private async Task OnFileChangedAsync(string file)
        {
            await LoadAllAsync();
        }

        private void BuildSessionsAcrossAll()
        {
            sessions.Clear();
            var ordered = rows.OrderBy(r => r.Timestamp)
                              .ThenBy(r => r.SourceFile, StringComparer.OrdinalIgnoreCase)
                              .ThenBy(r => r.LineIndex)
                              .ToList();

            var open = new Dictionary<string, Session>(StringComparer.OrdinalIgnoreCase);

            Func<string, bool> IsStart = s => s.IndexOf("Start", StringComparison.OrdinalIgnoreCase) >= 0;
            Func<string, bool> IsSuccess = s => { var t = s.ToLowerInvariant(); return t.Contains("success") || t.Contains("succes"); };
            Func<string, bool> IsEnd = s => { var t = s.ToLowerInvariant(); return t.Contains(" end") || t.EndsWith("end") || t.Contains("- end"); };

            foreach (var h in ordered)
            {
                if (!fileCache.TryGetValue(h.SourceFile, out var arr))
                    arr = fileCache[h.SourceFile] = File.ReadAllLines(Path.Combine(txtFolder.Text, h.SourceFile), System.Text.Encoding.UTF8);

                string headerText = (h.LineIndex >= 0 && h.LineIndex < arr.Length) ? arr[h.LineIndex] : string.Empty;

                // skip one-line "…: START" notifications from session logic
                if (h.IsOneLiner) continue;

                if (!open.TryGetValue(h.Var, out var ses))
                {
                    if (IsStart(headerText))
                    {
                        ses = new Session { Var = h.Var, StartFile = h.SourceFile, StartIdx = (int)h.LineIndex, StartTs = h.Timestamp };
                        open[h.Var] = ses;
                    }
                    else if (IsSuccess(headerText))
                    {
                        ses = new Session { Var = h.Var, StartFile = h.SourceFile, StartIdx = (int)h.LineIndex, StartTs = h.Timestamp, SuccessFile = h.SourceFile, SuccessIdx = (int)h.LineIndex, SuccessTs = h.Timestamp };
                        open[h.Var] = ses;
                    }
                    else if (IsEnd(headerText))
                    {
                        ses = new Session { Var = h.Var, StartFile = h.SourceFile, StartIdx = (int)h.LineIndex, StartTs = h.Timestamp, EndFile = h.SourceFile, EndIdx = (int)h.LineIndex, EndTs = h.Timestamp };
                        sessions.Add(ses);
                    }
                }
                else
                {
                    if (IsStart(headerText))
                    {
                        if (ses.EndIdx < 0)
                        {
                            ses.EndFile = h.SourceFile;
                            ses.EndIdx = Math.Max(0, (int)h.LineIndex - 1);
                            ses.EndTs = h.Timestamp;
                            sessions.Add(ses);
                        }
                        open[h.Var] = new Session { Var = h.Var, StartFile = h.SourceFile, StartIdx = (int)h.LineIndex, StartTs = h.Timestamp };
                    }
                    else if (IsSuccess(headerText))
                    {
                        ses.SuccessFile = h.SourceFile;
                        ses.SuccessIdx = (int)h.LineIndex;
                        ses.SuccessTs = h.Timestamp;
                    }
                    else if (IsEnd(headerText))
                    {
                        ses.EndFile = h.SourceFile;
                        ses.EndIdx = (int)h.LineIndex;
                        ses.EndTs = h.Timestamp;
                        sessions.Add(ses);
                        open.Remove(h.Var);
                    }
                }
            }

            // close any open sessions (cross-day) without End
            foreach (var kv in open)
                sessions.Add(kv.Value);
        }

        private void ShowDetailBySession(LogRow anchorRow)
        {
            if (anchorRow.IsOneLiner)
            {
                ShowFallback(anchorRow);
                return;
            }

            var related = sessions.Where(s => string.Equals(s.Var, anchorRow.Var, StringComparison.OrdinalIgnoreCase)).ToList();
            if (related.Count == 0) { ShowFallback(anchorRow); return; }

            Session picked = null;
            foreach (var s in related)
            {
                var start = s.StartTs;
                var end = s.EndIdx >= 0 ? s.EndTs : DateTime.MaxValue;
                if (anchorRow.Timestamp >= start && anchorRow.Timestamp <= end) { picked = s; break; }
            }
            if (picked == null)
            {
                picked = related.OrderBy(s => Math.Abs((anchorRow.Timestamp - s.StartTs).TotalMilliseconds)).First();
            }

            var sb = new StringBuilder();

            Action<string,int,int> appendRange = (file, startIdxParam, endIdxParam) =>
            {
                if (!fileCache.TryGetValue(file, out var linesFile))
                    linesFile = fileCache[file] = File.ReadAllLines(Path.Combine(txtFolder.Text, file), System.Text.Encoding.UTF8);
                int n = linesFile.Length;
                startIdxLocal = Math.Max(0, Math.Min(startIdxLocal, n - 1));
                endIdxLocal = Math.Max(0, Math.Min(endIdxLocal, n - 1));
                if (endIdxLocal < startIdxLocal) return;
                for (int i = startIdxLocal; i <= endIdxLocal; i++)
                    sb.AppendLine(linesFile[i]);
            };

            Func<string,int,int> endOfBlock = (file, idx) =>
            {
                if (!fileCache.TryGetValue(file, out var linesFile))
                    linesFile = fileCache[file] = File.ReadAllLines(Path.Combine(txtFolder.Text, file), System.Text.Encoding.UTF8);
                int j = idx + 1;
                while (j < linesFile.Length && !headRx.IsMatch(linesFile[j])) j++;
                return j - 1;
            };

            string curFile = picked.StartFile;
            int startIdxLocal = picked.StartIdx;
            int endIdxLocal;

            if (picked.EndIdx >= 0)
            {
                if (picked.EndFile == picked.StartFile)
                {
                    endIdxLocal = endOfBlock(picked.EndFile, picked.EndIdx);
                    appendRange(curFile, startIdxLocal, endIdxLocal);
                }
                else
                {
                    appendRange(picked.StartFile, startIdxLocal, (fileCache[picked.StartFile].Length - 1));
                    endIdxLocal = endOfBlock(picked.EndFile, picked.EndIdx);
                    appendRange(picked.EndFile, 0, endIdxLocal);
                }
            }
            else
            {
                int anchor = picked.SuccessIdx >= 0 ? picked.SuccessIdx : picked.StartIdx;
                endIdxLocal = endOfBlock(picked.StartFile, anchor);
                appendRange(curFile, startIdxLocal, endIdxLocal);
            }

            var title = string.Format("{0} 세션 보기  (Start={1}, Success={2}, End={3})",
                picked.Var,
                picked.StartTs.ToString("HH:mm:ss.fff"),
                picked.SuccessIdx >= 0 ? picked.SuccessTs.ToString("HH:mm:ss.fff") : "-",
                picked.EndIdx >= 0 ? picked.EndTs.ToString("HH:mm:ss.fff") : "-");

            ShowText(sb.ToString(), title);
        }

        private void ShowFallback(LogRow anchorRow)
        {
            var fp = Path.Combine(txtFolder.Text, anchorRow.SourceFile);
            string[] arr;
            if (!fileCache.TryGetValue(anchorRow.SourceFile, out arr))
                arr = File.ReadAllLines(fp, System.Text.Encoding.UTF8);
            int start = (int)Math.Max(0, anchorRow.LineIndex - 10);
            int end = Math.Min(arr.Length - 1, (int)anchorRow.LineIndex + 20);
            var txt = string.Join(Environment.NewLine, arr.Skip(start).Take(end - start + 1));
            ShowText(txt, anchorRow.SourceFile + " - 단일/주변 보기");
        }

        private void ShowText(string text, string title)
        {
            var frm = new Form { Text = title, Width = 1100, Height = 760 };
            var tb = new TextBox
            {
                Multiline = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                ReadOnly = true,
                Font = new System.Drawing.Font("Consolas", 10),
                Text = text
            };
            frm.Controls.Add(tb);
            frm.Show();
        }
    }
}
