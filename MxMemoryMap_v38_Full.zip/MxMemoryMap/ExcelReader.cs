using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;

namespace MxMemoryMap
{
    public class SheetInfo { public string Name; public string Target; }

    public static class SimpleXlsx
    {
        public static List<SheetInfo> GetSheetInfos(string path)
        {
            var list = new List<SheetInfo>();
            using (var fs = File.OpenRead(path))
            using (var zip = new ZipArchive(fs, ZipArchiveMode.Read))
            {
                var wbEntry = zip.GetEntry("xl/workbook.xml");
                if (wbEntry == null) return list;
                XDocument wb; using (var s = wbEntry.Open()) wb = XDocument.Load(s);
                XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
                XNamespace relNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
                var relEntry = zip.GetEntry("xl/_rels/workbook.xml.rels");
                if (relEntry == null) return list;
                XDocument rels; using (var s = relEntry.Open()) rels = XDocument.Load(s);
                var sheets = wb.Root.Element(ns + "sheets")?.Elements(ns + "sheet");
                if (sheets == null) return list;
                foreach (var sheet in sheets)
                {
                    var name = (string)sheet.Attribute("name") ?? "Sheet";
                    var rId = (string)sheet.Attribute(relNs + "id");
                    if (string.IsNullOrEmpty(rId)) continue;
                    var rel = rels.Root.Elements().FirstOrDefault(e => (string)e.Attribute("Id") == rId);
                    if (rel == null) continue;
                    var target = (string)rel.Attribute("Target");
                    if (string.IsNullOrEmpty(target)) continue;
                    if (!target.StartsWith("xl/")) target = "xl/" + target;
                    list.Add(new SheetInfo { Name = name, Target = target.Replace("\\\\", "/") });
                }
            }
            return list;
        }

        public static SheetInfo FindSheetByName(string path, string name) =>
            GetSheetInfos(path).FirstOrDefault(s => string.Equals(s.Name, name, StringComparison.OrdinalIgnoreCase));

        public static List<string> ReadColumnStrings(string path, string sheetTargetPath, string columnLetter)
        {
            var result = new List<string>();
            if (string.IsNullOrWhiteSpace(columnLetter)) columnLetter = "H";
            columnLetter = columnLetter.Trim().ToUpperInvariant();
            using (var fs = File.OpenRead(path))
            using (var zip = new ZipArchive(fs, ZipArchiveMode.Read))
            {
                var shared = ReadSharedStrings(zip);
                var entry = zip.GetEntry(sheetTargetPath);
                if (entry == null) return result;
                XDocument wsDoc; using (var s = entry.Open()) wsDoc = XDocument.Load(s);
                XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
                foreach (var c in wsDoc.Descendants(ns + "c"))
                {
                    var r = (string)c.Attribute("r");
                    if (string.IsNullOrEmpty(r)) continue;
                    string letters = new string(r.Where(ch => char.IsLetter(ch)).ToArray()).ToUpperInvariant();
                    if (letters != columnLetter) continue;
                    var t = (string)c.Attribute("t");
                    string text = null;
                    if (t == "s")
                    {
                        var v = (string)c.Element(ns + "v");
                        if (int.TryParse(v, out int idx) && idx >= 0 && idx < shared.Count) text = shared[idx];
                    }
                    else if (t == "inlineStr")
                    {
                        var isElem = c.Element(ns + "is"); var tnode = isElem?.Element(ns + "t"); text = tnode?.Value;
                    }
                    else
                    {
                        text = (string)c.Element(ns + "v");
                    }
                    if (!string.IsNullOrWhiteSpace(text)) result.Add(text.Trim());
                }
            }
            return result;
        }

        private static List<string> ReadSharedStrings(ZipArchive zip)
        {
            var list = new List<string>();
            var entry = zip.GetEntry("xl/sharedStrings.xml");
            if (entry == null) return list;
            XDocument sst; using (var s = entry.Open()) sst = XDocument.Load(s);
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            foreach (var si in sst.Descendants(ns + "si"))
            {
                var texts = si.Descendants(ns + "t").Select(t => t.Value);
                list.Add(string.Concat(texts));
            }
            return list;
        }
    }
}
