
using System;
using System.Globalization;
using System.Windows.Forms;
using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Configuration;

namespace UAClient_RW_Tistory
{
    public partial class MainForm : Form
    {
        private Session _session = null;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // nothing
        }

        private void Log(string msg)
        {
            try
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    while (lvLog.Items.Count > 500) lvLog.Items.RemoveAt(lvLog.Items.Count - 1);
                    var it = lvLog.Items.Insert(0, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    it.SubItems.Add(msg);
                }));
            }
            catch { }
        }

        private void chkAnonymous_CheckedChanged(object sender, EventArgs e)
        {
            bool anon = chkAnonymous.Checked;
            txtUser.Enabled = !anon;
            txtPassword.Enabled = !anon;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                var endpointUrl = txtEndpoint.Text.Trim();
                if (string.IsNullOrEmpty(endpointUrl))
                {
                    MessageBox.Show("Endpoint URL을 입력하세요.");
                    return;
                }

                Log("Connecting: " + endpointUrl);

                var config = new ApplicationConfiguration()
                {
                    ApplicationName = "OPCClientTest",
                    ApplicationUri = Utils.Format(@"urn:{0}:OPCClientTest", System.Net.Dns.GetHostName()),
                    ApplicationType = ApplicationType.Client,
                    SecurityConfiguration = new SecurityConfiguration
                    {
                        ApplicationCertificate = new CertificateIdentifier(),
                        TrustedPeerCertificates = new CertificateTrustList(),
                        RejectedCertificateStore = new CertificateStoreIdentifier(),
                        AutoAcceptUntrustedCertificates = true,
                        RejectSHA1SignedCertificates = false
                    },
                    TransportConfigurations = new TransportConfigurationCollection(),
                    TransportQuotas = new TransportQuotas { OperationTimeout = 15000 },
                    ClientConfiguration = new ClientConfiguration { DefaultSessionTimeout = 60000 },
                    TraceConfiguration = new TraceConfiguration(),
                };

                // Blog pattern: Use CoreClientUtils.SelectEndpoint (useSecurity:false)
                var selectedEndpoint = CoreClientUtils.SelectEndpoint(endpointUrl, false);
                var endpointConfig = EndpointConfiguration.Create(config);
                var configuredEndpoint = new ConfiguredEndpoint(null, selectedEndpoint, endpointConfig);

                IUserIdentity identity;
                if (chkAnonymous.Checked)
                {
                    identity = new UserIdentity(new AnonymousIdentityToken());
                }
                else
                {
                    identity = new UserIdentity(txtUser.Text ?? string.Empty, txtPassword.Text ?? string.Empty);
                }

                // Synchronous overload per the blog pattern
                _session = Session.Create(config, configuredEndpoint, true, "session", 60000, identity, null).GetAwaiter().GetResult();

                _session.KeepAlive += (s, e2) =>
                {
                    if (ServiceResult.IsBad(e2.Status))
                    {
                        Log("KeepAlive: " + e2.Status);
                    }
                };

                Log("Connected.");
            }
            catch (Exception ex)
            {
                Log("Connect failed: " + ex.Message);
                MessageBox.Show("Connect failed: " + ex.Message);
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (_session != null && _session.Connected)
                {
                    _session.Close();
                    _session.Dispose();
                }
            }
            catch { }
            finally
            {
                _session = null;
                Log("Disconnected.");
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (_session == null || !_session.Connected)
            {
                MessageBox.Show("Not connected."); return;
            }
            var idText = txtNodeId.Text.Trim();
            if (string.IsNullOrEmpty(idText))
            {
                MessageBox.Show("NodeId를 입력하세요."); return;
            }
            try
            {
                var nodeId = NodeId.Parse(idText);
                var dv = _session.ReadValue(nodeId);
                lblRead.Text = string.Format("Value={0}, Status={1}, SourceTimestamp={2}", dv.Value, dv.StatusCode, dv.SourceTimestamp);
                Log("Read: " + idText + " -> " + dv.Value + " (" + dv.StatusCode + ")");
            }
            catch (Exception ex)
            {
                Log("Read failed: " + ex.Message);
                MessageBox.Show("Read failed: " + ex.Message);
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            if (_session == null || !_session.Connected)
            {
                MessageBox.Show("Not connected."); return;
            }
            var idText = txtNodeId.Text.Trim();
            if (string.IsNullOrEmpty(idText))
            {
                MessageBox.Show("NodeId를 입력하세요."); return;
            }
            var valText = txtWrite.Text.Trim();
            if (string.IsNullOrEmpty(valText))
            {
                MessageBox.Show("Write 값 입력."); return;
            }
            try
            {
                var nodeId = NodeId.Parse(idText);

                // Try to infer type (bool -> long -> double -> datetime -> string)
                object value = InferValue(valText);

                var writeValue = new WriteValue
                {
                    NodeId = nodeId,
                    AttributeId = Attributes.Value,
                    Value = new DataValue(new Variant(value))
                };

                var col = new WriteValueCollection { writeValue };
                _session.Write(null, col, out StatusCodeCollection results, out DiagnosticInfoCollection diags);
                var sc = (results != null && results.Count > 0) ? results[0] : StatusCodes.Bad;
                Log("Write: " + idText + " = " + value + " -> " + sc);
                if (StatusCode.IsBad(sc)) MessageBox.Show("Write failed: " + sc.ToString());
            }
            catch (Exception ex)
            {
                Log("Write failed: " + ex.Message);
                MessageBox.Show("Write failed: " + ex.Message);
            }
        }

        private object InferValue(string text)
        {
            bool b; long l; double d; DateTime dt;
            if (bool.TryParse(text, out b)) return b;
            if (long.TryParse(text, out l)) return l;
            if (double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out d)) return d;
            if (DateTime.TryParse(text, out dt)) return dt;
            return text;
        }
    }
}
