
# UAClient_RW_Tistory  (.NET Framework 4.7.2, WinForms, C# 7.3)

블로그 예제(CoreClientUtils + Session.Create 동기 오버로드)를 따르면서 **Read/Write** UI를 추가했습니다.

## NuGet (고정)
- OPCFoundation.NetStandard.Opc.Ua 1.5.376.244
- OPCFoundation.NetStandard.Opc.Ua.Client 1.5.376.244

## 실행
1) VS 2019/2022로 솔루션 열기 → NuGet 복원
2) Endpoint에 Kepware UA Server 주소 (예: opc.tcp://<IP>:49320)
3) Connect → NodeId 입력 → Read / Write
