
using System.Windows.Forms;

namespace UAClient_RW_Tistory
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtEndpoint;
        private Button btnConnect;
        private Button btnDisconnect;
        private TextBox txtNodeId;
        private Button btnRead;
        private TextBox txtWrite;
        private Button btnWrite;
        private Label lblRead;
        private ListView lvLog;
        private ColumnHeader colTime;
        private ColumnHeader colMessage;
        private CheckBox chkAnonymous;
        private TextBox txtUser;
        private TextBox txtPassword;
        private Label lblNodeId;
        private Label lblWrite;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtEndpoint = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.txtNodeId = new System.Windows.Forms.TextBox();
            this.btnRead = new System.Windows.Forms.Button();
            this.txtWrite = new System.Windows.Forms.TextBox();
            this.btnWrite = new System.Windows.Forms.Button();
            this.lblRead = new System.Windows.Forms.Label();
            this.lvLog = new System.Windows.Forms.ListView();
            this.colTime = new System.Windows.Forms.ColumnHeader();
            this.colMessage = new System.Windows.Forms.ColumnHeader();
            this.chkAnonymous = new System.Windows.Forms.CheckBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblNodeId = new System.Windows.Forms.Label();
            this.lblWrite = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtEndpoint
            // 
            this.txtEndpoint.Location = new System.Drawing.Point(12, 12);
            this.txtEndpoint.Name = "txtEndpoint";
            this.txtEndpoint.Size = new System.Drawing.Size(400, 23);
            this.txtEndpoint.TabIndex = 0;
            this.txtEndpoint.Text = "opc.tcp://localhost:49320";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(418, 11);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(80, 25);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Location = new System.Drawing.Point(504, 11);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(90, 25);
            this.btnDisconnect.TabIndex = 2;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // chkAnonymous
            // 
            this.chkAnonymous.AutoSize = true;
            this.chkAnonymous.Checked = true;
            this.chkAnonymous.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAnonymous.Location = new System.Drawing.Point(600, 14);
            this.chkAnonymous.Name = "chkAnonymous";
            this.chkAnonymous.Size = new System.Drawing.Size(92, 19);
            this.chkAnonymous.TabIndex = 3;
            this.chkAnonymous.Text = "Anonymous";
            this.chkAnonymous.UseVisualStyleBackColor = true;
            this.chkAnonymous.CheckedChanged += new System.EventHandler(this.chkAnonymous_CheckedChanged);
            // 
            // txtUser
            // 
            this.txtUser.Enabled = false;
            this.txtUser.Location = new System.Drawing.Point(698, 12);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(100, 23);
            this.txtUser.TabIndex = 4;
            // 
            // txtPassword
            // 
            this.txtPassword.Enabled = false;
            this.txtPassword.Location = new System.Drawing.Point(804, 12);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(100, 23);
            this.txtPassword.TabIndex = 5;
            // 
            // lblNodeId
            // 
            this.lblNodeId.AutoSize = true;
            this.lblNodeId.Location = new System.Drawing.Point(12, 49);
            this.lblNodeId.Name = "lblNodeId";
            this.lblNodeId.Size = new System.Drawing.Size(49, 15);
            this.lblNodeId.TabIndex = 6;
            this.lblNodeId.Text = "NodeId";
            // 
            // txtNodeId
            // 
            this.txtNodeId.Location = new System.Drawing.Point(67, 45);
            this.txtNodeId.Name = "txtNodeId";
            this.txtNodeId.Size = new System.Drawing.Size(430, 23);
            this.txtNodeId.TabIndex = 7;
            this.txtNodeId.Text = "ns=2;s=Channel1.Device1.Tag1";
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(503, 45);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(80, 23);
            this.btnRead.TabIndex = 8;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // lblWrite
            // 
            this.lblWrite.AutoSize = true;
            this.lblWrite.Location = new System.Drawing.Point(12, 80);
            this.lblWrite.Name = "lblWrite";
            this.lblWrite.Size = new System.Drawing.Size(36, 15);
            this.lblWrite.TabIndex = 9;
            this.lblWrite.Text = "Write";
            // 
            // txtWrite
            // 
            this.txtWrite.Location = new System.Drawing.Point(67, 76);
            this.txtWrite.Name = "txtWrite";
            this.txtWrite.Size = new System.Drawing.Size(430, 23);
            this.txtWrite.TabIndex = 10;
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(503, 76);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(80, 23);
            this.btnWrite.TabIndex = 11;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // lblRead
            // 
            this.lblRead.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRead.Location = new System.Drawing.Point(12, 111);
            this.lblRead.Name = "lblRead";
            this.lblRead.Size = new System.Drawing.Size(892, 23);
            this.lblRead.TabIndex = 12;
            this.lblRead.Text = "Read value will appear here";
            this.lblRead.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lvLog
            // 
            this.lvLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colTime, this.colMessage });
            this.lvLog.FullRowSelect = true;
            this.lvLog.GridLines = true;
            this.lvLog.HideSelection = false;
            this.lvLog.Location = new System.Drawing.Point(12, 140);
            this.lvLog.Name = "lvLog";
            this.lvLog.Size = new System.Drawing.Size(892, 360);
            this.lvLog.TabIndex = 13;
            this.lvLog.View = System.Windows.Forms.View.Details;
            // 
            // colTime
            // 
            this.colTime.Text = "LogTime";
            this.colTime.Width = 180;
            // 
            // colMessage
            // 
            this.colMessage.Text = "Message";
            this.colMessage.Width = 700;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 512);
            this.Controls.Add(this.lvLog);
            this.Controls.Add(this.lblRead);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.txtWrite);
            this.Controls.Add(this.lblWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.txtNodeId);
            this.Controls.Add(this.lblNodeId);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.chkAnonymous);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtEndpoint);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OPC UA Client (Read/Write) - Tistory Pattern";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
