using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogViewer48
{
    public enum ActionKind { Other, Start, Success, Fail, End }

    public class LogRow
    {
        public DateTime Timestamp { get; set; }
        public string Var { get; set; }
        public string SourceFile { get; set; }
        public long LineIndex { get; set; }
        public ActionKind Kind { get; set; }
    }

    public class CombinedRow
    {
        public string Var { get; set; }
        public DateTime StartTs { get; set; }
        public DateTime? SuccessTs { get; set; }
        public DateTime? EndTs { get; set; }
        public string Status { get; set; }
        public double? DurationSeconds { get; set; }
    }

    public class MainForm : Form
    {
        TextBox txtFolder = new TextBox();
        Button btnBrowse = new Button();
        Button btnLoad = new Button();
        ListBox lstFiles = new ListBox();
        DataGridView grid = new DataGridView();
        CheckBox chkCombine = new CheckBox();

        List<LogRow> rows = new List<LogRow>();
        List<CombinedRow> merged = new List<CombinedRow>();

        Regex headRx = new Regex(@"^(?<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+\[(?<level>[^\]]+)\]\s+(?<rest>.*)$", RegexOptions.Compiled);

        public MainForm()
        {
            Text = "EIF Log Viewer v26 (Full)";
            Width = 1200; Height = 800;
            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
            btnBrowse.Text = "경로"; btnLoad.Text = "불러오기"; chkCombine.Text = "BR 결합 보기"; chkCombine.Checked = true;
            top.Controls.AddRange(new Control[]{ new Label{Text="폴더"}, txtFolder, btnBrowse, btnLoad, chkCombine });
            Controls.Add(top);
            lstFiles.Dock = DockStyle.Left; lstFiles.Width = 200; Controls.Add(lstFiles);
            grid.Dock = DockStyle.Fill; grid.AutoGenerateColumns = true; Controls.Add(grid);
            btnBrowse.Click += (s,e)=>{ using(var f=new FolderBrowserDialog()){ if(f.ShowDialog()==DialogResult.OK) txtFolder.Text=f.SelectedPath;}};
            btnLoad.Click += async (s,e)=> await LoadFiles();
            lstFiles.DoubleClick += async (s,e)=>{ if(lstFiles.SelectedItem!=null) await LoadOneFile(Path.Combine(txtFolder.Text,lstFiles.SelectedItem.ToString()));};
        }

        async Task LoadFiles()
        {
            lstFiles.Items.Clear();
            if(!Directory.Exists(txtFolder.Text)) return;
            foreach(var f in Directory.GetFiles(txtFolder.Text,"*.log")) lstFiles.Items.Add(Path.GetFileName(f));
        }

        async Task LoadOneFile(string file)
        {
            rows.Clear();
            using(var sr=new StreamReader(file))
            {
                string line; long idx=0;
                while((line=await sr.ReadLineAsync())!=null)
                {
                    var m=headRx.Match(line); if(!m.Success){idx++; continue;}
                    if(!DateTime.TryParse(m.Groups["dt"].Value,out var ts)){idx++; continue;}
                    string rest=m.Groups["rest"].Value;
                    ActionKind kind=DetectKind(rest);
                    string varName=ExtractVar(rest);
                    rows.Add(new LogRow{Timestamp=ts,Var=varName,Kind=kind,SourceFile=Path.GetFileName(file),LineIndex=idx});
                    idx++;
                }
            }
            if(chkCombine.Checked)
            {
                merged=BuildMerged(rows.OrderBy(r=>r.Timestamp));
                grid.DataSource=merged;
            } else grid.DataSource=rows;
        }

        ActionKind DetectKind(string t)
        {
            t=t.ToLower();
            if(t.Contains("start")) return ActionKind.Start;
            if(t.Contains("success")) return ActionKind.Success;
            if(t.Contains("ng")||t.Contains("fail")||t.Contains("error")) return ActionKind.Fail;
            if(t.Contains("end")) return ActionKind.End;
            return ActionKind.Other;
        }

        string ExtractVar(string t)
        {
            var m=Regex.Match(t,@".*\[(?<var>BR_[^\]]+)\]"); if(m.Success) return m.Groups["var"].Value;
            return "GLOBAL";
        }

        List<CombinedRow> BuildMerged(IEnumerable<LogRow> ordered)
        {
            var result=new List<CombinedRow>();
            var stacks=new Dictionary<string,Stack<CombinedRow>>();
            foreach(var r in ordered)
            {
                if(!r.Var.StartsWith("BR_")) continue;
                if(!stacks.TryGetValue(r.Var,out var st)){st=new Stack<CombinedRow>();stacks[r.Var]=st;}
                switch(r.Kind)
                {
                    case ActionKind.Start:
                        st.Push(new CombinedRow{Var=r.Var,StartTs=r.Timestamp,Status="Unknown"});
                        break;
                    case ActionKind.Success:
                    case ActionKind.Fail:
                        if(st.Count==0) st.Push(new CombinedRow{Var=r.Var,StartTs=r.Timestamp});
                        var arr=st.ToArray();
                        for(int i=0;i<arr.Length;i++){ if(!arr[i].SuccessTs.HasValue){arr[i].SuccessTs=r.Timestamp; arr[i].Status=(r.Kind==ActionKind.Success?"Success":"NG"); break;} }
                        st=new Stack<CombinedRow>(arr.Reverse()); stacks[r.Var]=st;
                        break;
                    case ActionKind.End:
                        if(st.Count>0){ var top=st.Pop(); top.EndTs=r.Timestamp; if(top.Status=="Unknown"&&top.SuccessTs.HasValue) top.Status="Success"; top.DurationSeconds=(top.EndTs-top.StartTs).Value.TotalSeconds; result.Add(top);} else result.Add(new CombinedRow{Var=r.Var,StartTs=r.Timestamp,EndTs=r.Timestamp,Status="Unknown",DurationSeconds=0});
                        break;
                }
            }
            foreach(var kv in stacks)
                foreach(var it in kv.Value){ it.EndTs=it.SuccessTs??it.StartTs; it.DurationSeconds=(it.EndTs-it.StartTs).Value.TotalSeconds; result.Add(it); }
            return result.OrderBy(x=>x.StartTs).ToList();
        }
    }
}
