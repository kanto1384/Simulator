using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LogViewer48")]
[assembly: AssemblyDescription("Simple log viewer for day-rotated files")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("LogViewer48")] 
[assembly: AssemblyCopyright("Copyright © 2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("602FF705-B61C-413E-8DA8-FEE9393E61F7")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
