
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogViewer48
{
    public class LogEntry
    {
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Var { get; set; }
        public string Message { get; set; }
        public string SourceFile { get; set; }
        public long LineNo { get; set; }
        public string Device { get; set; }
    }

    public class LogGroup
    {
        public string Var { get; set; }
        public string Device { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string Status { get; set; }
        public string Level { get; set; }
        public string SourceFile { get; set; }
        public List<LogEntry> Lines { get; } = new List<LogEntry>();
        public TimeSpan? Duration => EndTime.HasValue ? EndTime.Value - StartTime : (TimeSpan?)null;
    }

    public class MainForm : Form
    {
        TextBox txtFolder;
        Button btnBrowse;
        TextBox txtPrefix;
        Button btnLoad;
        DataGridView grid;
        TextBox txtDetails;
        SplitContainer split;
        Label lblCount;
        StatusStrip statusStrip;
        ToolStripStatusLabel statusLabel;
        ToolStripProgressBar statusProgress;

        FileSystemWatcher watcher;
        readonly Dictionary<string, long> fileReadOffsets = new Dictionary<string, long>();
        readonly Dictionary<string, LogGroup> openGroupsByVar = new Dictionary<string, LogGroup>();
        readonly List<LogGroup> closedGroups = new List<LogGroup>();
        readonly object locker = new object();

        // 단순화된 정규식: 날짜/시간 + 레벨만 정확히, 나머지는 유연 처리
        readonly Regex headRx = new Regex(
            @"^(?<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+\[(?<level>[^\]]+)\]\s+(?<rest>.*)$",
            RegexOptions.Compiled);

        readonly Regex bracketRx = new Regex(@"^\[(?<tok>[^\]]+)\]\s*", RegexOptions.Compiled);

        public MainForm()
        {
            Text = "Log Viewer (.NET Framework 4.8)";
            Width = 1200;
            Height = 800;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(6), AutoSize = false };
            txtFolder = new TextBox { Width = 500 };
            btnBrowse = new Button { Text = "경로...", Width = 70 };
            txtPrefix = new TextBox { Width = 160, Text = "RollMapElm" };
            btnLoad = new Button { Text = "불러오기", Width = 100 };
            lblCount = new Label { AutoSize = true, Text = "0개 그룹", Margin = new Padding(10, 8, 0, 0) };

            top.Controls.Add(new Label { Text = "폴더:", AutoSize = true, Margin = new Padding(0, 8, 4, 0) });
            top.Controls.Add(txtFolder);
            top.Controls.Add(btnBrowse);
            top.Controls.Add(new Label { Text = "파일 Prefix:", AutoSize = true, Margin = new Padding(12, 8, 4, 0) });
            top.Controls.Add(txtPrefix);
            top.Controls.Add(btnLoad);
            top.Controls.Add(new Label { Text = "   ", AutoSize = true });
            top.Controls.Add(lblCount);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 460 };
            // 상/하 간격 10px
            split.Panel1.Padding = new Padding(0, 0, 0, 10);

            grid = new DataGridView { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, AutoGenerateColumns = false };
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "변수", DataPropertyName = "Var", Width = 100 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "장비", DataPropertyName = "Device", Width = 160 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "파일", DataPropertyName = "SourceFile", Width = 260 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "시작", DataPropertyName = "StartTime", Width = 160 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "종료", DataPropertyName = "EndTime", Width = 160 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "소요", DataPropertyName = "Duration", Width = 120 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "레벨", DataPropertyName = "Level", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "상태", DataPropertyName = "Status", Width = 120 });

            txtDetails = new TextBox { Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both, ReadOnly = true, WordWrap = false };

            split.Panel1.Controls.Add(grid);
            split.Panel2.Controls.Add(txtDetails);

            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel("대기 중");
            statusProgress = new ToolStripProgressBar() { Style = ProgressBarStyle.Blocks, Visible = false };
            statusStrip.Items.Add(statusLabel);
            statusStrip.Items.Add(new ToolStripStatusLabel() { Spring = true });
            statusStrip.Items.Add(statusProgress);

            Controls.Add(split);
            Controls.Add(top);
            Controls.Add(statusStrip);

            btnBrowse.Click += (s, e) => BrowseFolder();
            btnLoad.Click += async (s, e) => await LoadAllAsync();
            grid.SelectionChanged += (s, e) => ShowDetailsOfSelected();

            FormClosing += (s, e) => watcher?.Dispose();
        }

        private void SetBusy(string text, bool busy)
        {
            statusLabel.Text = text;
            statusProgress.Visible = busy;
            statusProgress.Style = busy ? ProgressBarStyle.Marquee : ProgressBarStyle.Blocks;
            btnLoad.Enabled = !busy;
            btnBrowse.Enabled = !busy;
            txtFolder.Enabled = !busy;
            txtPrefix.Enabled = !busy;
            Cursor = busy ? Cursors.AppStarting : Cursors.Default;
            statusStrip.Refresh();
        }

        private void BrowseFolder()
        {
            using (var f = new FolderBrowserDialog())
            {
                if (f.ShowDialog(this) == DialogResult.OK)
                    txtFolder.Text = f.SelectedPath;
            }
        }

        private async Task LoadAllAsync()
        {
            if (string.IsNullOrWhiteSpace(txtFolder.Text) || !Directory.Exists(txtFolder.Text))
            {
                MessageBox.Show("올바른 폴더를 선택하세요.");
                return;
            }

            SetBusy("불러오는 중…", true);
            try
            {
                lock (locker)
                {
                    fileReadOffsets.Clear();
                    openGroupsByVar.Clear();
                    closedGroups.Clear();
                }
                txtDetails.Clear();
                grid.DataSource = null;
                lblCount.Text = "0개 그룹";

                var prefix = txtPrefix.Text?.Trim() ?? "";
                var files = Directory.GetFiles(txtFolder.Text, $"{prefix}_*.txt")
                    .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                int idx = 0;
                foreach (var file in files)
                {
                    idx++;
                    statusLabel.Text = $"불러오는 중… ({idx}/{files.Count}) {Path.GetFileName(file)}";
                    await ParseFileFromStartAsync(file);
                }

                SetupWatcher(prefix);
                RefreshGrid();
                statusLabel.Text = $"불러오기 완료: 파일 {files.Count}개, 그룹 {closedGroups.Count}개";
            }
            catch (Exception ex)
            {
                statusLabel.Text = "오류 발생";
                MessageBox.Show(ex.ToString(), "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetBusy(statusLabel.Text, false);
            }
        }

        private void SetupWatcher(string prefix)
        {
            watcher?.Dispose();
            watcher = new FileSystemWatcher(txtFolder.Text, $"{prefix}_*.txt")
            {
                IncludeSubdirectories = false,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size
            };
            watcher.Changed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Created += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Renamed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.EnableRaisingEvents = true;
        }

        private async Task ParseFileFromStartAsync(string file)
        {
            try
            {
                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, Encoding.UTF8, true, 1024 * 16))
                {
                    string line;
                    long lineNo = 0;
                    while ((line = await sr.ReadLineAsync()) != null)
                    {
                        lineNo++;
                        ProcessLine(file, line, lineNo);
                    }
                    lock (locker) { fileReadOffsets[file] = fs.Position; }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private async Task OnFileChangedAsync(string file)
        {
            await Task.Delay(100);
            try
            {
                long offset;
                lock (locker)
                {
                    if (!fileReadOffsets.TryGetValue(file, out offset))
                        offset = 0;
                }

                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    if (offset > fs.Length) offset = 0;
                    fs.Position = offset;
                    using (var sr = new StreamReader(fs, Encoding.UTF8, true, 1024 * 16))
                    {
                        string line;
                        long appendedLines = 0;
                        while ((line = await sr.ReadLineAsync()) != null)
                        {
                            appendedLines++;
                            ProcessLine(file, line, 0);
                        }
                        lock (locker) { fileReadOffsets[file] = fs.Position; }
                        if (appendedLines > 0)
                            BeginInvoke(new Action(RefreshGrid));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void ProcessLine(string file, string line, long lineNo)
        {
            var m = headRx.Match(line);
            if (!m.Success) return;

            DateTime ts;
            if (!DateTime.TryParse(m.Groups["dt"].Value, out ts)) return;

            var level = m.Groups["level"].Value;
            var rest = m.Groups["rest"].Value;

            // [token] [token] ... 추출
            var tokens = new List<string>();
            while (true)
            {
                var bm = bracketRx.Match(rest);
                if (!bm.Success) break;
                tokens.Add(bm.Groups["tok"].Value);
                rest = rest.Substring(bm.Length);
            }

            string device = null;
            string varName = null;

            if (tokens.Count >= 2)
            {
                device = tokens[0];
                varName = tokens[1];
            }
            else if (tokens.Count == 1)
            {
                // 단일 토큰일 때: Var로 간주 (기존 포맷 호환)
                varName = tokens[0];
            }

            // 파일명에서 장치 prefix 보조 추출
            if (string.IsNullOrEmpty(device))
            {
                var n = Path.GetFileNameWithoutExtension(file);
                var idx = n.LastIndexOf('_');
                device = idx > 0 ? n.Substring(0, idx) : n;
            }

            if (string.IsNullOrEmpty(varName))
            {
                // Var가 전혀 없으면 장치명 기반으로 그룹 (최후 fallback)
                varName = device ?? "GLOBAL";
            }

            var msg = rest?.Trim() ?? string.Empty;

            var entry = new LogEntry
            {
                Timestamp = ts,
                Level = level,
                Var = varName,
                Message = msg,
                SourceFile = Path.GetFileName(file),
                LineNo = lineNo,
                Device = device
            };

            lock (locker)
            {
                bool isStart = ContainsToken(msg, "Start");
                bool isEnd = ContainsToken(msg, "End");
                bool isSuccess = ContainsToken(msg, "Success") || ContainsToken(msg, "Succes"); // 오타 케어

                if (isStart)
                {
                    if (openGroupsByVar.TryGetValue(varName, out var existing))
                    {
                        existing.EndTime = entry.Timestamp;
                        existing.Status = existing.Status ?? "Closed(by new Start)";
                        closedGroups.Add(existing);
                        openGroupsByVar.Remove(varName);
                    }

                    var g = new LogGroup
                    {
                        Var = varName,
                        Device = device,
                        StartTime = entry.Timestamp,
                        EndTime = null,
                        Status = "Running",
                        Level = level,
                        SourceFile = entry.SourceFile
                    };
                    g.Lines.Add(entry);
                    openGroupsByVar[varName] = g;
                }
                else if (isEnd)
                {
                    if (!openGroupsByVar.TryGetValue(varName, out var g))
                    {
                        g = new LogGroup
                        {
                            Var = varName,
                            Device = device,
                            StartTime = entry.Timestamp,
                            SourceFile = entry.SourceFile,
                            Level = level,
                            Status = "Completed"
                        };
                    }
                    g.Lines.Add(entry);
                    g.EndTime = entry.Timestamp;
                    if (string.IsNullOrEmpty(g.Status) || g.Status == "Running") g.Status = "Completed";
                    g.Level = PickSeverity(g.Level, level);
                    closedGroups.Add(g);
                    openGroupsByVar.Remove(varName);
                }
                else
                {
                    if (!openGroupsByVar.TryGetValue(varName, out var g))
                    {
                        g = new LogGroup
                        {
                            Var = varName,
                            Device = device,
                            StartTime = entry.Timestamp,
                            SourceFile = entry.SourceFile,
                            Level = level,
                            Status = "Running"
                        };
                        openGroupsByVar[varName] = g;
                    }
                    g.Lines.Add(entry);
                    if (isSuccess) g.Status = "Success";
                    g.Level = PickSeverity(g.Level, level);

                    // 메시지 내 "Assess- End" 같은 변형 케이스: End가 뒤에 있으면 종료로 간주
                    if (!isEnd && msg.IndexOf(" End", StringComparison.OrdinalIgnoreCase) >= 0 &&
                        msg.IndexOf("Start", StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        g.EndTime = entry.Timestamp;
                        if (string.IsNullOrEmpty(g.Status) || g.Status == "Running") g.Status = "Completed";
                        closedGroups.Add(g);
                        openGroupsByVar.Remove(varName);
                    }
                }
            }
        }

        private bool ContainsToken(string msg, string token)
        {
            return msg?.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private string PickSeverity(string a, string b)
        {
            int Rank(string s)
            {
                var t = (s ?? "").ToLowerInvariant();
                if (t == "error" || t == "fatal") return 3;
                if (t == "warn" || t == "warning") return 2;
                if (t == "info") return 1;
                return 0;
            }
            return Rank(a) >= Rank(b) ? a : b;
        }

        private void RefreshGrid()
        {
            List<LogGroup> view;
            lock (locker)
            {
                view = closedGroups
                    .OrderByDescending(g => g.StartTime)
                    .ToList();
            }
            grid.DataSource = view;
            lblCount.Text = $"{view.Count}개 그룹";
        }

        private void ShowDetailsOfSelected()
        {
            if (grid.CurrentRow?.DataBoundItem is LogGroup g)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"[변수] {g.Var}");
                sb.AppendLine($"[장비] {g.Device}");
                sb.AppendLine($"[파일] {g.SourceFile}");
                sb.AppendLine($"[시작] {g.StartTime:yyyy-MM-dd HH:mm:ss.fff}");
                sb.AppendLine($"[종료] {(g.EndTime.HasValue ? g.EndTime.Value.ToString("yyyy-MM-dd HH:mm:ss.fff") : "-")}");
                sb.AppendLine($"[상태] {g.Status}  [레벨] {g.Level}");
                sb.AppendLine(new string('-', 80));
                foreach (var ln in g.Lines)
                {
                    sb.AppendLine($"{ln.Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{ln.Level}] [{ln.Device}] [{ln.Var}] {ln.Message}");
                }
                txtDetails.Text = sb.ToString();
            }
            else
            {
                txtDetails.Clear();
            }
        }
    }
}
