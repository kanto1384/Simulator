using System;
using System.Globalization;

namespace RollMapFake
{
    public static class FakeValueApplier
    {
        public static void ApplyValue(CStructureVariable response, string fieldName, string dataType, string rawValue)
        {
            var variable = response[fieldName];

            if (variable == null)
                throw new Exception("[FAKE] response field not found: " + fieldName);

            switch ((dataType ?? "").Trim().ToLowerInvariant())
            {
                case "string":
                    variable.AsString = rawValue;
                    break;

                case "int":
                case "int32":
                    variable.AsInt = int.Parse(rawValue, CultureInfo.InvariantCulture);
                    break;

                case "short":
                case "int16":
                    variable.AsShort = short.Parse(rawValue, CultureInfo.InvariantCulture);
                    break;

                case "decimal":
                    variable.AsDecimal = decimal.Parse(rawValue, CultureInfo.InvariantCulture);
                    break;

                case "datetime":
                    variable.AsDateTime = DateTime.Parse(rawValue, CultureInfo.InvariantCulture);
                    break;

                default:
                    throw new NotSupportedException("[FAKE] Unsupported DataType: " + dataType);
            }
        }
    }
}
