namespace RollMapFake
{
    public class FakeFieldValue
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public string RawValue { get; set; }
    }
}
