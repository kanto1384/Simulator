using System;

namespace LGChem.GMES.SolaceEIF.Simulator
{
    public partial class CSimulator : CControlServer
    {
        protected override void OnInitializeCompleted()
        {
            base.OnInitializeCompleted();

            RollMapFake.FakeScenarioSetup.RegisterDefaults();
            RollMapFake.FakeHarmonyBootstrap.Initialize();

            Console.WriteLine("[FAKE] bootstrap initialized");
        }
    }
}
