using System;
using System.Collections.Generic;

namespace RollMapFake
{
    public static class FakeScenarioRepository
    {
        private static readonly Dictionary<string, FakeRequestScenario> _map
            = new Dictionary<string, FakeRequestScenario>(StringComparer.OrdinalIgnoreCase);

        public static void RegisterOrReplace(string bizName, FakeRequestScenario scenario)
        {
            _map[bizName] = scenario;
        }

        public static FakeRequestScenario Get(string bizName)
        {
            if (!_map.TryGetValue(bizName, out var scenario))
                throw new Exception("[FAKE] Scenario not found: " + bizName);

            return scenario;
        }
    }
}
