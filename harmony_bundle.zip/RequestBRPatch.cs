using System;
using System.Reflection;
using HarmonyLib;

namespace RollMapFake
{
    [HarmonyPatch]
    public static class RequestBRPatch
    {
        static MethodBase TargetMethod()
        {
            return AccessTools.Method(
                typeof(CRollMap2_0),
                "RequestBR",
                new Type[]
                {
                    typeof(string),
                    typeof(CStructureVariable),
                    typeof(CStructureVariable),
                    typeof(Exception).MakeByRefType()
                });
        }

        public static bool Prefix(
            CRollMap2_0 __instance,
            string serviceName,
            CStructureVariable request,
            CStructureVariable response,
            ref Exception exception,
            ref int __result)
        {
            Console.WriteLine("[FAKE] RequestBR intercepted: " + serviceName);

            var scenario = FakeScenarioRepository.Get(serviceName);

            exception = scenario.Exception;

            if (scenario.Fields != null)
            {
                foreach (var field in scenario.Fields)
                {
                    FakeValueApplier.ApplyValue(response, field.Name, field.DataType, field.RawValue);
                    Console.WriteLine("[FAKE] set " + field.Name + " = " + field.RawValue);
                }
            }

            __result = scenario.ReturnCode;

            Console.WriteLine("[FAKE] RequestBR return: " + __result);

            return false;
        }
    }
}
