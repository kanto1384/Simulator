using System.Collections.Generic;

namespace RollMapFake
{
    public static class FakeScenarioSetup
    {
        public static void RegisterDefaults()
        {
            FakeScenarioRepository.RegisterOrReplace(
                "BR_PRD_GET_RM_EIF_INPUT_LOT_SET",
                new FakeRequestScenario
                {
                    ReturnCode = 1,
                    Exception = null,
                    Fields = new List<FakeFieldValue>
                    {
                        new FakeFieldValue { Name = "RESULT_CD",   DataType = "string", RawValue = "OK" },
                        new FakeFieldValue { Name = "RESULT_MSG",  DataType = "string", RawValue = "SUCCESS" },
                        new FakeFieldValue { Name = "EQPTID",      DataType = "string", RawValue = "RM_EQ_001" },
                        new FakeFieldValue { Name = "INPUT_LOTID", DataType = "string", RawValue = "LOT_TEST_0001" },
                        new FakeFieldValue { Name = "INPUT_CSTID", DataType = "string", RawValue = "CST_TEST_0001" }
                    }
                });
        }
    }
}
