RollMap Harmony Patch Bundle

1) Add 0Harmony.dll reference to your .NET Framework class library project.
2) Also copy 0Harmony.dll to the runtime folder next to ControlServer.exe.
3) Add these .cs files to the same registered DLL project that is loaded by ControlServer.
4) In your CControlServer-derived class, call:
   RollMapFake.FakeScenarioSetup.RegisterDefaults();
   RollMapFake.FakeHarmonyBootstrap.Initialize();
   inside OnInitializeCompleted().
5) Build your DLL and register/deploy it in the same way you normally register your simulator/control DLL.
6) Put breakpoints here:
   - CSimulator.OnInitializeCompleted()
   - FakeHarmonyBootstrap.Initialize()
   - RequestBRPatch.Prefix()

Expected logs:
[FAKE] Harmony patch installed
[FAKE] bootstrap initialized
[FAKE] RequestBR intercepted: BR_PRD_GET_RM_EIF_INPUT_LOT_SET

Notes:
- If Prefix does not hit, the actual RequestBR signature/class may differ.
- If a response field is missing, adjust FakeScenarioSetup field names to your actual OutData keys.
- If RequestBR has multiple overloads, keep the TargetMethod() version as provided.
