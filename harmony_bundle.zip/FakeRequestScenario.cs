using System;
using System.Collections.Generic;

namespace RollMapFake
{
    public class FakeRequestScenario
    {
        public int ReturnCode { get; set; }
        public Exception Exception { get; set; }
        public List<FakeFieldValue> Fields { get; set; } = new List<FakeFieldValue>();
    }
}
