using System;
using System.Reflection;
using HarmonyLib;

namespace RollMapFake
{
    public static class FakeHarmonyBootstrap
    {
        private static bool _installed;
        private static Harmony _harmony;

        public static void Initialize()
        {
            if (_installed)
                return;

            _installed = true;

            _harmony = new Harmony("rollmap.fake.requestbr");
            _harmony.PatchAll(Assembly.GetExecutingAssembly());

            Console.WriteLine("[FAKE] Harmony patch installed");
        }
    }
}
