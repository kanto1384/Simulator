using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Configuration;

namespace WinFormsOpcUaClient
{
    public class MainForm : Form
    {
        private TextBox txtEndpoint;
        private CheckBox chkAnonymous;
        private TextBox txtUser;
        private TextBox txtPassword;
        private Button btnConnect;
        private Button btnDisconnect;
        private TreeView tvBrowse;
        private TextBox txtNodeId;
        private Button btnRead;
        private Label lblReadValue;
        private TextBox txtWriteValue;
        private Button btnWrite;
        private TextBox txtLog;

        private ApplicationConfiguration _config;
        private Session _session;

        public MainForm()
        {
            Text = "WinForms OPC UA Client (.NET Framework)";
            Width = 1100;
            Height = 720;
            StartPosition = FormStartPosition.CenterScreen;

            BuildUi();
        }

        private void BuildUi()
        {
            var topPanel = new Panel { Dock = DockStyle.Top, Height = 100 };
            Controls.Add(topPanel);

            var lblUrl = new Label { Text = "Endpoint URL", Left = 10, Top = 12, Width = 90 };
            txtEndpoint = new TextBox { Left = 100, Top = 10, Width = 520, Text = "opc.tcp://localhost:4840" };

            chkAnonymous = new CheckBox { Left = 640, Top = 12, Width = 140, Text = "Anonymous", Checked = true };
            var lblUser = new Label { Text = "User", Left = 780, Top = 12, Width = 40 };
            txtUser = new TextBox { Left = 820, Top = 10, Width = 110, Enabled = false };

            var lblPwd = new Label { Text = "Password", Left = 940, Top = 12, Width = 70 };
            txtPassword = new TextBox { Left = 1010, Top = 10, Width = 70, UseSystemPasswordChar = true, Enabled = false };

            chkAnonymous.CheckedChanged += (s, e) =>
            {
                bool anon = chkAnonymous.Checked;
                txtUser.Enabled = !anon;
                txtPassword.Enabled = !anon;
            };

            btnConnect = new Button { Left = 100, Top = 40, Width = 120, Text = "Connect" };
            btnDisconnect = new Button { Left = 230, Top = 40, Width = 120, Text = "Disconnect", Enabled = false };

            btnConnect.Click += async (s, e) => await ConnectAsync();
            btnDisconnect.Click += (s, e) => Disconnect();

            topPanel.Controls.AddRange(new Control[] {
                lblUrl, txtEndpoint, chkAnonymous, lblUser, txtUser, lblPwd, txtPassword, btnConnect, btnDisconnect
            });

            var mainSplit = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 400 };
            Controls.Add(mainSplit);

            // Left: browse tree
            tvBrowse = new TreeView { Dock = DockStyle.Fill };
            tvBrowse.BeforeExpand += TvBrowse_BeforeExpand;
            tvBrowse.AfterSelect += (s, e) => txtNodeId.Text = e.Node.Tag as string ?? "";
            mainSplit.Panel1.Controls.Add(tvBrowse);

            // Right: read/write + log
            var rightPanel = new Panel { Dock = DockStyle.Fill };
            mainSplit.Panel2.Controls.Add(rightPanel);

            var lblNodeId = new Label { Text = "NodeId", Left = 10, Top = 10, Width = 60 };
            txtNodeId = new TextBox { Left = 70, Top = 8, Width = 420 };

            btnRead = new Button { Left = 500, Top = 8, Width = 80, Text = "Read", Enabled = false };
            btnRead.Click += async (s, e) => await ReadAsync();

            var lblWrite = new Label { Text = "Write Value", Left = 10, Top = 40, Width = 80 };
            txtWriteValue = new TextBox { Left = 100, Top = 38, Width = 390 };
            btnWrite = new Button { Left = 500, Top = 38, Width = 80, Text = "Write", Enabled = false };
            btnWrite.Click += async (s, e) => await WriteAsync();

            var lblRead = new Label { Text = "Read:", Left = 10, Top = 72, Width = 60 };
            lblReadValue = new Label { Left = 70, Top = 72, Width = 510, AutoSize = false };
            lblReadValue.BorderStyle = BorderStyle.FixedSingle;
            lblReadValue.Height = 24;

            var grpLog = new GroupBox { Text = "Log", Left = 10, Top = 110, Width = 570, Height = 480, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right };
            txtLog = new TextBox { Multiline = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill };
            grpLog.Controls.Add(txtLog);

            rightPanel.Controls.AddRange(new Control[] {
                lblNodeId, txtNodeId, btnRead, lblWrite, txtWriteValue, btnWrite, lblRead, lblReadValue, grpLog
            });
        }

        private void Log(string text)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action<string>(Log), text);
                return;
            }
            txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}{Environment.NewLine}");
        }

        private async Task ConnectAsync()
        {
            try
            {
                btnConnect.Enabled = false;
                string url = txtEndpoint.Text.Trim();
                if (string.IsNullOrWhiteSpace(url))
                {
                    MessageBox.Show("Endpoint URL을 입력하세요.");
                    btnConnect.Enabled = true;
                    return;
                }

                Log($"Connecting to {url} ...");

                _config = new ApplicationConfiguration()
                {
                    ApplicationName = "WinFormsOpcUaClient",
                    ApplicationType = ApplicationType.Client,
                    ApplicationUri = $"urn:{System.Net.Dns.GetHostName()}:WinFormsOpcUaClient",
                    SecurityConfiguration = new SecurityConfiguration
                    {
                        ApplicationCertificate = new CertificateIdentifier
                        {
                            StoreType = "Directory",
                            StorePath = "Certs/Own",
                            SubjectName = "CN=WinFormsOpcUaClient"
                        },
                        AutoAcceptUntrustedCertificates = true,
                        AddAppCertToTrustedStore = true
                    },
                    TransportQuotas = new TransportQuotas
                    {
                        OperationTimeout = 15000,
                        MaxStringLength = 1_048_576,
                        MaxByteStringLength = 1_048_576,
                        MaxArrayLength = 65_535,
                        MaxBufferSize = 65_535,
                        ChannelLifetime = 300_000,
                        SecurityTokenLifetime = 3_600_000
                    },
                    ClientConfiguration = new ClientConfiguration
                    {
                        DefaultSessionTimeout = 60_000
                    }
                };

                _config.Validate(ApplicationType.Client).GetAwaiter().GetResult();

                var app = new ApplicationInstance
                {
                    ApplicationName = "WinFormsOpcUaClient",
                    ApplicationType = ApplicationType.Client,
                    ApplicationConfiguration = _config
                };

                // Ensure there's an app certificate (auto-accepted for simplicity)
                bool haveCert = await app.CheckApplicationInstanceCertificate(false, 2048);
                if (!haveCert)
                {
                    Log("Warning: No application certificate created. Some secure endpoints may reject the client.");
                }
                _config.CertificateValidator.CertificateValidation += (s, e) =>
                {
                    e.Accept = true;
                    Log($"CertificateValidation: Auto-accept {e.Error?.StatusCode} for {e.Certificate?.Subject}");
                };

                // Select endpoint using CoreClientUtils (compatible with older stack versions)
                var selected = CoreClientUtils.SelectEndpoint(url, false, 15000);if (selected == null)
                {
                    throw new Exception("No usable endpoints found for the server.");
                }

                Log($"Selected endpoint: {selected.EndpointUrl} | SecurityMode={selected.SecurityMode} | SecurityPolicy={selected.SecurityPolicyUri}");

                var endpointConfiguration = EndpointConfiguration.Create(_config);
                var configuredEndpoint = new ConfiguredEndpoint(null, selected, endpointConfiguration);

                IUserIdentity identity;
                if (chkAnonymous.Checked)
                {
                    identity = new UserIdentity(new AnonymousIdentityToken());
                }
                else
                {
                    identity = new UserIdentity(txtUser.Text ?? string.Empty, txtPassword.Text ?? string.Empty);
                }

                _session = await Session.Create(
                    _config,
                    configuredEndpoint,
                    updateBeforeConnect: false,
                    sessionName: "WinFormsOpcUaClient",
                    sessionTimeout: 60_000,
                    identity: identity,
                    preferredLocales: null);

                _session.KeepAlive += (s, e) =>
                {
                    if (ServiceResult.IsBad(e.Status))
                    {
                        Log($"KeepAlive status: {e.Status}");
                    }
                };

                btnDisconnect.Enabled = true;
                btnRead.Enabled = true;
                btnWrite.Enabled = true;

                Log("Connected.");

                // Seed browse tree with ObjectsFolder
                tvBrowse.Nodes.Clear();
                var root = new TreeNode("Objects") { Tag = ObjectIds.ObjectsFolder.ToString() };
                root.Nodes.Add(new TreeNode("loading...")); // lazy load
                tvBrowse.Nodes.Add(root);
                root.Expand();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connect failed: " + ex.Message);
                Log("Connect failed: " + ex);
            }
            finally
            {
                btnConnect.Enabled = true;
            }
        }

        private void Disconnect()
        {
            try
            {
                if (_session != null && _session.Connected)
                {
                    _session.Close();
                    _session.Dispose();
                }
            }
            catch { }
            finally
            {
                _session = null;
                btnDisconnect.Enabled = false;
                btnRead.Enabled = false;
                btnWrite.Enabled = false;
                tvBrowse.Nodes.Clear();
                Log("Disconnected.");
            }
        }

        private async void TvBrowse_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (_session == null || !_session.Connected) return;
            var node = e.Node;
            if (node == null) return;

            // If already loaded, do nothing
            if (node.Nodes.Count == 1 && node.Nodes[0].Text == "loading...")
            {
                node.Nodes.Clear();
                try
                {
                    var nodeIdStr = node.Tag as string ?? ObjectIds.ObjectsFolder.ToString();
                    var nodeId = ExpandedNodeId.ToNodeId(ExpandedNodeId.Parse(nodeIdStr), _session.NamespaceUris);

                    ReferenceDescriptionCollection references;
                    byte[] cp;
                    _session.Browse(
                        null,
                        null,
                        nodeId,
                        0u,
                        BrowseDirection.Forward,
                        ReferenceTypeIds.HierarchicalReferences,
                        includeSubtypes: true,
                        (uint)(NodeClass.Object | NodeClass.Variable | NodeClass.Method),
                        out cp,
                        out references);

                    foreach (var rd in references)
                    {
                        string display = $"{rd.DisplayName.Text} ({rd.NodeClass})";
                        var child = new TreeNode(display);
                        child.Tag = rd.NodeId.ToString();
                        // Add placeholder for lazy loading if it might have children
                        if (rd.NodeClass == NodeClass.Object || rd.NodeClass == NodeClass.Variable)
                        {
                            child.Nodes.Add(new TreeNode("loading..."));
                        }
                        node.Nodes.Add(child);
                    }
                }
                catch (Exception ex)
                {
                    Log("Browse error: " + ex.Message);
                }
            }
        }

        private NodeId GetTargetNodeId()
        {
            string raw = txtNodeId.Text?.Trim();
            if (!string.IsNullOrWhiteSpace(raw))
            {
                try { return NodeId.Parse(raw); }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid NodeId format. Example: ns=2;s=Demo.Static.Scalar.Int32\n" + ex.Message);
                    return null;
                }
            }

            // fallback: selected tree node tag
            if (tvBrowse.SelectedNode != null && tvBrowse.SelectedNode.Tag is string tag && !string.IsNullOrWhiteSpace(tag))
            {
                try { return ExpandedNodeId.ToNodeId(ExpandedNodeId.Parse(tag), _session.NamespaceUris); }
                catch { }
            }
            return null;
        }

        private async Task ReadAsync()
        {
            if (_session == null || !_session.Connected) { MessageBox.Show("Not connected."); return; }

            var nodeId = GetTargetNodeId();
            if (nodeId == null)
            {
                MessageBox.Show("NodeId를 선택하거나 입력하세요.");
                return;
            }

            try
            {
                var dv = _session.ReadValue(nodeId);
                string typeInfo = dv?.WrappedValue.TypeInfo?.ToString() ?? "unknown";
                lblReadValue.Text = $"{dv?.Value}  (Type={typeInfo}, Status={dv.StatusCode})";
                Log($"Read {nodeId}: {dv?.Value} (status {dv.StatusCode})");
            }
            catch (Exception ex)
            {
                Log("Read failed: " + ex.Message);
                MessageBox.Show("Read failed: " + ex.Message);
            }
        }

        private async Task WriteAsync()
        {
            if (_session == null || !_session.Connected) { MessageBox.Show("Not connected."); return; }

            var nodeId = GetTargetNodeId();
            if (nodeId == null)
            {
                MessageBox.Show("NodeId를 선택하거나 입력하세요.");
                return;
            }

            string text = txtWriteValue.Text?.Trim() ?? "";
            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Write Value를 입력하세요.");
                return;
            }

            try
            {
                // Best-effort type inference (bool, int, double, datetime, otherwise string)
                object value = InferValue(text, await GuessDataTypeAsync(nodeId));

                var wv = new WriteValue
                {
                    NodeId = nodeId,
                    AttributeId = Attributes.Value,
                    Value = new DataValue(new Variant(value))
                };

                var col = new WriteValueCollection { wv };
                _session.Write(null, col, out StatusCodeCollection results, out DiagnosticInfoCollection diags);

                var sc = (results != null && results.Count > 0) ? results[0] : StatusCodes.Bad;
                Log($"Write {nodeId}: {value} -> {sc}");
                if (StatusCode.IsGood(sc))
                {
                    MessageBox.Show("Write 성공");
                }
                else
                {
                    MessageBox.Show($"Write 실패: {sc}");
                }
            }
            catch (Exception ex)
            {
                Log("Write failed: " + ex.Message);
                MessageBox.Show("Write failed: " + ex.Message);
            }
        }

        private async Task<NodeId> GuessDataTypeAsync(NodeId nodeId)
        {
            try
            {
                // Read the DataType attribute to infer target type
                ReadValueId rvid = new ReadValueId { NodeId = nodeId, AttributeId = Attributes.DataType };
                _session.Read(null, 0, TimestampsToReturn.Neither, new ReadValueIdCollection { rvid }, out DataValueCollection values, out DiagnosticInfoCollection _);
                if (values != null && values.Count > 0 && values[0].Value is NodeId dt)
                {
                    return dt;
                }
            }
            catch { }
            return null;
        }

        private object InferValue(string text, NodeId targetDataTypeId)
        {
            // If server says it's a Boolean / Int32 / Double / DateTime, try to parse accordingly.
            try
            {
                if (targetDataTypeId == DataTypeIds.Boolean || text.Equals("true", StringComparison.OrdinalIgnoreCase) || text.Equals("false", StringComparison.OrdinalIgnoreCase))
                {
                    if (bool.TryParse(text, out var b)) return b;
                }
                if (targetDataTypeId == DataTypeIds.Int16 || targetDataTypeId == DataTypeIds.Int32 || targetDataTypeId == DataTypeIds.Int64 ||
                    targetDataTypeId == DataTypeIds.UInt16 || targetDataTypeId == DataTypeIds.UInt32 || targetDataTypeId == DataTypeIds.UInt64)
                {
                    if (long.TryParse(text, out var l)) return l;
                }
                if (targetDataTypeId == DataTypeIds.Float || targetDataTypeId == DataTypeIds.Double || targetDataTypeId == DataTypeIds.Decimal)
                {
                    if (double.TryParse(text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var d)) return d;
                }
                if (targetDataTypeId == DataTypeIds.DateTime)
                {
                    if (DateTime.TryParse(text, out var dt)) return dt;
                }
            }
            catch { }

            // Generic fallbacks
            if (bool.TryParse(text, out var b2)) return b2;
            if (long.TryParse(text, out var l2)) return l2;
            if (double.TryParse(text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var d2)) return d2;
            if (DateTime.TryParse(text, out var dt2)) return dt2;
            return text; // default to string
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try
            {
                if (_session != null && _session.Connected)
                {
                    _session.Close();
                    _session.Dispose();
                }
            }
            catch { }
            base.OnFormClosing(e);
        }
    }
}