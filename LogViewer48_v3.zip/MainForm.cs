
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace LogViewer48
{
    public partial class MainForm : Form
    {
        private DataGridView grid;
        private TextBox txtFolder;
        private TextBox txtPrefix;
        private Button btnLoad;
        private StatusStrip status;
        private ToolStripStatusLabel lblStatus;

        public MainForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Log Viewer";
            this.Width = 1000;
            this.Height = 700;

            Label lbl1 = new Label() { Left = 10, Top = 15, Text = "경로:" };
            txtFolder = new TextBox() { Left = 50, Top = 10, Width = 700 };
            Button btnBrowse = new Button() { Left = 760, Top = 8, Text = "...", Width = 30 };
            btnBrowse.Click += (s, e) =>
            {
                using (var fbd = new FolderBrowserDialog())
                {
                    if (fbd.ShowDialog() == DialogResult.OK)
                        txtFolder.Text = fbd.SelectedPath;
                }
            };
            Label lbl2 = new Label() { Left = 800, Top = 15, Text = "Prefix:" };
            txtPrefix = new TextBox() { Left = 850, Top = 10, Width = 100, Text = "RollMapElm" };

            btnLoad = new Button() { Left = 10, Top = 40, Text = "불러오기", Width = 100 };
            btnLoad.Click += BtnLoad_Click;

            grid = new DataGridView()
            {
                Left = 10,
                Top = 80,
                Width = 960,
                Height = 550,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToOrderColumns = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            grid.DoubleClick += Grid_DoubleClick;

            grid.Columns.Add("Date", "날짜");
            grid.Columns.Add("Time", "시간");
            grid.Columns.Add("Level", "레벨");
            grid.Columns.Add("Device", "장비");
            grid.Columns.Add("Var", "변수");
            grid.Columns.Add("Elapsed", "소요(ms)");

            status = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("준비됨");
            status.Items.Add(lblStatus);

            this.Controls.Add(lbl1);
            this.Controls.Add(txtFolder);
            this.Controls.Add(btnBrowse);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtPrefix);
            this.Controls.Add(btnLoad);
            this.Controls.Add(grid);
            this.Controls.Add(status);
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            string folder = txtFolder.Text.Trim();
            string prefix = txtPrefix.Text.Trim();
            if (!Directory.Exists(folder))
            {
                MessageBox.Show("경로가 존재하지 않습니다.");
                return;
            }
            lblStatus.Text = "불러오는 중...";

            grid.Rows.Clear();
            var files = Directory.GetFiles(folder, prefix + "_*.log");

            List<LogGroup> groups = new List<LogGroup>();
            Regex lineRx = new Regex(@"^(?<dt>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \[(?<level>[^\]]+)\](?<rest>.*)$");

            foreach (var file in files)
            {
                foreach (var line in File.ReadLines(file))
                {
                    var m = lineRx.Match(line);
                    if (!m.Success) continue;

                    DateTime dt;
                    if (!DateTime.TryParse(m.Groups["dt"].Value, out dt)) continue;
                    string level = m.Groups["level"].Value;
                    string rest = m.Groups["rest"].Value.Trim();

                    // 토큰 추출
                    var tokenMatches = Regex.Matches(rest, @"\[[^\]]+\]");
                    string device = "", variable = "";
                    int consumed = 0;
                    if (tokenMatches.Count > 0)
                    {
                        device = tokenMatches[0].Value.Trim('[', ']');
                        consumed = tokenMatches[0].Index + tokenMatches[0].Length;
                    }
                    if (tokenMatches.Count > 1)
                    {
                        variable = tokenMatches[1].Value.Trim('[', ']');
                        consumed = tokenMatches[1].Index + tokenMatches[1].Length;
                    }
                    if (variable == "" && device != "")
                        variable = device;

                    string msg = rest.Substring(consumed).Trim();

                    // Start/End 그룹핑
                    if (msg.Contains("Start"))
                    {
                        groups.Add(new LogGroup()
                        {
                            Device = device,
                            Variable = variable,
                            Level = level,
                            StartTime = dt,
                            Lines = new List<string>() { line }
                        });
                    }
                    else if (msg.Contains("End") && groups.Count > 0)
                    {
                        var g = groups.LastOrDefault(x => x.EndTime == DateTime.MinValue && x.Variable == variable);
                        if (g != null)
                        {
                            g.EndTime = dt;
                            g.Lines.Add(line);
                        }
                    }
                    else
                    {
                        var g = groups.LastOrDefault(x => x.EndTime == DateTime.MinValue && x.Variable == variable);
                        if (g != null)
                        {
                            g.Lines.Add(line);
                        }
                    }
                }
            }

            foreach (var g in groups)
            {
                double elapsed = g.EndTime > g.StartTime ? (g.EndTime - g.StartTime).TotalMilliseconds : 0;
                grid.Rows.Add(g.StartTime.ToString("yyyy-MM-dd"), g.StartTime.ToString("HH:mm:ss.fff"),
                    g.Level, g.Device, g.Variable, elapsed.ToString("F3"));
                grid.Rows[grid.Rows.Count - 1].Tag = g;
            }

            lblStatus.Text = $"불러오기 완료: 그룹 {groups.Count}개";
        }

        private void Grid_DoubleClick(object sender, EventArgs e)
        {
            if (grid.SelectedRows.Count == 0) return;
            var g = grid.SelectedRows[0].Tag as LogGroup;
            if (g == null) return;
            string text = string.Join(Environment.NewLine, g.Lines);
            Form f = new Form();
            f.Text = $"{g.Variable} 상세로그";
            f.Width = 800;
            f.Height = 600;
            TextBox tb = new TextBox()
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Both,
                Text = text
            };
            f.Controls.Add(tb);
            f.ShowDialog();
        }
    }

    public class LogGroup
    {
        public string Device;
        public string Variable;
        public string Level;
        public DateTime StartTime;
        public DateTime EndTime;
        public List<string> Lines = new List<string>();
    }
}
