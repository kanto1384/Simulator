GATEONE Auto ID/PW Fill (Main + Popup)

- 기반: 이전에 정상 컴파일되던 코드 구조 유지
- 추가된 것:
  1) "안전하지 않음" 화면: proceed 우선 + details 토글 반복 방지
  2) 로그인 폼이 iframe 안에 있어도 자동 입력: FrameCreated + frame.ExecuteScriptAsync

device_map.json (최상위) 예시:
{
  "version": 1,
  "updatedAt": "2026-02-12",
  "credentials": { "id": "YOUR_ID", "pw": "YOUR_PASSWORD" },
  "devices": []
}

로그인 input selector:
- input#USERID.input_txt
- input#PASSWD.input_txt

로그인 버튼 자동 클릭은 하지 않고 값만 채웁니다.
