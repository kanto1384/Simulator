using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using System.Globalization;

namespace GATEONE;

public sealed class MainForm : Form
{
    private readonly string userDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AppData");
    private readonly SplitContainer _split = new();
    // Global top bar (outside of the SplitContainer) so the splitter never draws over it.
    private readonly Panel _topBar = new();
    private readonly TextBox _txtUrl = new();
    private readonly Button _btnGo = new();
    private readonly Button _btnExtract = new();
    private readonly Button _btnReloadMap = new();
    private readonly WebView2 _web = new();

    private readonly Panel _rightTop = new();
    private readonly TextBox _txtSearch = new();
    private readonly Button _btnClearSearch = new();
    private readonly DataGridView _grid = new();

    private DeviceIndex _index = new();
    private List<ViewRow> _currentRows = new();

    private System.Windows.Forms.Timer? _autoExtractTimer;
    private bool _autoExtractBusy;

    // 마지막 테이블 상태(변화 감지용)
    private int _lastRowCount = -1;
    private string _lastFirstKey = "";

    // ✅ Auto-login credentials from device_map.json (top-level: "credentials": {"id":"..","pw":".."})
    private string? _loginIdFromJson;
    private string? _loginPwFromJson;

    // ✅ Prevent repeated "안전하지 않음" clicks per navigation
    private bool _certHandledThisNav;

    private string MapPath => Path.Combine(AppContext.BaseDirectory, "data", "device_map.json");

    public MainForm()
    {
        Text = "GATEONE";
        Width = 1700;
        Height = 900;
        StartPosition = FormStartPosition.CenterScreen;

        BuildLayout();
        Load += async (_, _) =>
        {
            try
            {
                await EnsureWebViewAsync();
                ReloadMap();
                _txtUrl.Text = "https://10.94.25.177/main.html";
                _web.CoreWebView2.Settings.AreBrowserAcceleratorKeysEnabled = false;
                Navigate();

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        };
    }

    private void BuildLayout()
    {
        // Root layout: a global top bar + the split area.
        // This prevents the SplitContainer splitter "drag ghost" from drawing over the top bar.
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f)); //상단바 아래 크기
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

        Controls.Clear();
        Controls.Add(root);

        // Global Top Bar
        _topBar.Dock = DockStyle.Fill;
        _topBar.Padding = new Padding(8, 8, 8, 8);
        _topBar.Controls.Clear();
        root.Controls.Add(_topBar, 0, 0);

        var leftButtons = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        _topBar.Controls.Add(leftButtons);

        // Add the fill control AFTER the right-docked buttons panel to avoid docking overlap.
        _txtUrl.Dock = DockStyle.Fill;

        _btnGo.Text = "이동";
        _btnGo.Width = 70;
        _btnGo.Click += (_, _) => Navigate();

        _btnExtract.Text = "추출";
        _btnExtract.Width = 90;
        _btnExtract.Click += async (_, _) => await ExtractAndShowAsync();

        _btnReloadMap.Text = "불러오기";
        _btnReloadMap.Width = 110;
        _btnReloadMap.Click += (_, _) => { ReloadMap(); ApplySearchFilter(); };

        leftButtons.Controls.Add(_btnExtract);
        leftButtons.Controls.Add(_btnReloadMap);

        // Split (below the global top bar)
        _split.Dock = DockStyle.Fill;
        _split.Orientation = Orientation.Vertical;
        root.Controls.Add(_split, 0, 1);

        // LEFT: WebView2 (only content; top bar is global)
        _split.Panel1.Controls.Clear();
        _web.Dock = DockStyle.Fill;
        _split.Panel1.Controls.Add(_web);

        // RIGHT: build panel order explicitly to avoid any dock overlap.
        _split.Panel2.Controls.Clear();

        // Rebuild the right-top bar content (avoid duplicates if layout is rebuilt).
        _rightTop.Controls.Clear();

        _btnClearSearch.Text = "초기화";
        _btnClearSearch.Dock = DockStyle.Right;
        _btnClearSearch.Width = 60;
        _btnClearSearch.Click += (_, _) => _txtSearch.Text = "";
        _rightTop.Controls.Add(_btnClearSearch);

        // Add the fill control AFTER the right-docked clear button to avoid docking overlap.
        _txtSearch.Dock = DockStyle.Fill;
        _txtSearch.PlaceholderText = "검색";
        _txtSearch.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                ApplySearchFilter();
            }
        };

        _rightTop.Controls.Add(_txtSearch);

        // RIGHT: grid
        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = false;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AllowUserToResizeRows = false;
        _grid.MultiSelect = false;
        _grid.SelectionMode = DataGridViewSelectionMode.CellSelect;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        _grid.RowHeadersVisible = false;
        _grid.DataSource = new List<ViewRow>();

        _grid.DataBindingComplete -= Grid_DataBindingComplete;
        _grid.DataBindingComplete += Grid_DataBindingComplete;
        _grid.ScrollBars = ScrollBars.Both;

        // RIGHT: top bar
        _rightTop.Dock = DockStyle.Top;
        _rightTop.Height = 44;
        _rightTop.Padding = new Padding(8, 8, 8, 8);

        _split.Panel2.Controls.Add(_grid);
        _split.Panel2.Controls.Add(_rightTop);

        KeyPreview = true;
        _split.SplitterDistance = (int)(Width * 0.57);
    }

    private void Grid_DataBindingComplete(object? sender, DataGridViewBindingCompleteEventArgs e)
    {
        BeginInvoke(new Action(() => { FitGridColumnsLikeExcel(_grid); ApplyKoreanHeadersSimple(_grid); }));
    }

    private void ApplyKoreanHeadersSimple(DataGridView grid)
    {
        foreach (DataGridViewColumn col in grid.Columns)
        {
            switch (col.HeaderText)
            {
                case "Ip": col.HeaderText = "IP"; break;
                case "Host": col.HeaderText = "호스트"; break;
                case "EndAt": col.HeaderText = "만료일자"; break;
                case "DDay": col.HeaderText = "만료까지"; break;
                case "plc": col.HeaderText = "PLC"; break;
                case "factova": col.HeaderText = "모델러"; break;
                case "Location": col.HeaderText = "위치"; break;
            }
        }
    }

    private async Task EnsureWebViewAsync()
    {
        await _web.EnsureCoreWebView2Async();

        _web.CoreWebView2.NavigationStarting += (_, __) => _certHandledThisNav = false;

        _web.CoreWebView2.DOMContentLoaded += async (_, __) =>
        {
            try
            {
                if (_certHandledThisNav) return;
                _certHandledThisNav = true;
                await TryClickProceedUnsafeAsync(_web);
            }
            catch { }
        };

        _web.CoreWebView2.FrameCreated += CoreWebView2_FrameCreated;

        StartAutoExtractWatcher();
        _web.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
    }

    private void CoreWebView2_FrameCreated(object? sender, CoreWebView2FrameCreatedEventArgs e)
    {
        e.Frame.DOMContentLoaded += async (_, __) =>
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_loginIdFromJson) || string.IsNullOrWhiteSpace(_loginPwFromJson))
                    return;

                await TryFillLoginOnceInFrameAsync(e.Frame, _loginIdFromJson!, _loginPwFromJson!);
            }
            catch { }
        };
    }

    private static async Task<bool> TryFillLoginOnceInFrameAsync(CoreWebView2Frame frame, string id, string pw)
    {
        var idJson = JsonSerializer.Serialize(id);
        var pwJson = JsonSerializer.Serialize(pw);

        var js = $@"
(() => {{
  const idEl = document.querySelector('input#USERID.input_txt, input#USERID');
  const pwEl = document.querySelector('input#PASSWD.input_txt, input#PASSWD');
  if (!idEl || !pwEl) return false;

  const setVal = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  function apply(el, v) {{
    if (setVal) setVal.call(el, v);
    else el.value = v;

    el.dispatchEvent(new Event('input',  {{ bubbles:true }}));
    el.dispatchEvent(new Event('change', {{ bubbles:true }}));
  }}

  apply(idEl, {idJson});
  apply(pwEl, {pwJson});
  return true;
}})();";

        var raw = await frame.ExecuteScriptAsync(js);
        return raw.Contains("true", StringComparison.OrdinalIgnoreCase);
    }

    private static async Task<bool> TryClickProceedUnsafeAsync(WebView2 web)
    {
        const string js = @"
(() => {
  const proceed = document.querySelector('#proceed-link');
  if (proceed) { proceed.click(); return 'proceeded'; }

  if (!window.__gateone_details_clicked) {
    const details = document.querySelector('#details-button');
    if (details) {
      window.__gateone_details_clicked = true;
      details.click();
      return 'details_clicked_once';
    }
  }

  return 'no_action';
})();";

        var raw = await web.CoreWebView2.ExecuteScriptAsync(js);
        return raw.Contains("proceeded", StringComparison.OrdinalIgnoreCase)
            || raw.Contains("details_clicked_once", StringComparison.OrdinalIgnoreCase);
    }

    private void FitGridColumnsLikeExcel(DataGridView grid)
    {
        if (grid.Columns.Count == 0) return;

        grid.SuspendLayout();
        try
        {
            foreach (DataGridViewColumn c in grid.Columns)
            {
                int preferred = c.GetPreferredWidth(DataGridViewAutoSizeColumnMode.AllCells, true);
                c.Width = preferred + 8;
            }
        }
        finally
        {
            grid.ResumeLayout();
        }
    }

    private async void CoreWebView2_NewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
    {
        var deferral = e.GetDeferral();
        try
        {
            e.Handled = true;

            var popup = new PopupBrowserForm();
            await popup.EnsureInitializedAsync(_web.CoreWebView2.Environment);

            popup.WebView.CoreWebView2.FrameCreated += (s2, fe) =>
            {
                fe.Frame.DOMContentLoaded += async (_, __) =>
                {
                    try
                    {
                        if (string.IsNullOrWhiteSpace(_loginIdFromJson) || string.IsNullOrWhiteSpace(_loginPwFromJson))
                            return;

                        await TryFillLoginOnceInFrameAsync(fe.Frame, _loginIdFromJson!, _loginPwFromJson!);
                    }
                    catch { }
                };
            };

            bool popupCertHandledThisNav = false;
            popup.WebView.CoreWebView2.NavigationStarting += (_, __) => popupCertHandledThisNav = false;
            popup.WebView.CoreWebView2.DOMContentLoaded += async (_, __) =>
            {
                try
                {
                    if (popupCertHandledThisNav) return;
                    popupCertHandledThisNav = true;
                    await TryClickProceedUnsafeAsync(popup.WebView);
                }
                catch { }
            };

            e.NewWindow = popup.WebView.CoreWebView2;
            popup.Show(this);
        }
        finally
        {
            deferral.Complete();
        }
    }

    private void Navigate()
    {
        if (_web.CoreWebView2 is null)
        {
            MessageBox.Show(this, "WebView2 is not initialized yet.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var url = _txtUrl.Text.Trim();
        if (string.IsNullOrWhiteSpace(url)) return;

        if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
            !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            url = "https://" + url;
        }

        _web.CoreWebView2.Navigate(url);
    }

    private void ReloadMap()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(MapPath)!);
            if (!File.Exists(MapPath))
            {
                File.WriteAllText(MapPath,
                    "{
  "version": 1,
  "updatedAt": "" + DateTime.Now.ToString("yyyy-MM-dd") + "",
  "credentials": { "id": "", "pw": "" },
  "devices": []
}
");
            }

            _index = DeviceIndex.Load(MapPath);

            var (id, pw) = LoadCredentialsFromMap(MapPath);
            _loginIdFromJson = id;
            _loginPwFromJson = pw;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.ToString(), "Map load failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private (string? id, string? pw) LoadCredentialsFromMap(string mapPath)
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(mapPath));
            if (!doc.RootElement.TryGetProperty("credentials", out var cred)) return (null, null);

            string? id = cred.TryGetProperty("id", out var pid) ? pid.GetString() : null;
            string? pw = cred.TryGetProperty("pw", out var ppw) ? ppw.GetString() : null;
            return (id, pw);
        }
        catch
        {
            return (null, null);
        }
    }

    // --- existing extract/search logic (unchanged) ---

    private async Task ExtractAndShowAsync()
    {
        if (_web.CoreWebView2 is null)
        {
            MessageBox.Show(this, "WebView2 is not initialized yet.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        try
        {
            await WaitForTableAsync(timeoutMs: 8000);

            var extracted = await ExtractIpHostAsync();
            _currentRows = BuildRows(extracted, _index);
            ApplySearchFilter();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.ToString(), "Extract failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ApplySearchFilter()
    {
        var q = _txtSearch.Text.Trim();
        if (string.IsNullOrWhiteSpace(q))
        {
            _grid.DataSource = _currentRows;
            return;
        }

        var filtered = _currentRows
            .Where(r =>
                ContainsIgnoreCase(r.Host, q) ||
                ContainsIgnoreCase(r.Ip, q) ||
                ContainsIgnoreCase(r.plc, q) ||
                ContainsIgnoreCase(r.factova, q) ||
                ContainsIgnoreCase(r.Location, q))
            .ToList();

        _grid.DataSource = filtered;
    }

    private static bool ContainsIgnoreCase(string? s, string q)
        => (s ?? "").IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0;

    private async Task WaitForTableAsync(int timeoutMs)
    {
        var sw = Stopwatch.StartNew();
        while (sw.ElapsedMilliseconds < timeoutMs)
        {
            const string js = """
            (() => {
              const t = document.querySelector('#seltable');
              const rows = document.querySelectorAll('#seltable tbody tr');
              return !!t && !!rows && rows.length > 0;
            })();
            """;

            var okJson = await _web.CoreWebView2.ExecuteScriptAsync(js);
            if (okJson == "true") return;
            await Task.Delay(200);
        }
    }

    private async Task<List<(string Ip, string Host, string EndAtText, bool IsExpired)>> ExtractIpHostAsync()
    {
        const string js = """
    (() => {
      const rows = Array.from(document.querySelectorAll('#seltable tbody tr'));
      const out = [];
      for (const tr of rows) {
        const tds = tr.querySelectorAll('td');
        if (!tds || tds.length < 15) continue;

        const ip = (tds[5].innerText || '').trim();
        const host = (tds[6].innerText || '').trim();
        const endAt = (tds[14].innerText || '').trim();

        let expired = false;
        for (const td of tds) {
          const style = (td.getAttribute('style') || '').toLowerCase();
          if (style.includes('#ff0000')) { expired = true; break; }
        }

        if (!ip && !host) continue;
        out.push({ ip, host, endAt, expired });
      }
      return out;
    })();
    """;

        var json = await _web.CoreWebView2.ExecuteScriptAsync(js);
        var items = JsonSerializer.Deserialize<List<PortalRowDto>>(json) ?? new();

        return items
            .Select(x => (
                Ip: (x.ip ?? "").Trim(),
                Host: (x.host ?? "").Trim(),
                EndAtText: (x.endAt ?? "").Trim(),
                IsExpired: x.expired
            ))
            .Where(x => !string.IsNullOrWhiteSpace(x.Ip) || !string.IsNullOrWhiteSpace(x.Host))
            .ToList();
    }

    private async Task<bool> JsHasLoadingOverlayAsync()
    {
        string js =
            "(function(){" +
            "  return !!(" +
            "    document.querySelector('#id_line') || document.querySelector('#Id_line') ||" +
            "    document.querySelector('#cont')" +
            "  );" +
            "})()";

        var raw = await _web.CoreWebView2.ExecuteScriptAsync(js);
        return raw.Contains("true", StringComparison.OrdinalIgnoreCase);
    }

    private async Task<(int rowCount, string firstKey)> JsGetTableSignatureAsync()
    {
        string js =
            "(function(){" +
            "  var rows = document.querySelectorAll('#seltable tbody tr');" +
            "  if (!rows || rows.length === 0) return JSON.stringify({c:0,k:''});" +
            "  var tds = rows[0].querySelectorAll('td');" +
            "  var ip = (tds && tds.length>6) ? (tds[5].innerText||'').trim() : '';" +
            "  var host = (tds && tds.length>6) ? (tds[6].innerText||'').trim() : '';" +
            "  return JSON.stringify({c:rows.length,k:(ip+'|'+host)});" +
            "})()";

        var raw = await _web.CoreWebView2.ExecuteScriptAsync(js);

        var jsonText = System.Text.Json.JsonSerializer.Deserialize<string>(raw) ?? "{"c":0,"k":""}";
        using var doc = System.Text.Json.JsonDocument.Parse(jsonText);

        int c = 0;
        string k = "";
        if (doc.RootElement.TryGetProperty("c", out var pc)) c = pc.GetInt32();
        if (doc.RootElement.TryGetProperty("k", out var pk)) k = pk.GetString() ?? "";

        return (c, k);
    }

    private void StartAutoExtractWatcher()
    {
        if (_autoExtractTimer != null) return;

        _autoExtractTimer = new System.Windows.Forms.Timer();
        _autoExtractTimer.Interval = 200;

        _autoExtractTimer.Tick += async (s, e) =>
        {
            if (_autoExtractBusy) return;
            if (_web.CoreWebView2 == null) return;

            _autoExtractBusy = true;
            try
            {
                bool isLoading = await JsHasLoadingOverlayAsync();
                if (isLoading) return;

                var sig = await JsGetTableSignatureAsync();
                if (sig.rowCount <= 0) return;

                bool changed = (sig.rowCount != _lastRowCount) || !string.Equals(sig.firstKey, _lastFirstKey, StringComparison.Ordinal);
                if (!changed) return;

                _lastRowCount = sig.rowCount;
                _lastFirstKey = sig.firstKey;

                await ExtractAndShowAsync();
            }
            catch
            {
            }
            finally
            {
                _autoExtractBusy = false;
            }
        };

        _autoExtractTimer.Start();
    }

    private sealed class PortalRowDto
    {
        public string? ip { get; set; }
        public string? host { get; set; }
        public string? endAt { get; set; }
        public bool expired { get; set; }
    }

    private static bool TryParseEndAt(string s, out DateTime endAt)
    {
        return DateTime.TryParseExact(
            s.Trim(),
            "yyyy-MM-dd HH:mm",
            CultureInfo.InvariantCulture,
            DateTimeStyles.AssumeLocal,
            out endAt
        );
    }

    private static string ToDDayText(DateTime endAt)
    {
        var d = (int)Math.Floor((endAt - DateTime.Now).TotalDays);
        if (d >= 0) return $"D-{d}";
        return $"만료(D+{-d})";
    }

    private static List<ViewRow> BuildRows(
        List<(string Ip, string Host, string EndAtText, bool IsExpired)> extracted,
        DeviceIndex index)
    {
        var rows = new List<ViewRow>(extracted.Count);

        foreach (var (ip, host, endAtText, isExpired) in extracted)
        {
            if (isExpired) continue;

            string dday = "";
            if (!string.IsNullOrWhiteSpace(endAtText) && TryParseEndAt(endAtText, out var endAt))
                dday = ToDDayText(endAt);

            DeviceItem? item = null;

            if (!string.IsNullOrWhiteSpace(host) && index.ByHost.TryGetValue(host, out var byHost))
                item = byHost;
            else if (!string.IsNullOrWhiteSpace(ip) && index.ByIp.TryGetValue(ip, out var byIp))
                item = byIp;

            if (item is null)
            {
                rows.Add(new ViewRow(ip, host, endAtText, dday, "", "", ""));
                continue;
            }

            var listText = item.factova is { Count: > 0 }
                ? string.Join(", ", item.factova)
                : "";

            rows.Add(new ViewRow(
                ip,
                host,
                endAtText,
                dday,
                item.plc ?? "",
                listText,
                item.location ?? ""
                ));
        }

        return rows;
    }

    public sealed record ViewRow(
        string Ip,
        string Host,
        string EndAt,
        string DDay,
        string plc,
        string factova,
        string Location
        );
}
