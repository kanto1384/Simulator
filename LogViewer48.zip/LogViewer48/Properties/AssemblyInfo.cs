using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LogViewer48")]
[assembly: AssemblyDescription("Simple log viewer for day-rotated files")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("LogViewer48")] 
[assembly: AssemblyCopyright("Copyright © 2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("BF3B540B-D792-4B7C-993D-85D7689DA184")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]