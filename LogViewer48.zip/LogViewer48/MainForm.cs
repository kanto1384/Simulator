using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogViewer48
{
    public class LogEntry
    {
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Var { get; set; }
        public string Message { get; set; }
        public string SourceFile { get; set; }
        public long LineNo { get; set; }
    }

    public class LogGroup
    {
        public string Var { get; set; }
        public string Device { get; set; }
        public string FileDateSuffix { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string Status { get; set; }
        public string Level { get; set; }
        public string SourceFile { get; set; }
        public List<LogEntry> Lines { get; } = new List<LogEntry>();
        public TimeSpan? Duration => EndTime.HasValue ? EndTime.Value - StartTime : (TimeSpan?)null;
    }

    public class MainForm : Form
    {
        TextBox txtFolder;
        Button btnBrowse;
        TextBox txtPrefix;
        DateTimePicker dtFrom, dtTo;
        Button btnLoad, btnCleanup;
        DataGridView grid;
        TextBox txtDetails;
        SplitContainer split;
        Label lblCount;
        FileSystemWatcher watcher;

        readonly Dictionary<string, long> fileReadOffsets = new Dictionary<string, long>();
        readonly Dictionary<string, LogGroup> openGroupsByVar = new Dictionary<string, LogGroup>();
        readonly List<LogGroup> closedGroups = new List<LogGroup>();
        readonly object locker = new object();

        readonly Regex lineRx = new Regex(
            @"^(?<date>\\d{4}-\\d{2}-\\d{2}) (?<time>\\d{2}:\\d{2}:\\d{2}\\.\\d{{3}}) \\[(?<level>\\w+)\\] \\[(?<var>[^\\]]+)\\] (?<msg>.*)$",
            RegexOptions.Compiled);

        public MainForm()
        {
            Text = "Log Viewer (.NET Framework 4.8)";
            Width = 1200;
            Height = 800;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(6), AutoSize = false };
            txtFolder = new TextBox { Width = 450 };
            btnBrowse = new Button { Text = "경로...", Width = 70 };
            txtPrefix = new TextBox { Width = 140, Text = "RollMapElm" };
            dtFrom = new DateTimePicker { Width = 130, Value = DateTime.Now.AddDays(-31) };
            dtTo = new DateTimePicker { Width = 130, Value = DateTime.Now.AddDays(1) };
            btnLoad = new Button { Text = "불러오기", Width = 90 };
            btnCleanup = new Button { Text = "한달초과 파일 삭제", Width = 140 };
            lblCount = new Label { AutoSize = true, Text = "0개 그룹" };

            top.Controls.Add(new Label { Text = "폴더:", AutoSize = true, Margin = new Padding(0, 8, 4, 0) });
            top.Controls.Add(txtFolder);
            top.Controls.Add(btnBrowse);
            top.Controls.Add(new Label { Text = "장비/PREFIX:", AutoSize = true, Margin = new Padding(12, 8, 4, 0) });
            top.Controls.Add(txtPrefix);
            top.Controls.Add(new Label { Text = "기간:", AutoSize = true, Margin = new Padding(12, 8, 4, 0) });
            top.Controls.Add(dtFrom);
            top.Controls.Add(new Label { Text = "~", AutoSize = true, Margin = new Padding(4, 8, 4, 0) });
            top.Controls.Add(dtTo);
            top.Controls.Add(btnLoad);
            top.Controls.Add(btnCleanup);
            top.Controls.Add(new Label { Text = "   ", AutoSize = true });
            top.Controls.Add(lblCount);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 450 };

            grid = new DataGridView { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, AutoGenerateColumns = false };
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "변수", DataPropertyName = "Var", Width = 60 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "장비", DataPropertyName = "Device", Width = 120 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "파일", DataPropertyName = "SourceFile", Width = 220 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "시작", DataPropertyName = "StartTime", Width = 150 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "종료", DataPropertyName = "EndTime", Width = 150 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "소요", DataPropertyName = "Duration", Width = 90 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "레벨", DataPropertyName = "Level", Width = 70 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "상태", DataPropertyName = "Status", Width = 100 });

            txtDetails = new TextBox { Dock = DockStyle.Fill, Multiline = true, ScrollBars = ScrollBars.Both, ReadOnly = true, WordWrap = false };

            split.Panel1.Controls.Add(grid);
            split.Panel2.Controls.Add(txtDetails);

            Controls.Add(split);
            Controls.Add(top);

            btnBrowse.Click += (s, e) => BrowseFolder();
            btnLoad.Click += async (s, e) => await LoadAllAsync();
            btnCleanup.Click += (s, e) => CleanupOldFiles();
            grid.SelectionChanged += (s, e) => ShowDetailsOfSelected();

            FormClosing += (s, e) => watcher?.Dispose();
        }

        private void BrowseFolder()
        {
            using (var f = new FolderBrowserDialog())
            {
                if (f.ShowDialog(this) == DialogResult.OK)
                    txtFolder.Text = f.SelectedPath;
            }
        }

        private async Task LoadAllAsync()
        {
            if (string.IsNullOrWhiteSpace(txtFolder.Text) || !Directory.Exists(txtFolder.Text))
            {
                MessageBox.Show("올바른 폴더를 선택하세요.");
                return;
            }

            lock (locker)
            {
                fileReadOffsets.Clear();
                openGroupsByVar.Clear();
                closedGroups.Clear();
            }
            txtDetails.Clear();
            grid.DataSource = null;
            lblCount.Text = "0개 그룹";

            var prefix = txtPrefix.Text?.Trim() ?? "";
            var files = Directory.GetFiles(txtFolder.Text, $"{prefix}_*.txt")
                .Where(p => IsInDateRangeBySuffix(p, dtFrom.Value.Date, dtTo.Value.Date))
                .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
                .ToList();

            foreach (var file in files)
                await ParseFileFromStartAsync(file);

            SetupWatcher(prefix);
            RefreshGrid();
        }

        private void SetupWatcher(string prefix)
        {
            watcher?.Dispose();
            watcher = new FileSystemWatcher(txtFolder.Text, $"{prefix}_*.txt")
            {
                IncludeSubdirectories = false,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size
            };
            watcher.Changed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Created += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Renamed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.EnableRaisingEvents = true;
        }

        private bool IsInDateRangeBySuffix(string path, DateTime from, DateTime toExclusive)
        {
            var name = Path.GetFileNameWithoutExtension(path);
            var parts = name.Split('_');
            if (parts.Length < 2) return true;

            var suffix = parts[1];
            if (suffix.Length != 4 || !int.TryParse(suffix.Substring(0, 2), out int mm) || !int.TryParse(suffix.Substring(2, 2), out int dd))
                return true;

            var year = DateTime.Now.Year;
            DateTime fileDate;
            try { fileDate = new DateTime(year, mm, dd); }
            catch { return true; }

            return fileDate >= from && fileDate < toExclusive;
        }

        private (string Device, string Suffix) ExtractDeviceAndSuffix(string path)
        {
            var name = Path.GetFileNameWithoutExtension(path);
            var idx = name.LastIndexOf('_');
            if (idx > 0)
            {
                return (name.Substring(0, idx), name.Substring(idx + 1));
            }
            return (name, "");
        }

        private async Task ParseFileFromStartAsync(string file)
        {
            try
            {
                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, Encoding.UTF8, true, 1024 * 16))
                {
                    string line;
                    long lineNo = 0;
                    while ((line = await sr.ReadLineAsync()) != null)
                    {
                        lineNo++;
                        ProcessLine(file, line, lineNo);
                    }
                    lock (locker) { fileReadOffsets[file] = fs.Position; }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private async Task OnFileChangedAsync(string file)
        {
            await Task.Delay(100);
            try
            {
                long offset;
                lock (locker)
                {
                    if (!fileReadOffsets.TryGetValue(file, out offset))
                        offset = 0;
                }

                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    if (offset > fs.Length) offset = 0;
                    fs.Position = offset;
                    using (var sr = new StreamReader(fs, Encoding.UTF8, true, 1024 * 16))
                    {
                        string line;
                        long appendedLines = 0;
                        while ((line = await sr.ReadLineAsync()) != null)
                        {
                            appendedLines++;
                            ProcessLine(file, line, 0);
                        }
                        lock (locker) { fileReadOffsets[file] = fs.Position; }
                        if (appendedLines > 0)
                            BeginInvoke(new Action(RefreshGrid));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void ProcessLine(string file, string line, long lineNo)
        {
            var m = lineRx.Match(line);
            if (!m.Success) return;

            var date = m.Groups["date"].Value;
            var time = m.Groups["time"].Value;
            var level = m.Groups["level"].Value;
            var varName = m.Groups["var"].Value;
            var msg = m.Groups["msg"].Value;

            DateTime ts;
            if (!DateTime.TryParse($"{date} {time}", out ts))
                ts = DateTime.MinValue;

            var entry = new LogEntry
            {
                Timestamp = ts,
                Level = level,
                Var = varName,
                Message = msg,
                SourceFile = Path.GetFileName(file),
                LineNo = lineNo
            };

            var (device, suffix) = ExtractDeviceAndSuffix(file);

            lock (locker)
            {
                bool isStart = ContainsToken(msg, "Start");
                bool isEnd = ContainsToken(msg, "End");
                bool isSuccess = ContainsToken(msg, "Success") || ContainsToken(msg, "Succes");

                if (isStart)
                {
                    if (openGroupsByVar.TryGetValue(varName, out var existing))
                    {
                        existing.EndTime = entry.Timestamp;
                        existing.Status = existing.Status ?? "Closed(by new Start)";
                        closedGroups.Add(existing);
                        openGroupsByVar.Remove(varName);
                    }

                    var g = new LogGroup
                    {
                        Var = varName,
                        Device = device,
                        FileDateSuffix = suffix,
                        StartTime = entry.Timestamp,
                        EndTime = null,
                        Status = "Running",
                        Level = level,
                        SourceFile = entry.SourceFile
                    };
                    g.Lines.Add(entry);
                    openGroupsByVar[varName] = g;
                }
                else if (isEnd)
                {
                    if (!openGroupsByVar.TryGetValue(varName, out var g))
                    {
                        g = new LogGroup
                        {
                            Var = varName,
                            Device = device,
                            FileDateSuffix = suffix,
                            StartTime = entry.Timestamp,
                            SourceFile = entry.SourceFile,
                            Level = level,
                            Status = "Completed"
                        };
                    }
                    g.Lines.Add(entry);
                    g.EndTime = entry.Timestamp;
                    if (string.IsNullOrEmpty(g.Status) || g.Status == "Running") g.Status = "Completed";
                    g.Level = PickSeverity(g.Level, level);
                    closedGroups.Add(g);
                    openGroupsByVar.Remove(varName);
                }
                else
                {
                    if (!openGroupsByVar.TryGetValue(varName, out var g))
                    {
                        g = new LogGroup
                        {
                            Var = varName,
                            Device = device,
                            FileDateSuffix = suffix,
                            StartTime = entry.Timestamp,
                            SourceFile = entry.SourceFile,
                            Level = level,
                            Status = "Running"
                        };
                        openGroupsByVar[varName] = g;
                    }
                    g.Lines.Add(entry);
                    if (isSuccess)
                    {
                        g.Status = "Success";
                    }
                    g.Level = PickSeverity(g.Level, level);
                }
            }
        }

        private bool ContainsToken(string msg, string token)
        {
            return msg?.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private string PickSeverity(string a, string b)
        {
            int Rank(string s)
            {
                var t = (s ?? "").ToLowerInvariant();
                if (t == "error" || t == "fatal") return 3;
                if (t == "warn" || t == "warning") return 2;
                if (t == "info") return 1;
                return 0;
            }
            return Rank(a) >= Rank(b) ? a : b;
        }

        private void RefreshGrid()
        {
            List<LogGroup> view;
            lock (locker)
            {
                var from = dtFrom.Value.Date;
                var to = dtTo.Value.Date.AddDays(1);
                view = closedGroups
                    .Where(g => g.StartTime >= from && g.StartTime < to)
                    .OrderByDescending(g => g.StartTime)
                    .ToList();
            }
            grid.DataSource = view;
            lblCount.Text = $"{view.Count}개 그룹";
        }

        private void ShowDetailsOfSelected()
        {
            if (grid.CurrentRow?.DataBoundItem is LogGroup g)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"[변수] {g.Var}");
                sb.AppendLine($"[장비] {g.Device}");
                sb.AppendLine($"[파일] {g.SourceFile}");
                sb.AppendLine($"[시작] {g.StartTime:yyyy-MM-dd HH:mm:ss.fff}");
                sb.AppendLine($"[종료] {(g.EndTime.HasValue ? g.EndTime.Value.ToString("yyyy-MM-dd HH:mm:ss.fff") : "-")}");
                sb.AppendLine($"[상태] {g.Status}  [레벨] {g.Level}");
                sb.AppendLine(new string('-', 80));
                foreach (var ln in g.Lines)
                {
                    sb.AppendLine($"{ln.Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{ln.Level}] [{ln.Var}] {ln.Message}");
                }
                txtDetails.Text = sb.ToString();
            }
            else
            {
                txtDetails.Clear();
            }
        }

        private void CleanupOldFiles()
        {
            if (string.IsNullOrWhiteSpace(txtFolder.Text) || !Directory.Exists(txtFolder.Text))
            {
                MessageBox.Show("올바른 폴더를 선택하세요.");
                return;
            }
            var prefix = txtPrefix.Text?.Trim() ?? "";
            var cutoff = DateTime.Now.Date.AddDays(-31);

            int deleted = 0;
            foreach (var file in Directory.GetFiles(txtFolder.Text, $"{prefix}_*.txt"))
            {
                var name = Path.GetFileNameWithoutExtension(file);
                var parts = name.Split('_');
                if (parts.Length >= 2 && parts[1].Length == 4)
                {
                    if (int.TryParse(parts[1].Substring(0, 2), out int mm) &&
                        int.TryParse(parts[1].Substring(2, 2), out int dd))
                    {
                        try
                        {
                            var dt = new DateTime(DateTime.Now.Year, mm, dd);
                            if (dt < cutoff)
                            {
                                try { File.Delete(file); deleted++; }
                                catch { /* ignore */ }
                            }
                        }
                        catch { /* ignore */ }
                    }
                }
            }
            MessageBox.Show($"{deleted}개 파일 삭제 완료(31일 초과).");
        }
    }
}