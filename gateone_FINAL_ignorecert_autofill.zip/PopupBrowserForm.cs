using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace GATEONE;
public class PopupBrowserForm : Form
{
    public WebView2 WebView { get; } = new WebView2();

    public PopupBrowserForm()
    {
        Text = "새창";
        Width = 1100;
        Height = 800;
        StartPosition = FormStartPosition.CenterParent;

        WebView.Dock = DockStyle.Fill;
        Controls.Add(WebView);
    }

    public async Task EnsureInitializedAsync(Microsoft.Web.WebView2.Core.CoreWebView2Environment env)
    {
        await WebView.EnsureCoreWebView2Async(env);
        WebView.CoreWebView2.WindowCloseRequested += (s, e) => { BeginInvoke(new Action(Close)); };

    }
}
