GATEONE FINAL (Ignore Certificate Errors + Auto Fill ID/PW in Main + Popup)

✅ 변경점(최종)
1) 인증서 경고(안전하지 않음) 페이지가 뜨지 않도록 WebView2 옵션 적용:
   --ignore-certificate-errors

2) 로그인 폼이 iframe 안에 있어도 자동 입력:
   CoreWebView2.FrameCreated + frame.ExecuteScriptAsync + polling(최대 10초)

3) 로그인 버튼 클릭은 하지 않고 값만 채움(2차 인증 때문에 안전)

✅ device_map.json (최상위) 예시:
{
  "version": 1,
  "updatedAt": "2026-02-12",
  "credentials": { "id": "YOUR_ID", "pw": "YOUR_PASSWORD" },
  "devices": []
}

✅ 로그인 input selector
- input#USERID.input_txt
- input#PASSWD.input_txt

참고:
- popup은 Main WebView의 Environment를 그대로 사용하므로 동일하게 인증서 무시 + 자동입력 적용됨.
