using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MxMemoryMap
{
    public class Segment
    {
        public char Area;
        public int StartHex;
        public int Count;
        public Segment(char area, int startHex, int count)
        {
            Area = area; StartHex = startHex; Count = count;
        }
    }

    public class MergedRange
    {
        public char Area;
        public int StartHex;
        public int EndHex;
        public MergedRange(char area, int startHex, int endHex)
        {
            Area = area; StartHex = startHex; EndHex = endHex;
        }
    }

    public class MemoryMap
    {
        public List<Segment> Segments { get; private set; } = new List<Segment>();
    }

    public static class MemoryMapParser
    {
        // COUNT를 생략 가능하게: area:start[:count]
        static readonly Regex Entry = new Regex(@"(?<area>[A-Za-z]):(?<start>[0-9A-Fa-f]+)(:(?<count>0x[0-9A-Fa-f]+|\d+))?", RegexOptions.Compiled);

        public static MemoryMap ParseWithDefault(string input, int defaultCount)
        {
            if (string.IsNullOrWhiteSpace(input)) throw new ArgumentException("입력이 비어 있습니다.");
            var map = new MemoryMap();

            var s = input.Trim();
            if (s.StartsWith("MEMORY=", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);
            var parts = s.Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) throw new FormatException("엔트리가 없습니다. '&' 로 구분된 엔트리를 입력하세요.");

            foreach (var p in parts)
            {
                var m = Entry.Match(p);
                if (!m.Success) throw new FormatException(string.Format("형식을 해석할 수 없습니다: '{0}' (예: B:3000[:10])", p));
                char area = char.ToUpperInvariant(m.Groups["area"].Value[0]);
                int startHex = int.Parse(m.Groups["start"].Value, NumberStyles.AllowHexSpecifier);
                int count = defaultCount;
                if (m.Groups["count"].Success)
                    count = ParseCount(m.Groups["count"].Value);
                if (count <= 0) count = defaultCount;
                map.Segments.Add(new Segment(area, startHex, count));
            }
            return map;
        }

        static int ParseCount(string token)
        {
            if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                return int.Parse(token.Substring(2), NumberStyles.AllowHexSpecifier);
            return int.Parse(token);
        }
    }

    public static class MemoryMapFormatter
    {
        public static string FormatSummary(MemoryMap map, List<MergedRange> merged)
        {
            var sb = new StringBuilder();
            sb.AppendLine("[세그먼트 요약] (끝주소 = 시작 + 개수, 포함)");
            foreach (var seg in map.Segments.OrderBy(s => s.Area).ThenBy(s => s.StartHex))
            {
                int end = seg.StartHex + seg.Count; // 계산기 기준
                sb.AppendLine(string.Format("Area {0}  Start=0x{1:X}  Count={2}  End=0x{3:X}", seg.Area, seg.StartHex, seg.Count, end));
            }
            sb.AppendLine();
            sb.AppendLine("[병합 요약](겹치거나 인접 범위는 하나로)");
            foreach (var m in merged.OrderBy(m => m.Area).ThenBy(m => m.StartHex))
            {
                int count = m.EndHex - m.StartHex + 1;
                sb.AppendLine(string.Format("Area {0}  0x{1:X} ~ 0x{2:X}  (Count={3})", m.Area, m.StartHex, m.EndHex, count));
            }
            sb.AppendLine();
            sb.AppendLine("※ Excel(H열 등) 로드 시 DEVICE_TYPE/ADDRESS_NO 없거나 '@'인 행은 제외됩니다. COUNT 없으면 '기본 Count' 사용.");
            return sb.ToString();
        }
    }
}
