using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public class SheetPickerForm : Form
    {
        private ListBox list;
        private Button btnOk;
        private Button btnCancel;

        public int SelectedIndex { get; private set; } = -1;

        public SheetPickerForm(List<string> sheetNames)
        {
            this.Text = "시트 선택";
            this.Width = 360;
            this.Height = 420;
            this.StartPosition = FormStartPosition.CenterParent;

            list = new ListBox { Dock = DockStyle.Fill };
            foreach (var n in sheetNames) list.Items.Add(n);

            btnOk = new Button { Text = "확인", Dock = DockStyle.Right, Width = 80 };
            btnCancel = new Button { Text = "취소", Dock = DockStyle.Right, Width = 80 };
            btnOk.Click += (s, e) => { SelectedIndex = list.SelectedIndex; this.DialogResult = DialogResult.OK; };
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; };

            var bottom = new Panel { Dock = DockStyle.Bottom, Height = 44, Padding = new Padding(6) };
            bottom.Controls.Add(btnCancel);
            bottom.Controls.Add(btnOk);

            this.Controls.Add(list);
            this.Controls.Add(bottom);
        }
    }
}
