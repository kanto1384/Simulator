using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<MergedRange> _merged = new List<MergedRange>();
        private List<string> _lastExcelRows = new List<string>();
        private string _lastExcelPath;
        private string _selectedSheetTarget; // xl/worksheets/sheet1.xml ...
        private string _selectedSheetName;

        public MainForm()
        {
            InitializeComponent();
            txtInput.Text = "MEMORY=W:3000:4&W:3A00:4&W:4000:10&B:3000:10";
            txtNormalized.ReadOnly = true;
            txtNormalized.ShortcutsEnabled = true;
            txtNormalized.Cursor = Cursors.IBeam;

            // 기본값
            txtDefaultCount.Text = "1";
            txtExcelColumn.Text = "H";
            cboSpecMode.Items.AddRange(new object[] { "최적화(병합)", "원본(세그먼트)" });
            cboSpecMode.SelectedIndex = 0; // 기본 최적화

            txtDefaultCount.TextChanged += (_, __) =>
            {
                // 엑셀 재계산
                if (_lastExcelRows.Count > 0) RebuildFromRows(_lastExcelRows);
                // 수동 입력도 업데이트
                if (!string.IsNullOrWhiteSpace(txtInput.Text))
                    GenerateFromManual();
            };
            cboSpecMode.SelectedIndexChanged += (_, __) => UpdateNormalizedBox();

            // D&D
            this.AllowDrop = true;
            this.DragEnter += MainForm_DragEnter;
            this.DragDrop += MainForm_DragDrop;
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Length > 0 && Path.GetExtension(files[0]).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    e.Effect = DragDropEffects.Copy;
                    return;
                }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;
                var file = files[0];
                if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("엑셀 .xlsx 파일만 지원합니다.");
                    return;
                }

                _lastExcelPath = file;

                // 시트 선택
                var sheets = SimpleXlsx.GetSheetInfos(file);
                if (sheets.Count == 0) { MessageBox.Show("시트를 찾을 수 없습니다."); return; }

                var picker = new SheetPickerForm(sheets.Select(s => s.Name).ToList());
                if (picker.ShowDialog(this) != DialogResult.OK) return;
                int idx = picker.SelectedIndex;
                if (idx < 0 || idx >= sheets.Count) return;
                _selectedSheetTarget = sheets[idx].Target;
                _selectedSheetName = sheets[idx].Name;
                lblSheetInfo.Text = $"Sheet: {_selectedSheetName}";

                LoadExcelAndBuild();
            }
            catch (Exception ex)
            {
                MessageBox.Show("엑셀 로드 실패: " + ex.Message);
            }
        }

        private void btnReloadExcel_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_lastExcelPath))
            {
                MessageBox.Show("먼저 엑셀 파일을 드래그해서 불러오세요.");
                return;
            }
            // 시트 재선택
            var sheets = SimpleXlsx.GetSheetInfos(_lastExcelPath);
            if (sheets.Count == 0) { MessageBox.Show("시트를 찾을 수 없습니다."); return; }

            var picker = new SheetPickerForm(sheets.Select(s => s.Name).ToList());
            if (picker.ShowDialog(this) != DialogResult.OK) return;
            int idx = picker.SelectedIndex;
            if (idx < 0 || idx >= sheets.Count) return;
            _selectedSheetTarget = sheets[idx].Target;
            _selectedSheetName = sheets[idx].Name;
            lblSheetInfo.Text = $"Sheet: {_selectedSheetName}";

            LoadExcelAndBuild();
        }

        private void LoadExcelAndBuild()
        {
            try
            {
                if (string.IsNullOrEmpty(_selectedSheetTarget)) return;
                string col = string.IsNullOrWhiteSpace(txtExcelColumn.Text) ? "H" : txtExcelColumn.Text.Trim();
                var rows = SimpleXlsx.ReadColumnStrings(_lastExcelPath, _selectedSheetTarget, col);
                _lastExcelRows = rows;
                if (rows.Count == 0)
                {
                    MessageBox.Show($"{col}열에서 읽을 문자열이 없습니다.");
                    return;
                }
                RebuildFromRows(rows);
            }
            catch (Exception ex)
            {
                MessageBox.Show("엑셀 처리 중 오류: " + ex.Message);
            }
        }

        private void RebuildFromRows(List<string> rows)
        {
            var map = new MemoryMap();
            int accepted = 0, skipped = 0;
            int defaultCount = GetDefaultCount();

            foreach (var row in rows)
            {
                var dict = ParseKeyValues(row);
                string dev, addr;
                if (!dict.TryGetValue("DEVICE_TYPE", out dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@")
                { skipped++; continue; }
                if (!dict.TryGetValue("ADDRESS_NO", out addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@")
                { skipped++; continue; }

                int count = defaultCount;
                int tmp;
                if (TryGetInt(dict, new[] { "COUNT", "POINT", "POINTS", "LEN", "LENGTH", "SIZE" }, out tmp))
                    count = Math.Max(1, tmp);

                char area = char.ToUpperInvariant(dev.Trim()[0]);
                int startHex;
                if (!TryParseFlexibleInt(addr, out startHex))
                { skipped++; continue; }

                map.Segments.Add(new Segment(area, startHex, count));
                accepted++;
            }

            _map = map;
            _merged = MergeRanges(_map);

            txtOutput.Text = string.Format("[Excel 로드: {0} / Sheet: {1} / Column: {2}]\r\n읽은 행: {3}, 사용: {4}, 제외: {5}\r\n\r\n",
                                Path.GetFileName(_lastExcelPath), _selectedSheetName, txtExcelColumn.Text, rows.Count, accepted, skipped)
                           + MemoryMapFormatter.FormatSummary(_map, _merged);

            UpdateNormalizedBox();
            FillAreaAndPages();
        }

        private void UpdateNormalizedBox()
        {
            if (cboSpecMode.SelectedIndex == 1) // 원본
                txtNormalized.Text = BuildOriginalSpec(_map);
            else // 최적화
                txtNormalized.Text = BuildOptimizedSpec(_merged);
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            GenerateFromManual();
        }

        private void GenerateFromManual()
        {
            try
            {
                int defaultCount = GetDefaultCount();
                // 수동 입력: COUNT가 빠진 엔트리는 기본 Count 적용
                _map = MemoryMapParser.ParseWithDefault(txtInput.Text ?? string.Empty, defaultCount);
                _merged = MergeRanges(_map);

                txtOutput.Text = MemoryMapFormatter.FormatSummary(_map, _merged);
                UpdateNormalizedBox();
                FillAreaAndPages();
            }
            catch (Exception ex)
            {
                txtOutput.Text = "[에러] " + ex.Message;
                txtNormalized.Text = "";
            }
        }

        private void FillAreaAndPages()
        {
            cboArea.Items.Clear();
            foreach (char area in _merged.Select(m => m.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                cboArea.Items.Add(area);
            if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
            else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) { RefreshPages(); }
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) { ShowSelectedPage(); }

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_merged == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _merged.Where(m => m.Area == area).ToList();

            var pages = new SortedSet<int>(); // 0xXX00 페이지
            foreach (var r in ranges)
            {
                int pageStart = r.StartHex & 0xFF00;
                int pageEnd = r.EndHex & 0xFF00;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
                lstPages.Items.Add(string.Format("0x{0:X4} - 0x{1:X4}", p, p + 0xFF));
            lblPageInfo.Text = pages.Count > 0 ? string.Format("페이지 {0}개", pages.Count) : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_merged == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var text = lstPages.SelectedItem.ToString();
            if (string.IsNullOrEmpty(text)) return;

            int pageStart = int.Parse(text.Substring(2, 4), NumberStyles.HexNumber);
            var active = new bool[256];
            foreach (var r in _merged.Where(m => m.Area == area))
            {
                int s = Math.Max(r.StartHex, pageStart);
                int e = Math.Min(r.EndHex, pageStart + 0xFF);
                if (e < s) continue;
                for (int addr = s; addr <= e; addr++) active[addr - pageStart] = true;
            }
            pageView.SetPage(area, pageStart, active);
        }

        private int GetDefaultCount()
        {
            int v;
            if (int.TryParse(txtDefaultCount.Text.Trim(), out v) && v > 0) return v;
            return 1;
        }

        // 유틸
        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var parts = s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var kv = p.Split(new[] { '=' }, 2);
                if (kv.Length == 2)
                {
                    var key = kv[0].Trim();
                    var val = kv[1].Trim();
                    dict[key] = val;
                }
            }
            return dict;
        }

        private static bool TryGetInt(Dictionary<string, string> dict, string[] keys, out int value)
        {
            foreach (var k in keys)
            {
                string s;
                if (dict.TryGetValue(k, out s) && TryParseFlexibleInt(s, out value))
                    return true;
            }
            value = 0;
            return false;
        }

        private static bool TryParseFlexibleInt(string token, out int val)
        {
            if (string.IsNullOrWhiteSpace(token)) { val = 0; return false; }
            token = token.Trim();
            if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
            {
                return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            }
            token = token.Replace(",", "");
            bool hasHex = false;
            foreach (char ch in token)
            {
                if ((ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f')) { hasHex = true; break; }
            }
            if (hasHex) return int.TryParse(token, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            return int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
        }

        // B, W 우선 정렬 키
        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }

        private static string BuildOptimizedSpec(List<MergedRange> merged)
        {
            var parts = new List<string>();
            foreach (var g in merged.GroupBy(m => m.Area).OrderBy(g => AreaOrderKey(g.Key)))
            {
                foreach (var r in g.OrderBy(x => x.StartHex))
                {
                    int count = r.EndHex - r.StartHex + 1;
                    parts.Add(string.Format("{0}:{1:X}:{2}", r.Area, r.StartHex, count));
                }
            }
            return string.Join("&", parts.ToArray());
        }

        private static string BuildOriginalSpec(MemoryMap map)
        {
            var parts = new List<string>();
            foreach (var g in map.Segments.GroupBy(s => s.Area).OrderBy(g => AreaOrderKey(g.Key)))
            {
                foreach (var s in g.OrderBy(x => x.StartHex))
                {
                    parts.Add(string.Format("{0}:{1:X}:{2}", s.Area, s.StartHex, s.Count));
                }
            }
            return string.Join("&", parts.ToArray());
        }

        private static List<MergedRange> MergeRanges(MemoryMap map)
        {
            var result = new List<MergedRange>();
            foreach (var g in map.Segments.GroupBy(s => s.Area))
            {
                var intervals = g.Select(s => new { Start = s.StartHex, End = s.StartHex + s.Count }) // inclusive
                                 .OrderBy(t => t.Start).ToList();
                int? curS = null; int? curE = null;
                foreach (var it in intervals)
                {
                    int s = it.Start; int e = it.End;
                    if (curS == null) { curS = s; curE = e; continue; }
                    if (s <= curE + 1) curE = Math.Max(curE.Value, e);
                    else { result.Add(new MergedRange(g.Key, curS.Value, curE.Value)); curS = s; curE = e; }
                }
                if (curS != null) result.Add(new MergedRange(g.Key, curS.Value, curE.Value));
            }
            return result;
        }
    }
}
