using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MxMemoryMap")]
[assembly: AssemblyDescription("Memory map viewer (Full: multi .xlsx VARIABLES/H, duplicate highlighting)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("MxMemoryMap")] 
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("d3f1b9a3-2d7a-4b45-9d2d-1b6d8c0f1b9e")]
[assembly: AssemblyVersion("1.5.0.0")]
[assembly: AssemblyFileVersion("1.5.0.0")]
