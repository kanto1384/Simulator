using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MxMemoryMap
{
    public partial class MainForm : Form
    {
        private MemoryMap _map = new MemoryMap();
        private List<MergedRange> _merged = new List<MergedRange>();
        private List<string> _lastExcelRows = new List<string>();

        public MainForm()
        {
            InitializeComponent();
            txtInput.Text = "MEMORY=W:3000:4&W:3A00:4&W:4000:10&B:3000:10";
            txtNormalized.ReadOnly = true;
            txtNormalized.ShortcutsEnabled = true;
            txtNormalized.Cursor = Cursors.IBeam;

            txtDefaultCount.Text = "1";
            cboSpecMode.Items.AddRange(new object[] { "최적화(병합)", "원본(세그먼트)" });
            cboSpecMode.SelectedIndex = 0;

            txtDefaultCount.TextChanged += (_, __) =>
            {
                int _;
                if (!int.TryParse(txtDefaultCount.Text.Trim(), out _)) return;
                if (_lastExcelRows.Count > 0)
                    RebuildFromRows(_lastExcelRows);
                else if (!string.IsNullOrWhiteSpace(txtInput.Text))
                    GenerateFromManual();
            };
            cboSpecMode.SelectedIndexChanged += (_, __) => UpdateNormalizedBox();

            this.AllowDrop = True;
            this.DragEnter += MainForm_DragEnter;
            this.DragDrop += MainForm_DragDrop;
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Length > 0)
                {
                    foreach (var f in files)
                    {
                        if (Path.GetExtension(f).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)) { e.Effect = DragDropEffects.Copy; return; }
                    }
                }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0) return;

                var allRows = new List<string>();
                int used = 0, skipped = 0;
                foreach (var file in files)
                {
                    if (!Path.GetExtension(file).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)) { skipped++; continue; }
                    var sheet = SimpleXlsx.FindSheetByName(file, "VARIABLES");
                    if (sheet == null) { skipped++; continue; }
                    var rows = SimpleXlsx.ReadColumnStrings(file, sheet.Target, "H");
                    if (rows.Count == 0) { skipped++; continue; }
                    allRows.AddRange(rows);
                    used++;
                }

                if (allRows.Count == 0)
                {
                    MessageBox.Show("가져올 데이터가 없습니다. (.xlsx / VARIABLES 시트 / H열)");
                    return;
                }

                _lastExcelRows = allRows;
                lblSheetInfo.Text = $"VARIABLES / H (Files={used}, Skipped={skipped})";
                RebuildFromRows(allRows);
            }
            catch (Exception ex)
            {
                MessageBox.Show("엑셀 처리 오류: " + ex.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e) => GenerateFromManual();

        private void GenerateFromManual()
        {
            try
            {
                int defaultCount = GetDefaultCount();
                _map = MemoryMapParser.ParseWithDefault(txtInput.Text ?? string.Empty, defaultCount);
                _merged = MergeRanges(_map);
                txtOutput.Text = MemoryMapFormatter.FormatSummary(_map, _merged);
                UpdateNormalizedBox();
                FillAreaAndPages();
                // 수동 입력 시작 → 엑셀 캐시 비움
                _lastExcelRows.Clear();
                lblSheetInfo.Text = "Sheet: (수동 입력)";
            }
            catch (Exception ex)
            {
                txtOutput.Text = "[에러] " + ex.Message;
                txtNormalized.Text = "";
            }
        }

        private void RebuildFromRows(List<string> rows)
        {
            var map = new MemoryMap();
            int accepted = 0, skipped = 0;
            int defaultCount = GetDefaultCount();

            foreach (var row in rows)
            {
                var dict = ParseKeyValues(row);
                string dev, addr;
                if (!dict.TryGetValue("DEVICE_TYPE", out dev) || string.IsNullOrWhiteSpace(dev) || dev.Trim() == "@")
                { skipped++; continue; }
                if (!dict.TryGetValue("ADDRESS_NO", out addr) || string.IsNullOrWhiteSpace(addr) || addr.Trim() == "@")
                { skipped++; continue; }

                int count = defaultCount;
                int tmp;
                if (TryGetInt(dict, new[] { "COUNT", "POINT", "POINTS", "LEN", "LENGTH", "SIZE" }, out tmp))
                    count = Math.Max(1, tmp);

                char area = char.ToUpperInvariant(dev.Trim()[0]);
                int startHex;
                if (!TryParseFlexibleInt(addr, out startHex))
                { skipped++; continue; }

                map.Segments.Add(new Segment(area, startHex, count));
                accepted++;
            }

            _map = map;
            _merged = MergeRanges(_map);

            txtOutput.Text = $"[Excel 다중 로드] 읽은 행: {rows.Count}, 사용: {accepted}, 제외: {skipped}\r\n\r\n"
                           + MemoryMapFormatter.FormatSummary(_map, _merged);

            UpdateNormalizedBox();
            // 엑셀 결과를 수동 입력 박스에도 반영(최적화 명세)
            txtInput.Text = BuildOptimizedSpec(_merged);

            FillAreaAndPages();
        }

        private void UpdateNormalizedBox()
        {
            if (cboSpecMode.SelectedIndex == 1)
                txtNormalized.Text = BuildOriginalSpec(_map);
            else
                txtNormalized.Text = BuildOptimizedSpec(_merged);
        }

        private void FillAreaAndPages()
        {
            cboArea.Items.Clear();
            foreach (char area in _merged.Select(m => m.Area).Distinct().OrderBy(c => AreaOrderKey(c)))
                cboArea.Items.Add(area);
            if (cboArea.Items.Count > 0) cboArea.SelectedIndex = 0;
            else { lstPages.Items.Clear(); pageView.Clear(); lblPageInfo.Text = "페이지 없음"; }
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e) { RefreshPages(); }
        private void lstPages_SelectedIndexChanged(object sender, EventArgs e) { ShowSelectedPage(); }

        private void RefreshPages()
        {
            lstPages.Items.Clear();
            pageView.Clear();
            if (_merged == null || cboArea.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var ranges = _merged.Where(m => m.Area == area).ToList();

            var pages = new SortedSet<int>(); // 0xXX00 페이지
            foreach (var r in ranges)
            {
                int pageStart = r.StartHex & 0xFF00;
                int pageEnd = r.EndHex & 0xFF00;
                for (int p = pageStart; p <= pageEnd; p += 0x100) pages.Add(p);
            }
            foreach (int p in pages)
                lstPages.Items.Add(string.Format("0x{0:X4} - 0x{1:X4}", p, p + 0xFF));
            lblPageInfo.Text = pages.Count > 0 ? string.Format("페이지 {0}개", pages.Count) : "페이지 없음";
            if (lstPages.Items.Count > 0) lstPages.SelectedIndex = 0;
        }

        private void ShowSelectedPage()
        {
            if (_merged == null || cboArea.SelectedItem == null || lstPages.SelectedItem == null) return;
            char area = (char)cboArea.SelectedItem;
            var text = lstPages.SelectedItem.ToString();
            if (string.IsNullOrEmpty(text)) return;

            int pageStart = int.Parse(text.Substring(2, 4), NumberStyles.HexNumber);
            var counts = new byte[256];
            foreach (var s in _map.Segments.Where(m => char.ToUpperInvariant(m.Area) == area))
            {
                int sAddr = Math.Max(s.StartHex, pageStart);
                int eAddr = Math.Min(s.StartHex + s.Count, pageStart + 0xFF); // inclusive
                if (eAddr < sAddr) continue;
                for (int addr = sAddr; addr <= eAddr; addr++)
                {
                    int idx = addr - pageStart;
                    if (idx >= 0 && idx < 256)
                    {
                        if (counts[idx] < 255) counts[idx]++;
                    }
                }
            }
            pageView.SetPage(area, pageStart, counts);
        }

        private int GetDefaultCount()
        {
            int v;
            if (int.TryParse(txtDefaultCount.Text.Trim(), out v) && v > 0) return v;
            return 1;
        }

        // --- utils ---
        private static Dictionary<string, string> ParseKeyValues(string s)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var parts = s.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var kv = p.Split(new[] { '=' }, 2);
                if (kv.Length == 2) dict[kv[0].Trim()] = kv[1].Trim();
            }
            return dict;
        }

        private static bool TryGetInt(Dictionary<string, string> dict, string[] keys, out int value)
        {
            foreach (var k in keys)
            {
                string s;
                if (dict.TryGetValue(k, out s) && TryParseFlexibleInt(s, out value))
                    return true;
            }
            value = 0;
            return false;
        }

        private static bool TryParseFlexibleInt(string token, out int val)
        {
            if (string.IsNullOrWhiteSpace(token)) { val = 0; return false; }
            token = token.Trim();
            if (token.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                return int.TryParse(token.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            token = token.Replace(",", "");
            bool hasHex = false;
            foreach (char ch in token)
            {
                if ((ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f')) { hasHex = true; break; }
            }
            if (hasHex) return int.TryParse(token, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out val);
            return int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out val);
        }

        private static int AreaOrderKey(char area)
        {
            area = char.ToUpperInvariant(area);
            if (area == 'B') return 0;
            if (area == 'W') return 1;
            return 2 + (int)area;
        }

        private static string BuildOptimizedSpec(List<MergedRange> merged)
        {
            var parts = new List<string>();
            foreach (var g in merged.GroupBy(m => m.Area).OrderBy(g => AreaOrderKey(g.Key)))
            {
                foreach (var r in g.OrderBy(x => x.StartHex))
                {
                    int count = r.EndHex - r.StartHex + 1;
                    parts.Add(string.Format("{0}:{1:X}:{2}", r.Area, r.StartHex, count));
                }
            }
            return string.Join("&", parts.ToArray());
        }

        private static string BuildOriginalSpec(MemoryMap map)
        {
            var parts = new List<string>();
            foreach (var g in map.Segments.GroupBy(s => s.Area).OrderBy(g => AreaOrderKey(g.Key)))
            {
                foreach (var s in g.OrderBy(x => x.StartHex))
                {
                    parts.Add(string.Format("{0}:{1:X}:{2}", s.Area, s.StartHex, s.Count));
                }
            }
            return string.Join("&", parts.ToArray());
        }

        private static List<MergedRange> MergeRanges(MemoryMap map)
        {
            var result = new List<MergedRange>();
            foreach (var g in map.Segments.GroupBy(s => s.Area))
            {
                var intervals = g.Select(s => new { Start = s.StartHex, End = s.StartHex + s.Count }) // inclusive
                                 .OrderBy(t => t.Start).ToList();
                int? curS = null; int? curE = null;
                foreach (var it in intervals)
                {
                    int s = it.Start; int e = it.End;
                    if (curS == null) { curS = s; curE = e; continue; }
                    if (s <= curE + 1) curE = Math.Max(curE.Value, e);
                    else { result.Add(new MergedRange(g.Key, curS.Value, curE.Value)); curS = s; curE = e; }
                }
                if (curS != null) result.Add(new MergedRange(g.Key, curS.Value, curE.Value));
            }
            return result;
        }
    }
}
