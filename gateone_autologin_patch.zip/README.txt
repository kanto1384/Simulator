GATEONE Auto Login Patch (Main + Popup)

- device_map.json 최상위에 아래 항목을 채우면,
  메인 WebView2 / 팝업 WebView2 모두에서
  1) "안전하지 않음" interstitial에서 Proceed 시도
  2) 로그인 input이 나타나면 ID/PW 자동 입력

device_map.json 예시:

{
  "version": 1,
  "updatedAt": "2026-02-12",
  "credentials": {
    "id": "YOUR_ID",
    "pw": "YOUR_PASSWORD"
  },
  "devices": []
}

주의:
- 본 패치는 "값만 입력"합니다(로그인 버튼 자동 클릭 없음).
- interstitial DOM이 다른 환경이면 #details-button/#proceed-link가 다를 수 있습니다.
