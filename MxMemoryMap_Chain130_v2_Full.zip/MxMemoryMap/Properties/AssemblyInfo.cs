using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MxMemoryMap")]
[assembly: AssemblyDescription("Memory map viewer (Chain-130 rule, end-exclusive display)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("MxMemoryMap")] 
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("d3f1b9a3-2d7a-4b45-9d2d-1b6d8c0f1b9e")]
[assembly: AssemblyVersion("2.0.1.0")]
[assembly: AssemblyFileVersion("2.0.1.0")]
