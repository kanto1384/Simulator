namespace MxMemoryMap
{
    // Core helper placeholder (v2) - logic is inside MainForm for this sample.
    public static class CoreInfo
    {
        public const int MaxGap = 130;
    }
}
