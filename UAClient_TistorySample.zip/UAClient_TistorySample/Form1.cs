using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Configuration;

namespace UAClient_TistorySample
{
    public partial class Form1 : Form
    {
        private Subscription _subscription;

        public Form1()
        {
            InitializeComponent();
        }

        private async void Connect()
        {
            try
            {
                // KepServerEX Endpoint (예: Ua Configuration에서 확인)
                string endpointUrl = "opc.tcp://localhost:49320";

                // OPC UA Client 설정
                var config = new ApplicationConfiguration()
                {
                    ApplicationName = "OPCClientTest",
                    ApplicationUri = Utils.Format(@"urn:{0}:OPCClientTest", System.Net.Dns.GetHostName()),
                    ApplicationType = ApplicationType.Client,
                    SecurityConfiguration = new SecurityConfiguration
                    {
                        ApplicationCertificate = new CertificateIdentifier(),
                        TrustedPeerCertificates = new CertificateTrustList(),
                        RejectedCertificateStore = new CertificateStoreIdentifier(),
                        AutoAcceptUntrustedCertificates = true,
                        RejectSHA1SignedCertificates = false
                    },
                    TransportConfigurations = new TransportConfigurationCollection(),
                    TransportQuotas = new TransportQuotas { OperationTimeout = 15000 },
                    ClientConfiguration = new ClientConfiguration { DefaultSessionTimeout = 60000 },
                    TraceConfiguration = new TraceConfiguration(),
                };

                // 연결(Session 생성) - 보안 사용 안함 (useSecurity:false)
                var selectedEndpoint = CoreClientUtils.SelectEndpoint(endpointUrl, useSecurity: false);
                var endconf = new ConfiguredEndpoint(null, selectedEndpoint, EndpointConfiguration.Create(config));
                var session = Session.Create(config, endconf, true, "session", 1000, null, null).GetAwaiter().GetResult();

                // 구독(모니터링) 설정
                _subscription = new Subscription(session.DefaultSubscription)
                {
                    PublishingEnabled = true,
                    PublishingInterval = 500,
                };

                // 모니터링 할 Item 리스트
                var list = new List<MonitoredItem>();

                list.Add(new MonitoredItem()
                {
                    DisplayName = "Tag1",
                    StartNodeId = "ns=2;s=Channel1.Device1.Tag1"
                });
                list.Add(new MonitoredItem()
                {
                    DisplayName = "Tag2",
                    StartNodeId = "ns=2;s=Channel1.Device1.Tag2"
                });
                list.Add(new MonitoredItem()
                {
                    DisplayName = "Tag3",
                    StartNodeId = "ns=2;s=Channel1.Device1.Tag3"
                });

                // 이벤트 핸들러 연결
                list.ForEach(i => i.Notification += new MonitoredItemNotificationEventHandler(OnNotification));

                // Subscription에 Item 등록
                _subscription.AddItems(list);

                // Session에 Subscription 추가 후 생성
                session.AddSubscription(_subscription);
                _subscription.Create();
            }
            catch (Exception ex)
            {
                // 간단 로그
                this.Invoke(new MethodInvoker(delegate ()
                {
                    if (EventList.Items.Count > 100)
                        EventList.Items.RemoveAt(EventList.Items.Count - 1);
                    EventList.Items.Insert(0, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    EventList.Items[0].SubItems.Add("[EXCEPTION] : " + ex.Message);
                }));
            }
        }

        // 모니터링 콜백
        private void OnNotification(MonitoredItem item, MonitoredItemNotificationEventArgs e)
        {
            try
            {
                foreach (var value in item.DequeueValues())
                {
                    this.Invoke(new MethodInvoker(delegate ()
                    {
                        if (StatusCode.IsGood(value.StatusCode))
                        {
                            if (EventList.Items.Count > 100)
                                EventList.Items.RemoveAt(EventList.Items.Count - 1);
                            EventList.Items.Insert(0, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            EventList.Items[0].SubItems.Add("[Value] : " + value.Value + ", ID: " + item.DisplayName);
                        }
                        else
                        {
                            if (EventList.Items.Count > 100)
                                EventList.Items.RemoveAt(EventList.Items.Count - 1);
                            EventList.Items.Insert(0, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                            EventList.Items[0].SubItems.Add("[STATUS] : " + value.StatusCode + ", ID: " + item.DisplayName);
                        }
                    }));
                }
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Connect();
        }
    }
}