# UAClient_TistorySample

- .NET Framework **4.7.2**, Windows Forms, C# 7.3
- NuGet:
  - `OPCFoundation.NetStandard.Opc.Ua` **1.5.376.244**
  - `OPCFoundation.NetStandard.Opc.Ua.Client` **1.5.376.244**
- 구성은 아래 글의 예제를 최대한 동일하게 따릅니다 (보안 미사용 / 구독으로 값 모니터링):
  - https://oppr123.tistory.com/m/41

## 실행 방법
1. VS 2019/2022에서 솔루션을 엽니다.
2. NuGet 패키지 복원을 수행합니다.
3. `Form1.cs` 내 `endpointUrl`과 `StartNodeId`를 환경에 맞게 수정합니다.
4. 실행하면 폼 로드시 자동으로 Connect 후 Subscription을 생성합니다.