
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogViewer48
{
    public class LogRow
    {
        public DateTime Timestamp { get; set; }
        public string Level { get; set; }
        public string Device { get; set; }
        public string Var { get; set; }
        public string SourceFile { get; set; }
        public long LineIndex { get; set; } // 0-based index within file
        public string RawMessage { get; set; }
        public double? DurationSeconds { get; set; } // to next line of same Var
    }

    public class MainForm : Form
    {
        TextBox txtFolder;
        Button btnBrowse;
        TextBox txtPrefix;
        Button btnLoad;
        DataGridView grid;
        SplitContainer split;
        StatusStrip statusStrip;
        ToolStripStatusLabel statusLabel;
        ToolStripProgressBar statusProgress;

        FileSystemWatcher watcher;
        readonly object locker = new object();
        readonly List<LogRow> rows = new List<LogRow>();

        readonly Regex headRx = new Regex(
            @"^(?<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+\[(?<level>[^\]]+)\]\s+(?<rest>.*)$",
            RegexOptions.Compiled);

        readonly Regex bracketRx = new Regex(@"^\[(?<tok>[^\]]+)\]\s*", RegexOptions.Compiled);

        public MainForm()
        {
            Text = "Log Viewer (.NET Framework 4.8)";
            Width = 1100;
            Height = 760;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(6), AutoSize = false };
            txtFolder = new TextBox { Width = 520 };
            btnBrowse = new Button { Text = "경로...", Width = 70 };
            txtPrefix = new TextBox { Width = 160, Text = "RollMapElm" };
            btnLoad = new Button { Text = "불러오기", Width = 100 };

            top.Controls.Add(new Label { Text = "폴더:", AutoSize = true, Margin = new Padding(0, 8, 4, 0) });
            top.Controls.Add(txtFolder);
            top.Controls.Add(btnBrowse);
            top.Controls.Add(new Label { Text = "파일 Prefix:", AutoSize = true, Margin = new Padding(12, 8, 4, 0) });
            top.Controls.Add(txtPrefix);
            top.Controls.Add(btnLoad);

            split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 700 };
            split.Panel1.Padding = new Padding(0, 0, 0, 10);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoGenerateColumns = false,
                AllowUserToOrderColumns = true
            };

            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "날짜시간", DataPropertyName = "Timestamp", Width = 180 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "레벨", DataPropertyName = "Level", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "장비", DataPropertyName = "Device", Width = 150 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "변수", DataPropertyName = "Var", Width = 120 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "소요(초)", DataPropertyName = "DurationSeconds", Width = 100, DefaultCellStyle = new DataGridViewCellStyle { Format = "N3" } });

            split.Panel1.Controls.Add(grid);
            split.Panel2Collapsed = true; // no message panel

            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel("대기 중");
            statusProgress = new ToolStripProgressBar() { Style = ProgressBarStyle.Blocks, Visible = false };
            statusStrip.Items.Add(statusLabel);
            statusStrip.Items.Add(new ToolStripStatusLabel() { Spring = true });
            statusStrip.Items.Add(statusProgress);

            Controls.Add(split);
            Controls.Add(top);
            Controls.Add(statusStrip);

            btnBrowse.Click += (s, e) => BrowseFolder();
            btnLoad.Click += async (s, e) => await LoadAllAsync();
            grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && e.RowIndex < grid.Rows.Count) ShowDetail((LogRow)grid.Rows[e.RowIndex].DataBoundItem); };

            FormClosing += (s, e) => watcher?.Dispose();
        }

        private void SetBusy(string text, bool busy)
        {
            statusLabel.Text = text;
            statusProgress.Visible = busy;
            statusProgress.Style = busy ? ProgressBarStyle.Marquee : ProgressBarStyle.Blocks;
            btnLoad.Enabled = !busy;
            btnBrowse.Enabled = !busy;
            txtFolder.Enabled = !busy;
            txtPrefix.Enabled = !busy;
            Cursor = busy ? Cursors.AppStarting : Cursors.Default;
            statusStrip.Refresh();
        }

        private void BrowseFolder()
        {
            using (var f = new FolderBrowserDialog())
            {
                if (f.ShowDialog(this) == DialogResult.OK)
                    txtFolder.Text = f.SelectedPath;
            }
        }

        private async Task LoadAllAsync()
        {
            if (string.IsNullOrWhiteSpace(txtFolder.Text) || !Directory.Exists(txtFolder.Text))
            {
                MessageBox.Show("올바른 폴더를 선택하세요.");
                return;
            }

            SetBusy("불러오는 중…", true);
            try
            {
                lock (locker) { rows.Clear(); }

                var prefix = txtPrefix.Text?.Trim() ?? "";
                var files = Directory.GetFiles(txtFolder.Text, $"{prefix}_*.log")
                    .OrderBy(p => p, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                int idx = 0;
                foreach (var file in files)
                {
                    idx++;
                    statusLabel.Text = $"불러오는 중… ({idx}/{files.Count}) {Path.GetFileName(file)}";
                    await ParseFileAsync(file);
                }

                ComputeDurationsPerVar();

                grid.DataSource = null;
                grid.DataSource = rows.OrderBy(r => r.Timestamp).ToList();
                statusLabel.Text = $"불러오기 완료: 파일 {files.Count}개, 라인 {rows.Count}개";

                SetupWatcher(prefix);
            }
            catch (Exception ex)
            {
                statusLabel.Text = "오류 발생";
                MessageBox.Show(ex.ToString(), "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetBusy(statusLabel.Text, false);
            }
        }

        private void SetupWatcher(string prefix)
        {
            watcher?.Dispose();
            watcher = new FileSystemWatcher(txtFolder.Text, $"{prefix}_*.log")
            {
                IncludeSubdirectories = false,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size
            };
            watcher.Changed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Created += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.Renamed += async (s, e) => await OnFileChangedAsync(e.FullPath);
            watcher.EnableRaisingEvents = true;
        }

        private async Task ParseFileAsync(string file)
        {
            try
            {
                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, Encoding.UTF8, true, 1024 * 16))
                {
                    string line;
                    long idx = 0;
                    LogRow last = null;
                    while ((line = await sr.ReadLineAsync()) != null)
                    {
                        var m = headRx.Match(line);
                        if (m.Success)
                        {
                            if (!DateTime.TryParse(m.Groups["dt"].Value, out var ts)) continue;
                            var level = m.Groups["level"].Value;
                            var rest = m.Groups["rest"].Value;

                            var tokens = new List<string>();
                            while (true)
                            {
                                var bm = bracketRx.Match(rest);
                                if (!bm.Success) break;
                                tokens.Add(bm.Groups["tok"].Value);
                                rest = rest.Substring(bm.Length);
                            }

                            string device = null;
                            string varName = null;
                            if (tokens.Count >= 2) { device = tokens[0]; varName = tokens[1]; }
                            else if (tokens.Count == 1) { varName = tokens[0]; }

                            if (string.IsNullOrEmpty(device))
                            {
                                var n = Path.GetFileNameWithoutExtension(file);
                                var cut = n.LastIndexOf('_');
                                device = cut > 0 ? n.Substring(0, cut) : n;
                            }
                            if (string.IsNullOrEmpty(varName)) varName = device ?? "GLOBAL";

                            var row = new LogRow
                            {
                                Timestamp = ts,
                                Level = level,
                                Device = device,
                                Var = varName,
                                SourceFile = Path.GetFileName(file),
                                LineIndex = idx,
                                RawMessage = rest?.Trim() ?? ""
                            };
                            lock (locker) { rows.Add(row); }
                            last = row;
                            idx++;
                        }
                        else
                        {
                            if (last != null)
                            {
                                last.RawMessage = string.IsNullOrEmpty(last.RawMessage)
                                    ? line
                                    : last.RawMessage + Environment.NewLine + line;
                            }
                            idx++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private async Task OnFileChangedAsync(string file)
        {
            // Simple approach: full reload
            await LoadAllAsync();
        }

        private void ComputeDurationsPerVar()
        {
            var byVar = rows.GroupBy(r => r.Var);
            foreach (var g in byVar)
            {
                var list = g.OrderBy(r => r.Timestamp).ToList();
                for (int i = 0; i < list.Count - 1; i++)
                {
                    var cur = list[i];
                    var next = list[i + 1];
                    var dt = (next.Timestamp - cur.Timestamp).TotalSeconds;
                    cur.DurationSeconds = Math.Max(0, Math.Round(dt, 3));
                }
                list[list.Count - 1].DurationSeconds = null;
            }
        }

        private void ShowDetail(LogRow row)
        {
            var filePath = Path.Combine(txtFolder.Text, row.SourceFile);
            if (!File.Exists(filePath))
            {
                MessageBox.Show("원본 파일을 찾을 수 없습니다.");
                return;
            }

            string[] lines;
            try
            {
                lines = File.ReadAllLines(filePath, System.Text.Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            int startIdx = -1, endIdx = -1;
            for (int i = (int)Math.Max(0, row.LineIndex - 2000); i >= 0; i--)
            {
                var m = headRx.Match(lines[i]);
                if (!m.Success) continue;

                var rest = m.Groups["rest"].Value;
                var tokens = new List<string>();
                while (true)
                {
                    var bm = bracketRx.Match(rest);
                    if (!bm.Success) break;
                    tokens.Add(bm.Groups["tok"].Value);
                    rest = rest.Substring(bm.Length);
                }
                string varName = tokens.Count >= 2 ? tokens[1] : (tokens.Count == 1 ? tokens[0] : null);
                if (string.IsNullOrEmpty(varName)) varName = row.Var;

                if (varName == row.Var && rest.IndexOf("Start", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    startIdx = i;
                    break;
                }
            }

            for (int i = (int)row.LineIndex; i < lines.Length; i++)
            {
                var m = headRx.Match(lines[i]);
                if (!m.Success) continue;
                var rest = m.Groups["rest"].Value;
                if (rest.IndexOf(" End", StringComparison.OrdinalIgnoreCase) >= 0 &&
                    rest.IndexOf("Start", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    endIdx = i;
                    break;
                }
            }

            int from = startIdx >= 0 ? startIdx : (int)Math.Max(0, row.LineIndex - 100);
            int to = endIdx >= 0 ? endIdx : Math.Min(lines.Length - 1, (int)row.LineIndex + 200); // will fix to Math.Min below

            var block = string.Join(Environment.NewLine, lines.Skip(from).Take(to - from + 1));

            var frm = new Form
            {
                Text = $"{row.SourceFile} - {row.Var} 원문 보기 ({from}-{to})",
                Width = 1000,
                Height = 700
            };
            var tb = new TextBox
            {
                Multiline = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                ReadOnly = true,
                Font = new System.Drawing.Font("Consolas", 10),
                Text = block
            };
            frm.Controls.Add(tb);
            frm.Show();
        }
    }
}
