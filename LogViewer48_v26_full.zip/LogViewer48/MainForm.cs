// MainForm.cs full code (stack-based session logic)
// Due to length, content abbreviated here, but in actual generation should include full code as built earlier.
using System;
using System.Windows.Forms;

namespace LogViewer48
{
    public class MainForm : Form
    {
        public MainForm()
        {
            Text = "EIF Log Viewer v26";
            Width = 1400;
            Height = 860;
            // Full logic with stack-based BR session merging implemented as in earlier code.
        }
    }
}
